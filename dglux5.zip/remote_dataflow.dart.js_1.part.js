self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,N,{"^":"",
aE7:function(){var z=document
z=z.createElement("div")
z=new N.EF(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.oP()
z.abw()
return z},
ahQ:{"^":"ID;",
sq9:["auv",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cC()}}],
sGu:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cC()}},
sGv:function(a){if(!J.b(this.rx,a)){this.rx=a
this.cC()}},
sGw:function(a){if(!J.b(this.ry,a)){this.ry=a
this.cC()}},
sGy:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cC()}},
sGx:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cC()}},
saRY:function(a){if(!J.b(this.y1,a)){if(J.Z(a,180))a=180
this.y1=J.aG(a,-180)?-180:a
this.cC()}},
saRX:function(a){if(J.b(this.y2,a))return
this.y2=a
this.cC()},
gij:function(){return this.E},
sij:function(a){if(a==null)a=0
if(!J.b(this.E,a)){this.E=a
this.cC()}},
giP:function(){return this.v},
siP:function(a){if(a==null)a=100
if(!J.b(this.v,a)){this.v=a
this.cC()}},
saYR:function(a){if(this.N!==a){this.N=a
this.cC()}},
samw:function(a,b){if(b==null||J.aG(b,0))b=0
if(J.Z(b,4))b=4
if(!J.b(this.U,b)){this.U=b
this.cC()}},
sasY:function(a){if(this.V!==a){this.V=a
this.cC()}},
svw:function(a){this.Z=a
this.cC()},
gpw:function(){return this.F},
spw:function(a){if(!J.b(this.F,a)){this.F=a
this.cC()}},
saRN:function(a){if(!J.b(this.a1,a)){this.a1=a
this.cC()}},
guj:function(a){return this.O},
suj:["aaq",function(a,b){if(!J.b(this.O,b))this.O=b}],
sGS:["aar",function(a){if(!J.b(this.at,a))this.at=a}],
sa3x:function(a){this.aat(a)
this.cC()},
iE:function(a,b){this.EI(a,b)
this.N1()
if(J.b(this.F,"circular"))this.aZ1(a,b)
else this.aZ2(a,b)},
N1:function(){var z,y,x,w,v
z=this.V
y=this.k2
if(z){y.se9(0,2)
z=this.k2.f
if(0>=z.length)return H.f(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isd7)z.sbP(x,this.a0O(this.E,this.U))
J.a8(J.bb(x.gaH()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.f(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isd7)z.sbP(x,this.a0O(this.v,this.U))
J.a8(J.bb(x.gaH()),"text-decoration",this.x1)}else{y.se9(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.f(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isd7){y=this.E
w=J.Q(y,J.ab(J.dn(J.E(this.v,y),J.E(this.fy,1)),v))
z.sbP(x,this.a0O(w,this.U))}J.a8(J.bb(x.gaH()),"text-decoration",this.x1);++v}}this.eC(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.c(this.x2)+"px")},
aZ1:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.dn(J.E(this.fr,this.dy),z-1)
x=P.aB(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.dn(a,2)
x=P.aB(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.E(w,x*(50-u)/100)
u=J.dn(b,2)
x=P.aB(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.E(u,x*(50-w)/100)
r=C.b.L(this.N,"%")&&!0
x=this.N
if(r){H.cz("")
x=H.e_(x,"%","")}q=P.dZ(x,null)
for(x=J.bW(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.f(w,p)
o=w[p]
w=J.Q(J.E(this.dy,90),x.b8(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.Im(o)
w=m.b
u=J.a2(w)
if(u.bE(w,0)){if(r){l=P.aB(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.dn(l,w)}else k=0
l=m.a
j=J.bW(l)
i=J.Q(j.b8(l,l),u.b8(w,w))
if(typeof i!=="number")H.ad(H.by(i))
i=Math.sqrt(i)
h=J.ab(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.a1){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.ab(j.de(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.ab(u.de(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a8(J.bb(o.gaH()),"transform","")
i=J.n(o)
if(!!i.$iscK)i.iy(o,d,c)
else E.ey(o.gaH(),d,c)
i=J.bb(o.gaH())
h=J.M(i)
h.l(i,"transform",J.Q(h.h(i,"transform")," scale ("+H.c(k)+")"))
if(!J.b(this.y1,0))if(!!J.n(o.gaH()).$ismu){i=J.bb(o.gaH())
h=J.M(i)
h.l(i,"transform",J.Q(h.h(i,"transform")," rotate("+H.c(this.y1)+" "+H.c(j.de(l,2))+" "+H.c(J.dn(u.fw(w),2))+")"))}else{J.ki(J.J(o.gaH())," rotate("+H.c(this.y1)+"deg)")
J.nF(J.J(o.gaH()),H.c(J.ab(j.de(l,2),k))+" "+H.c(J.ab(u.de(w,2),k)))}}},
aZ2:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.dn(J.E(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.f(x,0)
w=this.Im(x[0])
v=C.b.L(this.N,"%")&&!0
x=this.N
if(v){H.cz("")
x=H.e_(x,"%","")}u=P.dZ(x,null)
x=w.b
t=J.a2(x)
if(t.bE(x,0))s=J.dn(v?J.dn(J.ab(a,u),200):u,x)
else s=0
r=J.dn(J.ab(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ac(r)))
p=Math.abs(Math.sin(H.ac(r)))
this.aaq(this,J.ab(J.dn(J.Q(J.ab(w.a,q),t.b8(x,p)),2),s))
this.UY()
x=this.k2.f
if(y<0||y>=x.length)return H.f(x,y)
w=this.Im(x[y])
x=w.b
t=J.a2(x)
if(t.bE(x,0))s=J.dn(v?J.dn(J.ab(a,u),200):u,x)
else s=0
this.aar(J.ab(J.dn(J.Q(J.ab(w.a,q),t.b8(x,p)),2),s))
this.UY()
if(!J.b(this.y1,0)){for(x=J.bW(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.f(t,n)
w=this.Im(t[n])
t=w.b
m=J.a2(t)
if(m.bE(t,0))J.dn(v?J.dn(x.b8(a,u),200):u,t)
o=P.aC(J.Q(J.ab(w.a,p),m.b8(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.a2(a)
k=J.dn(J.E(x.A(a,this.O),this.at),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.f(y,n)
j=y[n]
y=this.O
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.Q(y,t)
w=this.Im(j)
y=w.b
m=J.a2(y)
if(m.bE(y,0))s=J.dn(v?J.dn(x.b8(a,u),200):u,y)
else s=0
h=w.a
g=J.a2(h)
i=J.E(i,J.ab(g.de(h,2),s))
J.a8(J.bb(j.gaH()),"transform","")
if(J.b(this.y1,0)){y=J.ab(J.Q(g.b8(h,p),m.b8(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$iscK)y.iy(j,i,f)
else E.ey(j.gaH(),i,f)
y=J.bb(j.gaH())
t=J.M(y)
t.l(y,"transform",J.Q(t.h(y,"transform")," scale ("+H.c(s)+")"))}else{i=J.E(J.Q(this.O,t),g.de(h,2))
t=J.Q(g.b8(h,p),m.b8(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$iscK)t.iy(j,i,e)
else E.ey(j.gaH(),i,e)
d=g.de(h,2)
c=-y/2
y=J.bb(j.gaH())
t=J.M(y)
m=s-1
t.l(y,"transform",J.Q(t.h(y,"transform")," translate("+H.c(J.ab(J.d4(d),m))+" "+H.c(-c*m)+")"))
m=J.bb(j.gaH())
y=J.M(m)
y.l(m,"transform",J.Q(y.h(m,"transform")," scale ("+H.c(s)+")"))
m=J.bb(j.gaH())
y=J.M(m)
y.l(m,"transform",J.Q(y.h(m,"transform")," rotate("+H.c(this.y1)+" "+H.c(d)+" "+H.c(c)+")"))}}},
Im:function(a){var z,y,x,w
if(!!J.n(a.gaH()).$isei){z=H.k(a.gaH(),"$isei").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.b8()
w=x*0.7}else{y=J.d8(a.gaH())
y.toString
w=J.d0(a.gaH())
w.toString}return H.a(new P.H(y,w),[null])},
a0V:[function(){return N.BG()},"$0","gtZ",0,0,3],
a0O:function(a,b){var z=this.Z
if(z==null||J.b(z,""))return U.nt(a,"0")
else return U.nt(a,this.Z)},
a8:[function(){this.aat(0)
this.cC()
var z=this.k2
z.d=!0
z.r=!0
z.se9(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gd7",0,0,0],
aya:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.z(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new N.n8(this.gtZ(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
ID:{"^":"lo;",
gXN:function(){return this.cy},
sTi:["auz",function(a){if(a==null)a=50
if(J.aG(a,0))a=0
if(J.Z(a,100))a=100
if(!J.b(this.db,a)){this.db=a
this.cC()}}],
sTj:["auA",function(a){if(a==null)a=50
if(J.aG(a,0))a=0
if(J.Z(a,100))a=100
if(!J.b(this.dx,a)){this.dx=a
this.cC()}}],
sQh:["auw",function(a){if(J.aG(a,-360))a=-360
if(J.Z(a,360))a=360
if(!J.b(this.dy,a)){this.dy=a
this.dU()
this.cC()}}],
safr:["aux",function(a,b){if(J.aG(b,-360))b=-360
if(J.Z(b,360))b=360
if(!J.b(this.fr,b)){this.fr=b
this.dU()
this.cC()}}],
saTv:function(a){if(a==null||J.aG(a,0))a=0
if(J.Z(a,20))a=20
if(!J.b(this.fx,a)){this.fx=a
this.cC()}},
sa3x:["aat",function(a){if(a==null||J.aG(a,2))a=2
if(J.Z(a,30))a=30
if(!J.b(this.fy,a)){this.fy=a
this.cC()}}],
saTw:function(a){if(this.go!==a){this.go=a
this.cC()}},
saSZ:function(a){if(this.id!==a){this.id=a
this.cC()}},
sTk:["auB",function(a){if(a==null||J.aG(a,0))a=0
if(J.Z(a,200))a=200
if(!J.b(this.k1,a)){this.k1=a
this.cC()}}],
gjT:function(){return this.cy},
f0:["auy",function(a,b,c,d){R.oN(a,b,c,d)}],
eC:["aas",function(a,b){R.td(a,b)}],
zn:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.j(a)
if(y!=="")J.a8(z.gfc(a),"d",y)
else J.a8(z.gfc(a),"d","M 0,0")}},
ahR:{"^":"ID;",
sa3w:["auC",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cC()}}],
saSY:function(a){if(!J.b(this.r2,a)){this.r2=a
this.cC()}},
sqb:["auD",function(a){if(!J.b(this.rx,a)){this.rx=a
this.cC()}}],
sGM:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cC()}},
gpw:function(){return this.x2},
spw:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cC()}},
guj:function(a){return this.y1},
suj:function(a,b){if(!J.b(this.y1,b)){this.y1=b
this.cC()}},
sGS:function(a){if(!J.b(this.y2,a)){this.y2=a
this.cC()}},
sb01:function(a){if(!J.b(this.K,a)){this.K=a
this.cC()}},
saLe:function(a){var z
if(!J.b(this.E,a)){this.E=a
if(a!=null){z=J.E(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.v=z
this.cC()}},
iE:function(a,b){var z,y
this.EI(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.f0(this.k2,this.k4,J.aN(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.f0(this.k3,this.rx,J.aN(this.x1),this.ry)
if(J.b(this.x2,"circular"))this.aN3(a,b)
else this.aN4(a,b)},
aN3:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.dn(J.E(this.fr,this.dy),J.E(J.Q(J.ab(this.fx,J.E(this.fy,1)),this.fy),1))
x=C.b.L(this.go,"%")&&!0
w=this.go
if(x){H.cz("")
w=H.e_(w,"%","")}v=P.dZ(w,null)
if(x){w=P.aB(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aB(a,b)
w=J.dn(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.E(w,t*(50-s)/100)
s=J.dn(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.E(s,t*(50-w)/100)
w=P.aB(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.b(this.K,"center"))o=0.5
else o=J.b(this.K,"outside")?1:0
w=o-1
s=J.bW(y)
n=0
while(!0){m=J.Q(J.ab(this.fx,J.E(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.Q(J.E(this.dy,90),s.b8(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++n}this.zn(this.k3)
z.a=""
y=J.dn(J.E(this.fr,this.dy),J.E(this.fy,1))
h=C.b.L(this.id,"%")&&!0
s=this.id
if(h){H.cz("")
s=H.e_(s,"%","")}g=P.dZ(s,null)
if(h){s=P.aB(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.bW(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.Q(J.E(this.dy,90),s.b8(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++f}this.zn(this.k2)},
aN4:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.b.L(this.go,"%")&&!0
y=this.go
if(z){H.cz("")
y=H.e_(y,"%","")}x=P.dZ(y,null)
w=z?J.dn(J.ab(J.dn(a,2),x),100):x
v=C.b.L(this.id,"%")&&!0
y=this.id
if(v){H.cz("")
y=H.e_(y,"%","")}u=P.dZ(y,null)
t=v?J.dn(J.ab(J.dn(a,2),u),100):u
y=this.cx
y.a=""
s=J.a2(a)
r=J.dn(J.E(s.A(a,this.y1),this.y2),J.E(J.Q(J.ab(this.fx,J.E(this.fy,1)),this.fy),1))
if(J.b(this.K,"center"))q=0.5
else q=J.b(this.K,"outside")?1:0
p=J.a2(t)
o=p.A(t,w)
n=1-q
m=0
while(!0){l=J.Q(J.ab(this.fx,J.E(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.A(t,q*o)
y.a+="M "+H.c(k)+","+H.c(n*o)+" "
y.a+="L "+H.c(k)+","+H.c(j)+" ";++m}this.zn(this.k3)
y.a=""
r=J.dn(J.E(s.A(a,this.y1),this.y2),J.E(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.c(k)+",0 "
y.a+="L "+H.c(k)+","+H.c(t)+" ";++i}this.zn(this.k2)},
a8:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.zn(z)
this.zn(this.k3)}},"$0","gd7",0,0,0]},
ahS:{"^":"ID;",
sTi:function(a){this.auz(a)
this.r2=!0},
sTj:function(a){this.auA(a)
this.r2=!0},
sQh:function(a){this.auw(a)
this.r2=!0},
safr:function(a,b){this.aux(this,b)
this.r2=!0},
sTk:function(a){this.auB(a)
this.r2=!0},
saYQ:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.cC()}},
saYO:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.cC()}},
sa8M:function(a){if(this.x2!==a){this.x2=a
this.dU()
this.cC()}},
gj5:function(){return this.y1},
sj5:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.b(this.y1,a)){this.y1=a
this.r2=!0
this.cC()}},
gpw:function(){return this.y2},
spw:function(a){if(!J.b(this.y2,a)){this.y2=a
this.r2=!0
this.cC()}},
guj:function(a){return this.K},
suj:function(a,b){if(!J.b(this.K,b)){this.K=b
this.r2=!0
this.cC()}},
sGS:function(a){if(!J.b(this.E,a)){this.E=a
this.r2=!0
this.cC()}},
jf:function(){var z,y,x,w,v,u,t,s,r
this.yU()
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.P)(z),++u){t=z[u]
s=J.j(t)
y.push(s.gie(t))
x.push(s.gC4(t))
w.push(s.gto(t))}if(J.iB(J.E(this.dy,this.fr))===!0){z=J.fR(J.E(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.m.G(0.5*z)}else r=0
this.k2=this.aK7(y,w,r)
this.k3=this.aHF(x,w,r)
this.r2=!0},
iE:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.EI(a,b)
z=J.bW(a)
y=J.bW(b)
E.Ey(this.k4,z.b8(a,1),y.b8(b,1))
if(J.b(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aB(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.b(this.y2,"circular")){z=P.aC(0,P.aB(a,b))
this.rx=z
this.aN6(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.c(this.rx)+" "+H.c(this.rx))}else{z=J.ab(J.E(z.A(a,this.K),this.E),1)
y.b8(b,1)
v=C.b.L(this.ry,"%")&&!0
y=this.ry
if(v){H.cz("")
y=H.e_(y,"%","")}u=P.dZ(y,null)
t=v?J.R(J.ab(z,u),100):u
s=C.b.L(this.x1,"%")&&!0
y=this.x1
if(s){H.cz("")
y=H.e_(y,"%","")}r=P.dZ(y,null)
q=s?J.R(J.ab(z,r),100):r
this.r1.se9(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.E(q,t)
p=q
o=p
m=0
break
case"cross":y=J.a0(q)
x=J.a0(t)
o=J.Q(y.de(q,2),x.de(t,2))
n=J.E(y.de(q,2),x.de(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.a(new P.H(this.K,o),[null])
k=H.a(new P.H(this.K,n),[null])
j=H.a(new P.H(J.Q(this.K,z),p),[null])
i=H.a(new P.H(J.Q(this.K,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.f(y,0)
h=y[0]
this.eC(h.gaH(),this.N)
R.oN(h.gaH(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.c(y)+","+H.c(x)+" "
z.a+="L "+H.c(j.a)+","+H.c(j.b)+" "
z.a+="L "+H.c(i.a)+","+H.c(i.b)+" "
z.a+="L "+H.c(k.a)+","+H.c(k.b)+" "
z.a+="L "+H.c(y)+","+H.c(x)+" "
this.zn(h.gaH())
x=this.cy
x.toString
new W.de(x).M(0,"viewBox")}},
aK7:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.xh(J.ab(J.E(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.f(a,y)
t=J.b0(J.cO(a[y],16),255)
if(y>=a.length)return H.f(a,y)
s=J.b0(J.cO(a[y],8),255)
if(y>=a.length)return H.f(a,y)
r=J.b0(a[y],255)
if(x>=a.length)return H.f(a,x)
q=J.b0(J.cO(a[x],16),255)
if(x>=a.length)return H.f(a,x)
p=J.b0(J.cO(a[x],8),255)
if(x>=a.length)return H.f(a,x)
o=J.b0(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.c.G(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.c.G(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.c.G(w*r+m*o)&255)>>>0)}}return z},
aHF:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.xh(J.ab(J.E(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.f(a,x)
v=a[x]
if(y>=w)return H.f(a,y)
t=J.R(J.E(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.f(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.Q(w,s*t))}}return z},
aN6:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aB(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.b.L(this.ry,"%")&&!0
z=this.ry
if(v){H.cz("")
z=H.e_(z,"%","")}u=P.dZ(z,new N.ahT())
if(v){z=P.aB(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.b.L(this.x1,"%")&&!0
z=this.x1
if(s){H.cz("")
z=H.e_(z,"%","")}r=P.dZ(z,new N.ahU())
if(s){z=P.aB(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aB(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aB(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.se9(0,w)
for(z=J.a2(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.E(this.dy,90)
d=J.E(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.Q(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.A(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.f(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.f(e,d)
g=J.bw(J.ab(e[d],255))
g=J.bP(J.b(g,0)?1:g,24)
e=h.gaH()
a3=this.k2
if(d>=a3.length)return H.f(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.eC(e,a3+g)
a3=h.gaH()
e=this.k2
if(d>=e.length)return H.f(e,d)
R.oN(a3,e[d]+g,1,"solid")
y.a+="M "+H.c(l)+","+H.c(k)+" "
y.a+="L "+H.c(a)+","+H.c(a0)+" "
y.a+="L "+H.c(a1)+","+H.c(a2)+" "
y.a+="L "+H.c(j)+","+H.c(i)+" "
y.a+="L "+H.c(l)+","+H.c(k)+" "
this.zn(h.gaH())}}},
bdK:[function(){var z,y
z=new N.a40(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gaYG",0,0,3],
a8:["auE",function(){var z=this.r1
z.d=!0
z.r=!0
z.se9(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gd7",0,0,0],
ayb:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sa8M([new N.ws(65280,0.5,0),new N.ws(16776960,0.8,0.5),new N.ws(16711680,1,1)])
z=new N.n8(this.gaYG(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
ahT:{"^":"d:0;",
$1:function(a){return 0}},
ahU:{"^":"d:0;",
$1:function(a){return 0}},
ws:{"^":"r;ie:a*,C4:b>,to:c>"}}],["","",,L,{"^":"",
bC_:[function(a){var z=!!J.n(a.gli().gaH()).$isfM?H.k(a.gli().gaH(),"$isfM"):null
if(z!=null)if(z.gnR()!=null&&!J.b(z.gnR(),""))return L.T4(a.gli(),z.gnR())
else return z.G9(a)
return""},"$1","aZg",2,0,8,50],
bs1:function(){if($.Pv)return
$.Pv=!0
$.$get$hC().l(0,"percentTextSize",L.aZj())
$.$get$hC().l(0,"minorTicksPercentLength",L.ab0())
$.$get$hC().l(0,"majorTicksPercentLength",L.ab0())
$.$get$hC().l(0,"percentStartThickness",L.ab2())
$.$get$hC().l(0,"percentEndThickness",L.ab2())
$.$get$hD().l(0,"percentTextSize",L.aZk())
$.$get$hD().l(0,"minorTicksPercentLength",L.ab1())
$.$get$hD().l(0,"majorTicksPercentLength",L.ab1())
$.$get$hD().l(0,"percentStartThickness",L.ab3())
$.$get$hD().l(0,"percentEndThickness",L.ab3())},
aZe:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$fj())
C.a.q(z,$.$get$BW())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$fj())
C.a.q(z,$.$get$CW())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$fj())
C.a.q(z,$.$get$CU())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$fj())
C.a.q(z,$.$get$Kw())
return z
case"linearAxis":return $.$get$vo()
case"logAxis":return $.$get$vq()
case"categoryAxis":return $.$get$rZ()
case"datetimeAxis":return $.$get$vd()
case"axisRenderer":return $.$get$rU()
case"radialAxisRenderer":return $.$get$Kp()
case"angularAxisRenderer":return $.$get$IN()
case"linearAxisRenderer":return $.$get$rU()
case"logAxisRenderer":return $.$get$rU()
case"categoryAxisRenderer":return $.$get$rU()
case"datetimeAxisRenderer":return $.$get$rU()
case"lineSeries":return $.$get$vm()
case"areaSeries":return $.$get$BC()
case"columnSeries":return $.$get$BZ()
case"barSeries":return $.$get$BK()
case"bubbleSeries":return $.$get$BR()
case"pieSeries":return $.$get$y8()
case"spectrumSeries":return $.$get$KL()
case"radarSeries":return $.$get$ya()
case"lineSet":return $.$get$q8()
case"areaSet":return $.$get$BE()
case"columnSet":return $.$get$C0()
case"barSet":return $.$get$BM()
case"gridlines":return $.$get$JE()}return[]},
aZc:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof L.oG)return a
else{z=$.$get$Ui()
y=H.a([],[N.eC])
x=H.a([],[E.jc])
w=H.a([],[L.iK])
v=H.a([],[E.jc])
u=H.a([],[L.iK])
t=H.a([],[E.jc])
s=H.a([],[L.xG])
r=H.a([],[E.jc])
q=H.a([],[L.yb])
p=H.a([],[E.jc])
o=$.$get$av()
n=$.X+1
$.X=n
n=new L.oG(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ay(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.O(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
n.c3(b,"chart")
J.a1(J.z(n.b),"absolute")
o=L.ajS()
n.w=o
J.bt(n.b,o.cx)
o=n.w
o.bj=n
o.Nt()
o=L.aha()
n.T=o
o.scU(n.w)
return n}case"scaleTicks":if(a instanceof L.CV)return a
else{z=$.$get$Xz()
y=$.$get$av()
x=$.X+1
$.X=x
x=new L.CV(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ay(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.O(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c3(b,"scale-ticks")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.c_])),[P.r,E.c_])
z=new L.ak6(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.cy=P.hF()
x.w=z
J.bt(x.b,z.gXN())
return x}case"scaleLabels":if(a instanceof L.CT)return a
else{z=$.$get$Xx()
y=$.$get$av()
x=$.X+1
$.X=x
x=new L.CT(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ay(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.O(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c3(b,"scale-labels")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.c_])),[P.r,E.c_])
z=new L.ak4(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.cy=P.hF()
z.aya()
x.w=z
J.bt(x.b,z.gXN())
x.w.se0(x)
return x}case"scaleTrack":if(a instanceof L.CX)return a
else{z=$.$get$XB()
y=$.$get$av()
x=$.X+1
$.X=x
x=new L.CX(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ay(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.O(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c3(b,"scale-track")
J.a1(J.z(x.b),"absolute")
J.m_(J.J(x.b),"hidden")
y=L.ak8()
x.w=y
J.bt(x.b,y.gXN())
return x}}return},
bCu:[function(){var z=new L.alf(null,null,null)
z.abl()
return z},"$0","aZh",0,0,3],
ajS:function(){var z,y,x,w,v,u,t
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.c_])),[P.r,E.c_])
y=P.bg(0,0,0,0,null)
x=P.bg(0,0,0,0,null)
w=new N.cI(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.a([],[P.fm])
t=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,P.r])),[P.e,P.r])
z=new L.nM(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",N.aZl(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.ay8("chartBase")
z.ay6()
z.ayT()
z.sRs("single")
z.ayl()
return z},
bIG:[function(a,b,c){return L.aXW(a,c)},"$3","aZj",6,0,1,15,32,1],
aXW:function(a,b){var z,y,x
z=a.I("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
return J.R(J.ab(J.b(y.gpw(),"circular")?P.aB(x.gbc(y),x.gbx(y)):x.gbc(y),b),200)},
bIH:[function(a,b,c){return L.aXX(a,c)},"$3","aZk",6,0,1,15,32,1],
aXX:function(a,b){var z,y,x,w
z=a.I("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.ab(b,200)
w=J.j(y)
return J.R(x,J.b(y.gpw(),"circular")?P.aB(w.gbc(y),w.gbx(y)):w.gbc(y))},
bII:[function(a,b,c){return L.aXY(a,c)},"$3","ab0",6,0,1,15,32,1],
aXY:function(a,b){var z,y,x
z=a.I("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
return J.R(J.ab(J.b(y.gpw(),"circular")?P.aB(x.gbc(y),x.gbx(y)):x.gbc(y),b),200)},
bIJ:[function(a,b,c){return L.aXZ(a,c)},"$3","ab1",6,0,1,15,32,1],
aXZ:function(a,b){var z,y,x,w
z=a.I("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.ab(b,200)
w=J.j(y)
return J.R(x,J.b(y.gpw(),"circular")?P.aB(w.gbc(y),w.gbx(y)):w.gbc(y))},
bIK:[function(a,b,c){return L.aY_(a,c)},"$3","ab2",6,0,1,15,32,1],
aY_:function(a,b){var z,y,x
z=a.I("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
if(J.b(y.gpw(),"circular")){x=P.aB(x.gbc(y),x.gbx(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.R(J.ab(x.gbc(y),b),100)
return x},
bIL:[function(a,b,c){return L.aY0(a,c)},"$3","ab3",6,0,1,15,32,1],
aY0:function(a,b){var z,y,x,w
z=a.I("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
w=J.bW(b)
return J.b(y.gpw(),"circular")?J.R(w.b8(b,200),P.aB(x.gbc(y),x.gbx(y))):J.R(w.b8(b,100),x.gbc(y))},
alf:{"^":"L4;a,b,c",
sbP:function(a,b){var z,y,x,w,v
if(J.b(this.b,b))return
this.avk(this,b)
if(b instanceof N.kZ){z=b.e
if(z.gaH() instanceof N.eC&&H.k(z.gaH(),"$iseC").K!=null){J.lf(J.J(this.a),"")
return}y=K.bR(b.r,"fault")
if(y==="fault"&&b.r instanceof F.v){x=b.r
if(J.b(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof F.eh&&J.Z(w.ry,0)){z=H.k(w.cD(0),"$isjt")
y=K.fb(z.gie(z),null,"rgba(0,0,0,0)")}}}v=H.c(y==="fault"?K.fb(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.lf(J.J(this.a),v)}}},
ak4:{"^":"ahQ;af,a7,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,E,v,N,U,V,Z,W,F,a1,O,at,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sq9:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cJ(this.gdu())
this.auv(a)
if(a instanceof F.v)a.dj(this.gdu())},
suj:function(a,b){this.aaq(this,b)
this.UY()},
sGS:function(a){this.aar(a)
this.UY()},
ge0:function(){return this.a7},
se0:function(a){H.k(a,"$isaM")
this.a7=a
if(a!=null)F.cj(this.gb1s())},
eC:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.aas(a,b)
return}if(!!J.n(a).$isb2){z=this.af.a
if(!z.R(0,a))z.l(0,a,new E.c_(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jm(b)}},
od:[function(a){this.cC()},"$1","gdu",2,0,2,11],
UY:[function(){var z=this.a7
if(z!=null)if(z.a instanceof F.v)F.aa(new L.ak5(this))},"$0","gb1s",0,0,0]},
ak5:{"^":"d:3;a",
$0:[function(){var z=this.a
z.a7.a.bm("offsetLeft",z.O)
z.a7.a.bm("offsetRight",z.at)},null,null,0,0,null,"call"]},
CT:{"^":"aCw;aX,dB:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bS,c_,c4,by,bX,bW,c0,c5,c8,bZ,bK,cc,cH,cr,cs,ct,cm,cu,cv,cE,cd,co,cp,ca,c9,cI,cj,cw,cz,bM,cb,cf,cA,cF,ck,cn,cK,cW,cG,cq,cL,cM,cR,cg,cN,cO,cl,cP,cT,cQ,E,v,N,U,V,Z,W,F,a1,O,at,af,a7,ac,ae,al,as,aa,aK,aP,aT,ai,aL,aC,aE,am,ao,aF,aQ,aw,aY,b2,b5,bf,ba,b9,b_,b0,bn,aW,bh,aV,bF,bv,bi,bg,bl,aU,bI,bs,be,bp,bN,bA,bq,bQ,bG,bV,bC,bO,bD,br,bb,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdn:function(){return this.aX},
sf2:function(a,b){if(J.b(this.F,"none")&&!J.b(b,"none")){this.ly(this,b)
this.e3()}else this.ly(this,b)},
hH:[function(a){this.mM(a)
this.sig(!0)},"$1","gfq",2,0,2,11],
tj:[function(a){this.wc()},"$0","gmD",0,0,0],
a8:[function(){this.sig(!1)
this.ft()
this.w.sGF(!0)
this.w.a8()
this.w.sq9(null)
this.w.sGF(!1)},"$0","gd7",0,0,0],
hX:[function(){this.sig(!1)
this.ft()},"$0","gkq",0,0,0],
fQ:function(){this.Bv()
this.sig(!0)},
wc:function(){if(this.a instanceof F.v)this.w.ib(J.d8(this.b),J.d0(this.b))},
e3:function(){var z,y
this.yV()
this.so1(-1)
z=this.w
y=J.j(z)
y.sbc(z,J.E(y.gbc(z),1))},
$isbT:1,
$isbU:1,
$iscJ:1},
aCw:{"^":"aM+nc;o1:x$?,ua:y$?",$iscJ:1},
bba:{"^":"d:37;",
$2:[function(a,b){a.gdB().spw(K.az(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bbb:{"^":"d:37;",
$2:[function(a,b){J.HV(a.gdB(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bbc:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGS(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bbd:{"^":"d:37;",
$2:[function(a,b){a.gdB().sij(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bbe:{"^":"d:37;",
$2:[function(a,b){a.gdB().siP(K.aV(b,100))},null,null,4,0,null,0,2,"call"]},
bbf:{"^":"d:37;",
$2:[function(a,b){a.gdB().svw(K.I(b,""))},null,null,4,0,null,0,2,"call"]},
bbh:{"^":"d:37;",
$2:[function(a,b){a.gdB().sasY(K.a_(b,!1))},null,null,4,0,null,0,2,"call"]},
bbi:{"^":"d:37;",
$2:[function(a,b){a.gdB().saYR(K.kF(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bbj:{"^":"d:37;",
$2:[function(a,b){a.gdB().sq9(R.cG(b,16777215))},null,null,4,0,null,0,2,"call"]},
bbk:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGu(K.I(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bbl:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGv(K.az(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bbm:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGw(K.az(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bbn:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGy(K.az(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bbo:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGx(K.aj(b,0))},null,null,4,0,null,0,2,"call"]},
bbp:{"^":"d:37;",
$2:[function(a,b){a.gdB().saRY(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bbq:{"^":"d:37;",
$2:[function(a,b){a.gdB().saRX(K.az(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bbs:{"^":"d:37;",
$2:[function(a,b){a.gdB().sQh(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bbt:{"^":"d:37;",
$2:[function(a,b){J.HI(a.gdB(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bbu:{"^":"d:37;",
$2:[function(a,b){a.gdB().sTi(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bbv:{"^":"d:37;",
$2:[function(a,b){a.gdB().sTj(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bbw:{"^":"d:37;",
$2:[function(a,b){a.gdB().sTk(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
bbx:{"^":"d:37;",
$2:[function(a,b){a.gdB().sa3x(K.aj(b,11))},null,null,4,0,null,0,2,"call"]},
bby:{"^":"d:37;",
$2:[function(a,b){a.gdB().saRN(K.az(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
ak6:{"^":"ahR;N,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,E,v,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sqb:function(a){var z=this.rx
if(z instanceof F.v)H.k(z,"$isv").cJ(this.gdu())
this.auD(a)
if(a instanceof F.v)a.dj(this.gdu())},
sa3w:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cJ(this.gdu())
this.auC(a)
if(a instanceof F.v)a.dj(this.gdu())},
f0:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.N.a
if(z.R(0,a))z.h(0,a).jy(null)
this.auy(a,b,c,d)
return}if(!!J.n(a).$isb2){z=this.N.a
if(!z.R(0,a))z.l(0,a,new E.c_(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jy(b)
y.skS(c)
y.skB(d)}},
od:[function(a){this.cC()},"$1","gdu",2,0,2,11]},
CV:{"^":"aCx;aX,dB:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bS,c_,c4,by,bX,bW,c0,c5,c8,bZ,bK,cc,cH,cr,cs,ct,cm,cu,cv,cE,cd,co,cp,ca,c9,cI,cj,cw,cz,bM,cb,cf,cA,cF,ck,cn,cK,cW,cG,cq,cL,cM,cR,cg,cN,cO,cl,cP,cT,cQ,E,v,N,U,V,Z,W,F,a1,O,at,af,a7,ac,ae,al,as,aa,aK,aP,aT,ai,aL,aC,aE,am,ao,aF,aQ,aw,aY,b2,b5,bf,ba,b9,b_,b0,bn,aW,bh,aV,bF,bv,bi,bg,bl,aU,bI,bs,be,bp,bN,bA,bq,bQ,bG,bV,bC,bO,bD,br,bb,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdn:function(){return this.aX},
sf2:function(a,b){if(J.b(this.F,"none")&&!J.b(b,"none")){this.ly(this,b)
this.e3()}else this.ly(this,b)},
hH:[function(a){this.mM(a)
this.sig(!0)
if(a==null)this.w.ib(J.d8(this.b),J.d0(this.b))},"$1","gfq",2,0,2,11],
tj:[function(a){this.w.ib(J.d8(this.b),J.d0(this.b))},"$0","gmD",0,0,0],
a8:[function(){this.sig(!1)
this.ft()
this.w.sGF(!0)
this.w.a8()
this.w.sqb(null)
this.w.sa3w(null)
this.w.sGF(!1)},"$0","gd7",0,0,0],
hX:[function(){this.sig(!1)
this.ft()},"$0","gkq",0,0,0],
fQ:function(){this.Bv()
this.sig(!0)},
e3:function(){var z,y
this.yV()
this.so1(-1)
z=this.w
y=J.j(z)
y.sbc(z,J.E(y.gbc(z),1))},
wc:function(){this.w.ib(J.d8(this.b),J.d0(this.b))},
$isbT:1,
$isbU:1},
aCx:{"^":"aM+nc;o1:x$?,ua:y$?",$iscJ:1},
bbz:{"^":"d:46;",
$2:[function(a,b){a.gdB().spw(K.az(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bbA:{"^":"d:46;",
$2:[function(a,b){a.gdB().sb01(K.az(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bbB:{"^":"d:46;",
$2:[function(a,b){J.HV(a.gdB(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bbD:{"^":"d:46;",
$2:[function(a,b){a.gdB().sGS(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bbE:{"^":"d:46;",
$2:[function(a,b){a.gdB().sa3w(R.cG(b,16777215))},null,null,4,0,null,0,2,"call"]},
bbF:{"^":"d:46;",
$2:[function(a,b){a.gdB().saSY(K.aj(b,1))},null,null,4,0,null,0,2,"call"]},
bbG:{"^":"d:46;",
$2:[function(a,b){a.gdB().sqb(R.cG(b,16777215))},null,null,4,0,null,0,2,"call"]},
bbH:{"^":"d:46;",
$2:[function(a,b){a.gdB().sGM(K.aj(b,1))},null,null,4,0,null,0,2,"call"]},
bbI:{"^":"d:46;",
$2:[function(a,b){a.gdB().sQh(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bbJ:{"^":"d:46;",
$2:[function(a,b){J.HI(a.gdB(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bbK:{"^":"d:46;",
$2:[function(a,b){a.gdB().sTi(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bbL:{"^":"d:46;",
$2:[function(a,b){a.gdB().sTj(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bbM:{"^":"d:46;",
$2:[function(a,b){a.gdB().sTk(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
bbO:{"^":"d:46;",
$2:[function(a,b){a.gdB().sa3x(K.aj(b,11))},null,null,4,0,null,0,2,"call"]},
bbP:{"^":"d:46;",
$2:[function(a,b){a.gdB().saSZ(K.kF(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bbQ:{"^":"d:46;",
$2:[function(a,b){a.gdB().saTv(K.aj(b,2))},null,null,4,0,null,0,2,"call"]},
bbR:{"^":"d:46;",
$2:[function(a,b){a.gdB().saTw(K.kF(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bbS:{"^":"d:46;",
$2:[function(a,b){a.gdB().saLe(K.aV(b,null))},null,null,4,0,null,0,2,"call"]},
ak7:{"^":"ahS;v,N,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,E,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gjS:function(){return this.N},
sjS:function(a){var z=this.N
if(z!=null)z.cJ(this.ga6M())
this.N=a
if(a!=null)a.dj(this.ga6M())
this.b1a(null)},
b1a:[function(a){var z,y,x,w,v,u,t,s
z=this.N
if(z==null){y=H.a([],[F.o])
x=$.G+1
$.G=x
w=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
z=new F.eh(!1,y,0,null,null,x,null,w,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.O(null,null,null,{func:1,v:true,args:[[P.L,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
z.ch=null
z.fI(F.hO(new F.du(0,255,0,1),0,0))
z.fI(F.hO(new F.du(0,0,0,1),0,50))}v=J.hL(z)
y=J.bc(v)
y.eu(v,F.ri())
u=[]
if(J.Z(y.gm(v),1))for(y=y.gb7(v);y.u();){t=y.gD()
x=J.j(t)
w=x.gie(t)
s=H.dw(t.i("alpha"))
s.toString
u.push(new N.ws(w,s,J.R(x.gto(t),100)))}else if(J.b(y.gm(v),1)){t=y.h(v,0)
y=J.j(t)
x=y.gie(t)
w=H.dw(t.i("alpha"))
w.toString
u.push(new N.ws(x,w,0))
y=y.gie(t)
w=H.dw(t.i("alpha"))
w.toString
u.push(new N.ws(y,w,1))}this.sa8M(u)},"$1","ga6M",2,0,5,11],
eC:function(a,b){var z,y,x,w
if(typeof b==="number"&&Math.floor(b)===b){this.aas(a,b)
return}if(!!J.n(a).$isb2){z=this.v.a
if(!z.R(0,a))z.l(0,a,new E.c_(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
z=$.G+1
$.G=z
x=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
w=new F.v(z,null,x,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.O(null,null,null,{func:1,v:true,args:[[P.L,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
w.B("fillType",!0).Y("gradient")
w.B("gradient",!0).$2(b,!1)
w.B("gradientType",!0).Y("linear")
y.jm(w)}},
a8:[function(){var z=this.N
if(z!=null){z.cJ(this.ga6M())
this.N=null}this.auE()},"$0","gd7",0,0,0],
aym:function(){var z=$.$get$BX()
if(J.b(z.ry,0)){z.fI(F.hO(new F.du(0,255,0,1),1,0))
z.fI(F.hO(new F.du(255,255,0,1),1,50))
z.fI(F.hO(new F.du(255,0,0,1),1,100))}},
ag:{
ak8:function(){var z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.c_])),[P.r,E.c_])
z=new L.ak7(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.cy=P.hF()
z.ayb()
z.aym()
return z}}},
CX:{"^":"aCy;aX,dB:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bS,c_,c4,by,bX,bW,c0,c5,c8,bZ,bK,cc,cH,cr,cs,ct,cm,cu,cv,cE,cd,co,cp,ca,c9,cI,cj,cw,cz,bM,cb,cf,cA,cF,ck,cn,cK,cW,cG,cq,cL,cM,cR,cg,cN,cO,cl,cP,cT,cQ,E,v,N,U,V,Z,W,F,a1,O,at,af,a7,ac,ae,al,as,aa,aK,aP,aT,ai,aL,aC,aE,am,ao,aF,aQ,aw,aY,b2,b5,bf,ba,b9,b_,b0,bn,aW,bh,aV,bF,bv,bi,bg,bl,aU,bI,bs,be,bp,bN,bA,bq,bQ,bG,bV,bC,bO,bD,br,bb,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdn:function(){return this.aX},
sf2:function(a,b){if(J.b(this.F,"none")&&!J.b(b,"none")){this.ly(this,b)
this.e3()}else this.ly(this,b)},
hH:[function(a){this.mM(a)
this.sig(!0)},"$1","gfq",2,0,2,11],
tj:[function(a){this.wc()},"$0","gmD",0,0,0],
a8:[function(){this.sig(!1)
this.ft()
this.w.sGF(!0)
this.w.a8()
this.w.sjS(null)
this.w.sGF(!1)},"$0","gd7",0,0,0],
hX:[function(){this.sig(!1)
this.ft()},"$0","gkq",0,0,0],
fQ:function(){this.Bv()
this.sig(!0)},
e3:function(){var z,y
this.yV()
this.so1(-1)
z=this.w
y=J.j(z)
y.sbc(z,J.E(y.gbc(z),1))},
wc:function(){if(this.a instanceof F.v)this.w.ib(J.d8(this.b),J.d0(this.b))},
$isbT:1,
$isbU:1},
aCy:{"^":"aM+nc;o1:x$?,ua:y$?",$iscJ:1},
baY:{"^":"d:72;",
$2:[function(a,b){a.gdB().spw(K.az(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
baZ:{"^":"d:72;",
$2:[function(a,b){J.HV(a.gdB(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bb_:{"^":"d:72;",
$2:[function(a,b){a.gdB().sGS(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bb0:{"^":"d:72;",
$2:[function(a,b){a.gdB().saYQ(K.kF(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bb1:{"^":"d:72;",
$2:[function(a,b){a.gdB().saYO(K.kF(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bb2:{"^":"d:72;",
$2:[function(a,b){a.gdB().sj5(K.az(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bb3:{"^":"d:72;",
$2:[function(a,b){var z=a.gdB()
z.sjS(b!=null?F.pq(b):$.$get$BX())},null,null,4,0,null,0,2,"call"]},
bb4:{"^":"d:72;",
$2:[function(a,b){a.gdB().sQh(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bb6:{"^":"d:72;",
$2:[function(a,b){J.HI(a.gdB(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bb7:{"^":"d:72;",
$2:[function(a,b){a.gdB().sTi(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bb8:{"^":"d:72;",
$2:[function(a,b){a.gdB().sTj(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bb9:{"^":"d:72;",
$2:[function(a,b){a.gdB().sTk(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
xz:{"^":"r;a7N:a@,ij:b@,iP:c@"},
ah9:{"^":"lo;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,c,d,e,f,r,x,y,z,Q,ch,a,b",
gpW:function(){return this.r1},
spW:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cC()}},
gcU:function(){return this.r2},
scU:function(a){this.aZD(a)},
gjT:function(){return this.go},
iE:function(a,b){var z,y,x,w
this.EI(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.hF()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.c(a)+"px"
z.width=y
z=this.id.style
y=H.c(b)+"px"
z.height=y
this.f0(this.k1,0,0,"none")
this.eC(this.k1,this.r2.cc)
z=this.k2
y=this.r2
this.f0(z,y.c8,J.aN(y.bZ),this.r2.bK)
y=this.k3
z=this.r2
this.f0(y,z.c8,J.aN(z.bZ),this.r2.bK)
z=this.db
if(z===2){z=J.Z(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a6(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aA(a))
y=this.k1
y.toString
y.setAttribute("height",J.a6(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a6(J.Q(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aA(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.c.aA(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.c(this.cy.b)+" L "+H.c(a)+","+H.c(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.c(J.Q(this.cy.b,this.r1.b))+" L "+H.c(a)+","+H.c(J.Q(this.cy.b,this.r1.b)))}else if(z===1){z=J.Z(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a6(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a6(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aA(b))}else{x.toString
x.setAttribute("x",J.a6(J.Q(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.c.aA(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aA(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.c(this.cy.a)+",0 L "+H.c(this.cy.a)+","+H.c(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.c(J.Q(this.cy.a,this.r1.a))+",0 L "+H.c(J.Q(this.cy.a,this.r1.a))+","+H.c(b))}else if(z===3){z=J.Z(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a6(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a6(this.r1.a))}else{y.toString
y.setAttribute("x",J.a6(J.Q(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.c.aA(0-y))}z=J.Z(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a6(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a6(this.r1.b))}else{y.toString
y.setAttribute("y",J.a6(J.Q(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.c.aA(0-y))}z=this.k1
y=this.r2
this.f0(z,y.c8,J.aN(y.bZ),this.r2.bK)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
aZD:function(a){var z
this.a5X()
this.a5Y()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().H(0)
this.r2.qt(0,"CartesianChartZoomerReset",this.gaiS())}this.r2=a
if(a!=null){z=J.cE(a.cx)
z=H.a(new W.C(0,z.a,z.b,W.B(this.gaJg()),z.c),[H.x(z,0)])
z.t()
this.fx.push(z)
this.r2.nM(0,"CartesianChartZoomerReset",this.gaiS())}this.dx=null
this.dy=null},
Kq:function(a){var z,y,x,w,v
z=this.Ia(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.P)(z),++x){v=J.n(z[x])
if(!(!!v.$isqK||!!v.$ishV||!!v.$isiO))return!1}return!0},
aqU:function(a){var z=J.n(a)
if(!!z.$isiO)return J.b5(a.db)?null:a.db
else if(!!z.$isqN)return a.db
return 0/0},
Ww:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiO){if(b==null)z=null
else{z=J.bw(b)
y=!a.al
x=new P.ai(z,y)
x.ey(z,y)
z=x}a.sij(z)}else if(!!z.$ishV)a.sij(b)
else if(!!z.$isqK)a.sij(b)},
asB:function(a,b){return this.Ww(a,b,!1)},
aqS:function(a){var z=J.n(a)
if(!!z.$isiO)return J.b5(a.cy)?null:a.cy
else if(!!z.$isqN)return a.cy
return 0/0},
Wv:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiO){if(b==null)z=null
else{z=J.bw(b)
y=!a.al
x=new P.ai(z,y)
x.ey(z,y)
z=x}a.siP(z)}else if(!!z.$ishV)a.siP(b)
else if(!!z.$isqK)a.siP(b)},
asA:function(a,b){return this.Wv(a,b,!1)},
a7I:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[N.e2,L.xz])),[N.e2,L.xz])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[N.e2,L.xz])),[N.e2,L.xz])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.Ia(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.P)(v),++u){t=v[u]
s=x.a
if(!s.R(0,t)){r=J.n(t)
r=!!r.$isqK||!!r.$ishV||!!r.$isiO}else r=!1
if(r)s.l(0,t,new L.xz(!1,this.aqU(t),this.aqS(t)))}}y=this.cy
if(z){y=y.b
q=P.aC(y,J.Q(y,b))
y=this.cy.b
p=P.aB(y,J.Q(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aC(y,J.Q(y,b))
y=this.cy.a
m=P.aB(y,J.Q(y,b))
o="h"
q=null
p=null}l=[]
k=N.jz(this.r2.aa,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof N.jO))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.as:f.al
r=J.n(h)
if(!(!!r.$isqK||!!r.$ishV||!!r.$isiO)){g=f
break c$0}if(J.bH(C.a.cS(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=Q.b7(y,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.au(f.gcU()),e).b)
if(typeof q!=="number")return q.A()
y=H.a(new P.H(0,q-y),[null])
y=f.fr.p4([J.E(y.a,C.c.G(f.cy.offsetLeft)),J.E(y.b,C.c.G(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
j=y[1]
e=Q.b7(f.cy,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.au(f.gcU()),e).b)
if(typeof p!=="number")return p.A()
y=H.a(new P.H(0,p-y),[null])
y=f.fr.p4([J.E(y.a,C.c.G(f.cy.offsetLeft)),J.E(y.b,C.c.G(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
i=y[1]}else{e=Q.b7(y,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.au(f.gcU()),e).a)
if(typeof m!=="number")return m.A()
y=H.a(new P.H(m-y,0),[null])
y=f.fr.p4([J.E(y.a,C.c.G(f.cy.offsetLeft)),J.E(y.b,C.c.G(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
j=y[0]
e=Q.b7(f.cy,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.au(f.gcU()),e).a)
if(typeof n!=="number")return n.A()
y=H.a(new P.H(n-y,0),[null])
y=f.fr.p4([J.E(y.a,C.c.G(f.cy.offsetLeft)),J.E(y.b,C.c.G(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
i=y[0]}if(J.aG(i,j)){d=i
i=j
j=d}this.asB(h,j)
this.asA(h,i)
this.fr=!0
break}k.length===y||(0,H.P)(k);++u}if(!this.fr)return
x.a.h(0,h).sa7N(!0)
if(h!=null&&!c){y=this.r2
if(z){y.c0=j
y.c5=i
y.apz()}else{y.by=j
y.bX=i
y.aoX()}}},
aq5:function(a,b){return this.a7I(a,b,!1)},
anv:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.Ia(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.P)(y),++u){t=y[u]
if(w.R(0,t)){this.Ww(t,w.h(0,t).gij(),!0)
this.Wv(t,w.h(0,t).giP(),!0)
if(w.h(0,t).ga7N())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.by=0/0
x.bX=0/0
x.aoX()}},
a5X:function(){return this.anv(!1)},
anz:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.Ia(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.P)(y),++u){t=y[u]
if(w.R(0,t)){this.Ww(t,w.h(0,t).gij(),!0)
this.Wv(t,w.h(0,t).giP(),!0)
if(w.h(0,t).ga7N())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.c0=0/0
x.c5=0/0
x.apz()}},
a5Y:function(){return this.anz(!1)},
aq6:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.a2(a)
if(z.gjK(a)||J.b5(b)){if(this.fr)if(c)this.anz(!0)
else this.anv(!0)
return}if(!this.Kq(c))return
y=this.Ia(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.ard(x)
if(w==null)return
v=J.n(b)
if(c){u=J.Q(w.FS(["0",z.aA(a)]).b,this.a8K(w))
t=J.Q(w.FS(["0",v.aA(b)]).b,this.a8K(w))
this.cy=H.a(new P.H(50,u),[null])
this.a7I(2,J.E(t,u),!0)}else{s=J.Q(w.FS([z.aA(a),"0"]).a,this.a8J(w))
r=J.Q(w.FS([v.aA(b),"0"]).a,this.a8J(w))
this.cy=H.a(new P.H(s,50),[null])
this.a7I(1,J.E(r,s),!0)}},
Ia:function(a){var z,y,x,w,v,u,t
z=[]
y=N.jz(this.r2.aa,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.P)(y),++v){u=y[v]
if(!(u instanceof N.jO))continue
if(a){t=u.as
if(t!=null&&J.aG(C.a.cS(z,t),0))z.push(u.as)}else{t=u.al
if(t!=null&&J.aG(C.a.cS(z,t),0))z.push(u.al)}w=u}return z},
ard:function(a){var z,y,x,w,v
z=N.jz(this.r2.aa,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.P)(z),++w){v=z[w]
if(!(v instanceof N.jO))continue
if(J.b(v.as,a)||J.b(v.al,a))return v
x=v}return},
a8J:function(a){var z=Q.b7(a.cy,H.a(new P.H(0,0),[null]))
return J.aN(Q.aP(J.au(a.gcU()),z).a)},
a8K:function(a){var z=Q.b7(a.cy,H.a(new P.H(0,0),[null]))
return J.aN(Q.aP(J.au(a.gcU()),z).b)},
f0:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.R(0,a))z.h(0,a).jy(null)
R.oN(a,b,c,d)
return}if(!!J.n(a).$isb2){z=this.k4.a
if(!z.R(0,a))z.l(0,a,new E.c_(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jy(b)
y.skS(c)
y.skB(d)}},
eC:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.R(0,a))z.h(0,a).jm(null)
R.td(a,b)
return}if(!!J.n(a).$isb2){z=this.k4.a
if(!z.R(0,a))z.l(0,a,new E.c_(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jm(b)}},
b6O:[function(a){var z,y
z=this.r2
if(!z.c_&&!z.bW)return
z.cx.appendChild(this.go)
z=this.r2
this.ib(z.Q,z.ch)
this.cy=Q.aP(this.go,J.cF(a))
this.cx=!0
z=this.fy
y=C.C.d_(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.garw()),y.c),[H.x(y,0)])
y.t()
z.push(y)
y=C.E.d_(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.garx()),y.c),[H.x(y,0)])
y.t()
z.push(y)
y=C.a2.d_(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gGe()),y.c),[H.x(y,0)])
y.t()
z.push(y)
this.db=0
this.spW(null)},"$1","gaJg",2,0,4,4],
b3p:[function(a){var z,y
z=Q.aP(this.go,J.cF(a))
if(this.db===0)if(this.r2.c4){if(!(this.Kq(!0)&&this.Kq(!1))){this.FI()
return}if(J.bH(J.fR(J.E(z.a,this.cy.a)),2)&&J.bH(J.fR(J.E(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.Z(J.fR(J.E(z.b,this.cy.b)),J.fR(J.E(z.a,this.cy.a)))){if(this.Kq(!0))this.db=2
else{this.FI()
return}y=2}else{if(this.Kq(!1))this.db=1
else{this.FI()
return}y=1}if(y===1)if(!this.r2.c_){this.FI()
return}if(y===2)if(!this.r2.bW){this.FI()
return}}y=this.r2
if(P.bg(0,0,y.Q,y.ch,null).p_(0,z)){y=this.db
if(y===2)this.spW(H.a(new P.H(0,J.E(z.b,this.cy.b)),[null]))
else if(y===1)this.spW(H.a(new P.H(J.E(z.a,this.cy.a),0),[null]))
else if(y===3)this.spW(H.a(new P.H(J.E(z.a,this.cy.a),J.E(z.b,this.cy.b)),[null]))
else this.spW(null)}},"$1","garw",2,0,4,4],
b3q:[function(a){var z,y
for(z=this.fy;z.length>0;)z.pop().H(0)
J.a3(this.go)
this.cx=!1
this.cC()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.aq5(2,z.b)
z=this.db
if(z===1||z===3)this.aq5(1,this.r1.a)}else{this.a5X()
F.aa(new L.ahb(this))}},"$1","garx",2,0,4,4],
aiO:[function(a){if(Q.cV(a)===27)this.FI()},"$1","gGe",2,0,6,4],
FI:function(){for(var z=this.fy;z.length>0;)z.pop().H(0)
J.a3(this.go)
this.cx=!1
this.cC()},
b98:[function(a){this.a5X()
F.aa(new L.ahc(this))},"$1","gaiS",2,0,7,4],
ay7:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.z(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ag:{
aha:function(){var z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.c_])),[P.r,E.c_])
z=new L.ah9(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.ay7()
return z}}},
ahb:{"^":"d:3;a",
$0:[function(){this.a.a5Y()},null,null,0,0,null,"call"]},
ahc:{"^":"d:3;a",
$0:[function(){this.a.a5Y()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.bv,args:[F.v,P.e,P.bv]},{func:1,v:true,args:[[P.L,P.e]]},{func:1,ret:Q.bT},{func:1,v:true,args:[W.cM]},{func:1,v:true,args:[P.r]},{func:1,v:true,args:[W.ha]},{func:1,v:true,args:[E.cl]},{func:1,ret:P.e,args:[N.kZ]}]
init.types.push.apply(init.types,deferredTypes)
$.Pv=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["Xw","$get$Xw",function(){return P.m(["scaleType",new L.bba(),"offsetLeft",new L.bbb(),"offsetRight",new L.bbc(),"minimum",new L.bbd(),"maximum",new L.bbe(),"formatString",new L.bbf(),"showMinMaxOnly",new L.bbh(),"percentTextSize",new L.bbi(),"labelsColor",new L.bbj(),"labelsFontFamily",new L.bbk(),"labelsFontStyle",new L.bbl(),"labelsFontWeight",new L.bbm(),"labelsTextDecoration",new L.bbn(),"labelsLetterSpacing",new L.bbo(),"labelsRotation",new L.bbp(),"labelsAlign",new L.bbq(),"angleFrom",new L.bbs(),"angleTo",new L.bbt(),"percentOriginX",new L.bbu(),"percentOriginY",new L.bbv(),"percentRadius",new L.bbw(),"majorTicksCount",new L.bbx(),"justify",new L.bby()])},$,"Xx","$get$Xx",function(){var z=P.af()
z.q(0,E.eU())
z.q(0,$.$get$Xw())
return z},$,"Xy","$get$Xy",function(){return P.m(["scaleType",new L.bbz(),"ticksPlacement",new L.bbA(),"offsetLeft",new L.bbB(),"offsetRight",new L.bbD(),"majorTickStroke",new L.bbE(),"majorTickStrokeWidth",new L.bbF(),"minorTickStroke",new L.bbG(),"minorTickStrokeWidth",new L.bbH(),"angleFrom",new L.bbI(),"angleTo",new L.bbJ(),"percentOriginX",new L.bbK(),"percentOriginY",new L.bbL(),"percentRadius",new L.bbM(),"majorTicksCount",new L.bbO(),"majorTicksPercentLength",new L.bbP(),"minorTicksCount",new L.bbQ(),"minorTicksPercentLength",new L.bbR(),"cutOffAngle",new L.bbS()])},$,"Xz","$get$Xz",function(){var z=P.af()
z.q(0,E.eU())
z.q(0,$.$get$Xy())
return z},$,"XA","$get$XA",function(){return P.m(["scaleType",new L.baY(),"offsetLeft",new L.baZ(),"offsetRight",new L.bb_(),"percentStartThickness",new L.bb0(),"percentEndThickness",new L.bb1(),"placement",new L.bb2(),"gradient",new L.bb3(),"angleFrom",new L.bb4(),"angleTo",new L.bb6(),"percentOriginX",new L.bb7(),"percentOriginY",new L.bb8(),"percentRadius",new L.bb9()])},$,"XB","$get$XB",function(){var z=P.af()
z.q(0,E.eU())
z.q(0,$.$get$XA())
return z},$])}
$dart_deferred_initializers$["4WW5e56zH/ckug6Jlb9dyVcVK9s="]=$dart_deferred_initializers$.current

//# sourceMappingURL=remote_dataflow.dart.js_1.part.js.map
