self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,N,{"^":"",
aCW:function(){var z=document
z=z.createElement("div")
z=new N.Ef(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.oM()
z.ab3()
return z},
agU:{"^":"Ib;",
sq6:["atE",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cm()}}],
sGk:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cm()}},
sGl:function(a){if(!J.b(this.rx,a)){this.rx=a
this.cm()}},
sGm:function(a){if(!J.b(this.ry,a)){this.ry=a
this.cm()}},
sGo:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cm()}},
sGn:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cm()}},
saQF:function(a){if(!J.b(this.y1,a)){if(J.Z(a,180))a=180
this.y1=J.aI(a,-180)?-180:a
this.cm()}},
saQE:function(a){if(J.b(this.y2,a))return
this.y2=a
this.cm()},
gii:function(){return this.D},
sii:function(a){if(a==null)a=0
if(!J.b(this.D,a)){this.D=a
this.cm()}},
giP:function(){return this.v},
siP:function(a){if(a==null)a=100
if(!J.b(this.v,a)){this.v=a
this.cm()}},
saXr:function(a){if(this.N!==a){this.N=a
this.cm()}},
salP:function(a,b){if(b==null||J.aI(b,0))b=0
if(J.Z(b,4))b=4
if(!J.b(this.S,b)){this.S=b
this.cm()}},
sas7:function(a){if(this.U!==a){this.U=a
this.cm()}},
svp:function(a){this.Y=a
this.cm()},
gpu:function(){return this.G},
spu:function(a){if(!J.b(this.G,a)){this.G=a
this.cm()}},
saQx:function(a){if(!J.b(this.a_,a)){this.a_=a
this.cm()}},
guc:function(a){return this.P},
suc:["a9X",function(a,b){if(!J.b(this.P,b))this.P=b}],
sGJ:["a9Y",function(a){if(!J.b(this.at,a))this.at=a}],
sa37:function(a){this.aa_(a)
this.cm()},
iC:function(a,b){this.Ex(a,b)
this.MM()
if(J.b(this.G,"circular"))this.aXC(a,b)
else this.aXD(a,b)},
MM:function(){var z,y,x,w,v
z=this.U
y=this.k2
if(z){y.se8(0,2)
z=this.k2.f
if(0>=z.length)return H.f(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isd5)z.sbT(x,this.a0l(this.D,this.S))
J.ac(J.b9(x.gaC()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.f(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isd5)z.sbT(x,this.a0l(this.v,this.S))
J.ac(J.b9(x.gaC()),"text-decoration",this.x1)}else{y.se8(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.f(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isd5){y=this.D
w=J.Q(y,J.aa(J.du(J.D(this.v,y),J.D(this.fy,1)),v))
z.sbT(x,this.a0l(w,this.S))}J.ac(J.b9(x.gaC()),"text-decoration",this.x1);++v}}this.eD(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.c(this.x2)+"px")},
aXC:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.du(J.D(this.fr,this.dy),z-1)
x=P.aB(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.du(a,2)
x=P.aB(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.D(w,x*(50-u)/100)
u=J.du(b,2)
x=P.aB(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.D(u,x*(50-w)/100)
r=C.b.M(this.N,"%")&&!0
x=this.N
if(r){H.cz("")
x=H.dV(x,"%","")}q=P.e2(x,null)
for(x=J.bU(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.f(w,p)
o=w[p]
w=J.Q(J.D(this.dy,90),x.b1(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.Ic(o)
w=m.b
u=J.a2(w)
if(u.bw(w,0)){if(r){l=P.aB(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.du(l,w)}else k=0
l=m.a
j=J.bU(l)
i=J.Q(j.b1(l,l),u.b1(w,w))
if(typeof i!=="number")H.ad(H.bx(i))
i=Math.sqrt(i)
h=J.aa(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.a_){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.aa(j.dd(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.aa(u.dd(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.ac(J.b9(o.gaC()),"transform","")
if(!!J.n(o).$iscI)o.i8(d,c)
else E.ev(o.gaC(),d,c)
i=J.b9(o.gaC())
h=J.M(i)
h.l(i,"transform",J.Q(h.h(i,"transform")," scale ("+H.c(k)+")"))
if(!J.b(this.y1,0))if(!!J.n(o.gaC()).$isml){i=J.b9(o.gaC())
h=J.M(i)
h.l(i,"transform",J.Q(h.h(i,"transform")," rotate("+H.c(this.y1)+" "+H.c(j.dd(l,2))+" "+H.c(J.du(u.fv(w),2))+")"))}else{J.k9(J.J(o.gaC())," rotate("+H.c(this.y1)+"deg)")
J.nx(J.J(o.gaC()),H.c(J.aa(j.dd(l,2),k))+" "+H.c(J.aa(u.dd(w,2),k)))}}},
aXD:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.du(J.D(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.f(x,0)
w=this.Ic(x[0])
v=C.b.M(this.N,"%")&&!0
x=this.N
if(v){H.cz("")
x=H.dV(x,"%","")}u=P.e2(x,null)
x=w.b
t=J.a2(x)
if(t.bw(x,0))s=J.du(v?J.du(J.aa(a,u),200):u,x)
else s=0
r=J.du(J.aa(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ab(r)))
p=Math.abs(Math.sin(H.ab(r)))
this.a9X(this,J.aa(J.du(J.Q(J.aa(w.a,q),t.b1(x,p)),2),s))
this.UD()
x=this.k2.f
if(y<0||y>=x.length)return H.f(x,y)
w=this.Ic(x[y])
x=w.b
t=J.a2(x)
if(t.bw(x,0))s=J.du(v?J.du(J.aa(a,u),200):u,x)
else s=0
this.a9Y(J.aa(J.du(J.Q(J.aa(w.a,q),t.b1(x,p)),2),s))
this.UD()
if(!J.b(this.y1,0)){for(x=J.bU(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.f(t,n)
w=this.Ic(t[n])
t=w.b
m=J.a2(t)
if(m.bw(t,0))J.du(v?J.du(x.b1(a,u),200):u,t)
o=P.aC(J.Q(J.aa(w.a,p),m.b1(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.a2(a)
k=J.du(J.D(x.w(a,this.P),this.at),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.f(y,n)
j=y[n]
y=this.P
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.Q(y,t)
w=this.Ic(j)
y=w.b
m=J.a2(y)
if(m.bw(y,0))s=J.du(v?J.du(x.b1(a,u),200):u,y)
else s=0
h=w.a
g=J.a2(h)
i=J.D(i,J.aa(g.dd(h,2),s))
J.ac(J.b9(j.gaC()),"transform","")
if(J.b(this.y1,0)){y=J.aa(J.Q(g.b1(h,p),m.b1(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
if(!!J.n(j).$iscI)j.i8(i,f)
else E.ev(j.gaC(),i,f)
y=J.b9(j.gaC())
t=J.M(y)
t.l(y,"transform",J.Q(t.h(y,"transform")," scale ("+H.c(s)+")"))}else{i=J.D(J.Q(this.P,t),g.dd(h,2))
t=J.Q(g.b1(h,p),m.b1(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
if(!!J.n(j).$iscI)j.i8(i,e)
else E.ev(j.gaC(),i,e)
d=g.dd(h,2)
c=-y/2
y=J.b9(j.gaC())
t=J.M(y)
m=s-1
t.l(y,"transform",J.Q(t.h(y,"transform")," translate("+H.c(J.aa(J.d3(d),m))+" "+H.c(-c*m)+")"))
m=J.b9(j.gaC())
y=J.M(m)
y.l(m,"transform",J.Q(y.h(m,"transform")," scale ("+H.c(s)+")"))
m=J.b9(j.gaC())
y=J.M(m)
y.l(m,"transform",J.Q(y.h(m,"transform")," rotate("+H.c(this.y1)+" "+H.c(d)+" "+H.c(c)+")"))}}},
Ic:function(a){var z,y,x,w
if(!!J.n(a.gaC()).$isef){z=H.k(a.gaC(),"$isef").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.b1()
w=x*0.7}else{y=J.d7(a.gaC())
y.toString
w=J.d_(a.gaC())
w.toString}return H.a(new P.H(y,w),[null])},
a0s:[function(){return N.Bj()},"$0","gtU",0,0,3],
a0l:function(a,b){var z=this.Y
if(z==null||J.b(z,""))return U.nl(a,"0")
else return U.nl(a,this.Y)},
a7:[function(){this.aa_(0)
this.cm()
var z=this.k2
z.d=!0
z.r=!0
z.se8(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gd7",0,0,0],
axj:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.z(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new N.n0(this.gtU(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
Ib:{"^":"le;",
gXr:function(){return this.cy},
sSW:["atI",function(a){if(a==null)a=50
if(J.aI(a,0))a=0
if(J.Z(a,100))a=100
if(!J.b(this.db,a)){this.db=a
this.cm()}}],
sSX:["atJ",function(a){if(a==null)a=50
if(J.aI(a,0))a=0
if(J.Z(a,100))a=100
if(!J.b(this.dx,a)){this.dx=a
this.cm()}}],
sQ0:["atF",function(a){if(J.aI(a,-360))a=-360
if(J.Z(a,360))a=360
if(!J.b(this.dy,a)){this.dy=a
this.dU()
this.cm()}}],
sQ1:["atG",function(a){if(J.aI(a,-360))a=-360
if(J.Z(a,360))a=360
if(!J.b(this.fr,a)){this.fr=a
this.dU()
this.cm()}}],
saS7:function(a){if(a==null||J.aI(a,0))a=0
if(J.Z(a,20))a=20
if(!J.b(this.fx,a)){this.fx=a
this.cm()}},
sa37:["aa_",function(a){if(a==null||J.aI(a,2))a=2
if(J.Z(a,30))a=30
if(!J.b(this.fy,a)){this.fy=a
this.cm()}}],
saS8:function(a){if(this.go!==a){this.go=a
this.cm()}},
saRB:function(a){if(this.id!==a){this.id=a
this.cm()}},
sSY:["atK",function(a){if(a==null||J.aI(a,0))a=0
if(J.Z(a,200))a=200
if(!J.b(this.k1,a)){this.k1=a
this.cm()}}],
gjR:function(){return this.cy},
f1:["atH",function(a,b,c,d){R.oG(a,b,c,d)}],
eD:["a9Z",function(a,b){R.t3(a,b)}],
zf:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.j(a)
if(y!=="")J.ac(z.gfc(a),"d",y)
else J.ac(z.gfc(a),"d","M 0,0")}},
agV:{"^":"Ib;",
sa36:["atL",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cm()}}],
saRA:function(a){if(!J.b(this.r2,a)){this.r2=a
this.cm()}},
sq9:["atM",function(a){if(!J.b(this.rx,a)){this.rx=a
this.cm()}}],
sGD:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cm()}},
gpu:function(){return this.x2},
spu:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cm()}},
guc:function(a){return this.y1},
suc:function(a,b){if(!J.b(this.y1,b)){this.y1=b
this.cm()}},
sGJ:function(a){if(!J.b(this.y2,a)){this.y2=a
this.cm()}},
saZC:function(a){if(!J.b(this.K,a)){this.K=a
this.cm()}},
saK7:function(a){var z
if(!J.b(this.D,a)){this.D=a
if(a!=null){z=J.D(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.v=z
this.cm()}},
iC:function(a,b){var z,y
this.Ex(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.f1(this.k2,this.k4,J.aN(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.f1(this.k3,this.rx,J.aN(this.x1),this.ry)
if(J.b(this.x2,"circular"))this.aLT(a,b)
else this.aLU(a,b)},
aLT:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.du(J.D(this.fr,this.dy),J.D(J.Q(J.aa(this.fx,J.D(this.fy,1)),this.fy),1))
x=C.b.M(this.go,"%")&&!0
w=this.go
if(x){H.cz("")
w=H.dV(w,"%","")}v=P.e2(w,null)
if(x){w=P.aB(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aB(a,b)
w=J.du(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.D(w,t*(50-s)/100)
s=J.du(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.D(s,t*(50-w)/100)
w=P.aB(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.b(this.K,"center"))o=0.5
else o=J.b(this.K,"outside")?1:0
w=o-1
s=J.bU(y)
n=0
while(!0){m=J.Q(J.aa(this.fx,J.D(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.Q(J.D(this.dy,90),s.b1(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++n}this.zf(this.k3)
z.a=""
y=J.du(J.D(this.fr,this.dy),J.D(this.fy,1))
h=C.b.M(this.id,"%")&&!0
s=this.id
if(h){H.cz("")
s=H.dV(s,"%","")}g=P.e2(s,null)
if(h){s=P.aB(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.bU(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.Q(J.D(this.dy,90),s.b1(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++f}this.zf(this.k2)},
aLU:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.b.M(this.go,"%")&&!0
y=this.go
if(z){H.cz("")
y=H.dV(y,"%","")}x=P.e2(y,null)
w=z?J.du(J.aa(J.du(a,2),x),100):x
v=C.b.M(this.id,"%")&&!0
y=this.id
if(v){H.cz("")
y=H.dV(y,"%","")}u=P.e2(y,null)
t=v?J.du(J.aa(J.du(a,2),u),100):u
y=this.cx
y.a=""
s=J.a2(a)
r=J.du(J.D(s.w(a,this.y1),this.y2),J.D(J.Q(J.aa(this.fx,J.D(this.fy,1)),this.fy),1))
if(J.b(this.K,"center"))q=0.5
else q=J.b(this.K,"outside")?1:0
p=J.a2(t)
o=p.w(t,w)
n=1-q
m=0
while(!0){l=J.Q(J.aa(this.fx,J.D(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.w(t,q*o)
y.a+="M "+H.c(k)+","+H.c(n*o)+" "
y.a+="L "+H.c(k)+","+H.c(j)+" ";++m}this.zf(this.k3)
y.a=""
r=J.du(J.D(s.w(a,this.y1),this.y2),J.D(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.c(k)+",0 "
y.a+="L "+H.c(k)+","+H.c(t)+" ";++i}this.zf(this.k2)},
a7:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.zf(z)
this.zf(this.k3)}},"$0","gd7",0,0,0]},
agW:{"^":"Ib;",
sSW:function(a){this.atI(a)
this.r2=!0},
sSX:function(a){this.atJ(a)
this.r2=!0},
sQ0:function(a){this.atF(a)
this.r2=!0},
sQ1:function(a){this.atG(a)
this.r2=!0},
sSY:function(a){this.atK(a)
this.r2=!0},
saXq:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.cm()}},
saXo:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.cm()}},
sa8l:function(a){if(this.x2!==a){this.x2=a
this.dU()
this.cm()}},
gj4:function(){return this.y1},
sj4:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.b(this.y1,a)){this.y1=a
this.r2=!0
this.cm()}},
gpu:function(){return this.y2},
spu:function(a){if(!J.b(this.y2,a)){this.y2=a
this.r2=!0
this.cm()}},
guc:function(a){return this.K},
suc:function(a,b){if(!J.b(this.K,b)){this.K=b
this.r2=!0
this.cm()}},
sGJ:function(a){if(!J.b(this.D,a)){this.D=a
this.r2=!0
this.cm()}},
je:function(){var z,y,x,w,v,u,t,s,r
this.yM()
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.O)(z),++u){t=z[u]
s=J.j(t)
y.push(s.giq(t))
x.push(s.gBV(t))
w.push(s.gtj(t))}if(J.iv(J.D(this.dy,this.fr))===!0){z=J.fN(J.D(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.m.E(0.5*z)}else r=0
this.k2=this.aJ0(y,w,r)
this.k3=this.aGG(x,w,r)
this.r2=!0},
iC:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.Ex(a,b)
z=J.bU(a)
y=J.bU(b)
E.E8(this.k4,z.b1(a,1),y.b1(b,1))
if(J.b(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aB(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.b(this.y2,"circular")){z=P.aC(0,P.aB(a,b))
this.rx=z
this.aLW(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.c(this.rx)+" "+H.c(this.rx))}else{z=J.aa(J.D(z.w(a,this.K),this.D),1)
y.b1(b,1)
v=C.b.M(this.ry,"%")&&!0
y=this.ry
if(v){H.cz("")
y=H.dV(y,"%","")}u=P.e2(y,null)
t=v?J.R(J.aa(z,u),100):u
s=C.b.M(this.x1,"%")&&!0
y=this.x1
if(s){H.cz("")
y=H.dV(y,"%","")}r=P.e2(y,null)
q=s?J.R(J.aa(z,r),100):r
this.r1.se8(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.D(q,t)
p=q
o=p
m=0
break
case"cross":y=J.a0(q)
x=J.a0(t)
o=J.Q(y.dd(q,2),x.dd(t,2))
n=J.D(y.dd(q,2),x.dd(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.a(new P.H(this.K,o),[null])
k=H.a(new P.H(this.K,n),[null])
j=H.a(new P.H(J.Q(this.K,z),p),[null])
i=H.a(new P.H(J.Q(this.K,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.f(y,0)
h=y[0]
this.eD(h.gaC(),this.N)
R.oG(h.gaC(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.c(y)+","+H.c(x)+" "
z.a+="L "+H.c(j.a)+","+H.c(j.b)+" "
z.a+="L "+H.c(i.a)+","+H.c(i.b)+" "
z.a+="L "+H.c(k.a)+","+H.c(k.b)+" "
z.a+="L "+H.c(y)+","+H.c(x)+" "
this.zf(h.gaC())
x=this.cy
x.toString
new W.dd(x).L(0,"viewBox")}},
aJ0:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.x1(J.aa(J.D(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.f(a,y)
t=J.b_(J.cN(a[y],16),255)
if(y>=a.length)return H.f(a,y)
s=J.b_(J.cN(a[y],8),255)
if(y>=a.length)return H.f(a,y)
r=J.b_(a[y],255)
if(x>=a.length)return H.f(a,x)
q=J.b_(J.cN(a[x],16),255)
if(x>=a.length)return H.f(a,x)
p=J.b_(J.cN(a[x],8),255)
if(x>=a.length)return H.f(a,x)
o=J.b_(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.c.E(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.c.E(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.c.E(w*r+m*o)&255)>>>0)}}return z},
aGG:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.x1(J.aa(J.D(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.f(a,x)
v=a[x]
if(y>=w)return H.f(a,y)
t=J.R(J.D(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.f(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.Q(w,s*t))}}return z},
aLW:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aB(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.b.M(this.ry,"%")&&!0
z=this.ry
if(v){H.cz("")
z=H.dV(z,"%","")}u=P.e2(z,new N.agX())
if(v){z=P.aB(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.b.M(this.x1,"%")&&!0
z=this.x1
if(s){H.cz("")
z=H.dV(z,"%","")}r=P.e2(z,new N.agY())
if(s){z=P.aB(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aB(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aB(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.se8(0,w)
for(z=J.a2(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.D(this.dy,90)
d=J.D(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.Q(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.w(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.f(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.f(e,d)
g=J.bv(J.aa(e[d],255))
g=J.bP(J.b(g,0)?1:g,24)
e=h.gaC()
a3=this.k2
if(d>=a3.length)return H.f(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.eD(e,a3+g)
a3=h.gaC()
e=this.k2
if(d>=e.length)return H.f(e,d)
R.oG(a3,e[d]+g,1,"solid")
y.a+="M "+H.c(l)+","+H.c(k)+" "
y.a+="L "+H.c(a)+","+H.c(a0)+" "
y.a+="L "+H.c(a1)+","+H.c(a2)+" "
y.a+="L "+H.c(j)+","+H.c(i)+" "
y.a+="L "+H.c(l)+","+H.c(k)+" "
this.zf(h.gaC())}}},
bcd:[function(){var z,y
z=new N.a3b(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gaXg",0,0,3],
a7:["atN",function(){var z=this.r1
z.d=!0
z.r=!0
z.se8(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gd7",0,0,0],
axk:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sa8l([new N.wd(65280,0.5,0),new N.wd(16776960,0.8,0.5),new N.wd(16711680,1,1)])
z=new N.n0(this.gaXg(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
agX:{"^":"d:0;",
$1:function(a){return 0}},
agY:{"^":"d:0;",
$1:function(a){return 0}},
wd:{"^":"r;iq:a*,BV:b>,tj:c>"}}],["","",,L,{"^":"",
bzG:[function(a){var z=!!J.n(a.gle().gaC()).$isfH?H.k(a.gle().gaC(),"$isfH"):null
if(z!=null)if(z.gnO()!=null&&!J.b(z.gnO(),""))return L.So(a.gle(),z.gnO())
else return z.FZ(a)
return""},"$1","aXL",2,0,8,50],
bpU:function(){if($.P0)return
$.P0=!0
$.$get$hy().l(0,"percentTextSize",L.aXO())
$.$get$hy().l(0,"minorTicksPercentLength",L.aaa())
$.$get$hy().l(0,"majorTicksPercentLength",L.aaa())
$.$get$hy().l(0,"percentStartThickness",L.aac())
$.$get$hy().l(0,"percentEndThickness",L.aac())
$.$get$hz().l(0,"percentTextSize",L.aXP())
$.$get$hz().l(0,"minorTicksPercentLength",L.aab())
$.$get$hz().l(0,"majorTicksPercentLength",L.aab())
$.$get$hz().l(0,"percentStartThickness",L.aad())
$.$get$hz().l(0,"percentEndThickness",L.aad())},
aXJ:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$fd())
C.a.q(z,$.$get$Bz())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$fd())
C.a.q(z,$.$get$Cy())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$fd())
C.a.q(z,$.$get$Cw())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$fd())
C.a.q(z,$.$get$K7())
return z
case"linearAxis":return $.$get$v9()
case"logAxis":return $.$get$vb()
case"categoryAxis":return $.$get$rP()
case"datetimeAxis":return $.$get$uZ()
case"axisRenderer":return $.$get$rK()
case"radialAxisRenderer":return $.$get$K0()
case"angularAxisRenderer":return $.$get$In()
case"linearAxisRenderer":return $.$get$rK()
case"logAxisRenderer":return $.$get$rK()
case"categoryAxisRenderer":return $.$get$rK()
case"datetimeAxisRenderer":return $.$get$rK()
case"lineSeries":return $.$get$v7()
case"areaSeries":return $.$get$Bf()
case"columnSeries":return $.$get$BC()
case"barSeries":return $.$get$Bn()
case"bubbleSeries":return $.$get$Bu()
case"pieSeries":return $.$get$xR()
case"spectrumSeries":return $.$get$Km()
case"radarSeries":return $.$get$xT()
case"lineSet":return $.$get$q3()
case"areaSet":return $.$get$Bh()
case"columnSet":return $.$get$BE()
case"barSet":return $.$get$Bp()
case"gridlines":return $.$get$Je()}return[]},
aXH:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof L.oz)return a
else{z=$.$get$TC()
y=H.a([],[N.ez])
x=H.a([],[E.j6])
w=H.a([],[L.iD])
v=H.a([],[E.j6])
u=H.a([],[L.iD])
t=H.a([],[E.j6])
s=H.a([],[L.xn])
r=H.a([],[E.j6])
q=H.a([],[L.xU])
p=H.a([],[E.j6])
o=$.$get$aw()
n=$.X+1
$.X=n
n=new L.oz(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
n.c7(b,"chart")
J.a1(J.z(n.b),"absolute")
o=L.aiW()
n.C=o
J.by(n.b,o.cx)
o=n.C
o.bj=n
o.Nd()
o=L.age()
n.a8=o
o.scG(n.C)
return n}case"scaleTicks":if(a instanceof L.Cx)return a
else{z=$.$get$WS()
y=$.$get$aw()
x=$.X+1
$.X=x
x=new L.Cx(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c7(b,"scale-ticks")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.aja(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.cy=P.hB()
x.C=z
J.by(x.b,z.gXr())
return x}case"scaleLabels":if(a instanceof L.Cv)return a
else{z=$.$get$WQ()
y=$.$get$aw()
x=$.X+1
$.X=x
x=new L.Cv(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c7(b,"scale-labels")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.aj8(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.cy=P.hB()
z.axj()
x.C=z
J.by(x.b,z.gXr())
x.C.se0(x)
return x}case"scaleTrack":if(a instanceof L.Cz)return a
else{z=$.$get$WU()
y=$.$get$aw()
x=$.X+1
$.X=x
x=new L.Cz(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c7(b,"scale-track")
J.a1(J.z(x.b),"absolute")
J.lR(J.J(x.b),"hidden")
y=L.ajc()
x.C=y
J.by(x.b,y.gXr())
return x}}return},
bA6:[function(){var z=new L.akj(null,null,null)
z.aaT()
return z},"$0","aXM",0,0,3],
aiW:function(){var z,y,x,w,v,u,t
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
y=P.bf(0,0,0,0,null)
x=P.bf(0,0,0,0,null)
w=new N.cH(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.a([],[P.fg])
t=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,P.r])),[P.e,P.r])
z=new L.nE(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",N.aXQ(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.axh("chartBase")
z.axf()
z.ay1()
z.sR9("single")
z.axu()
return z},
bFt:[function(a,b,c){return L.aWr(a,c)},"$3","aXO",6,0,1,15,35,1],
aWr:function(a,b){var z,y,x
z=a.I("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
return J.R(J.aa(J.b(y.gpu(),"circular")?P.aB(x.gba(y),x.gbs(y)):x.gba(y),b),200)},
bFu:[function(a,b,c){return L.aWs(a,c)},"$3","aXP",6,0,1,15,35,1],
aWs:function(a,b){var z,y,x,w
z=a.I("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.aa(b,200)
w=J.j(y)
return J.R(x,J.b(y.gpu(),"circular")?P.aB(w.gba(y),w.gbs(y)):w.gba(y))},
bFv:[function(a,b,c){return L.aWt(a,c)},"$3","aaa",6,0,1,15,35,1],
aWt:function(a,b){var z,y,x
z=a.I("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
return J.R(J.aa(J.b(y.gpu(),"circular")?P.aB(x.gba(y),x.gbs(y)):x.gba(y),b),200)},
bFw:[function(a,b,c){return L.aWu(a,c)},"$3","aab",6,0,1,15,35,1],
aWu:function(a,b){var z,y,x,w
z=a.I("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.aa(b,200)
w=J.j(y)
return J.R(x,J.b(y.gpu(),"circular")?P.aB(w.gba(y),w.gbs(y)):w.gba(y))},
bFx:[function(a,b,c){return L.aWv(a,c)},"$3","aac",6,0,1,15,35,1],
aWv:function(a,b){var z,y,x
z=a.I("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
if(J.b(y.gpu(),"circular")){x=P.aB(x.gba(y),x.gbs(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.R(J.aa(x.gba(y),b),100)
return x},
bFy:[function(a,b,c){return L.aWw(a,c)},"$3","aad",6,0,1,15,35,1],
aWw:function(a,b){var z,y,x,w
z=a.I("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
w=J.bU(b)
return J.b(y.gpu(),"circular")?J.R(w.b1(b,200),P.aB(x.gba(y),x.gbs(y))):J.R(w.b1(b,100),x.gba(y))},
akj:{"^":"KF;a,b,c",
sbT:function(a,b){var z,y,x,w,v
if(J.b(this.b,b))return
this.aus(this,b)
if(b instanceof N.kQ){z=b.e
if(z.gaC() instanceof N.ez&&H.k(z.gaC(),"$isez").K!=null){J.l5(J.J(this.a),"")
return}y=K.bS(b.r,"fault")
if(y==="fault"&&b.r instanceof F.v){x=b.r
if(J.b(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof F.ee&&J.Z(w.ry,0)){z=H.k(w.cn(0),"$isjn")
y=K.hn(z.giq(z),null,"rgba(0,0,0,0)")}}}v=H.c(y==="fault"?K.hn(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.l5(J.J(this.a),v)}}},
aj8:{"^":"agU;ag,a6,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,D,v,N,S,U,Y,V,G,a_,P,at,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sq6:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cu(this.gdt())
this.atE(a)
if(a instanceof F.v)a.di(this.gdt())},
suc:function(a,b){this.a9X(this,b)
this.UD()},
sGJ:function(a){this.a9Y(a)
this.UD()},
ge0:function(){return this.a6},
se0:function(a){H.k(a,"$isaM")
this.a6=a
if(a!=null)F.cn(this.gb04())},
eD:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.a9Z(a,b)
return}if(!!J.n(a).$isb1){z=this.ag.a
if(!z.O(0,a))z.l(0,a,new E.bY(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jl(b)}},
o8:[function(a){this.cm()},"$1","gdt",2,0,2,11],
UD:[function(){var z=this.a6
if(z!=null)if(z.a instanceof F.v)F.a9(new L.aj9(this))},"$0","gb04",0,0,0]},
aj9:{"^":"d:3;a",
$0:[function(){var z=this.a
z.a6.a.bg("offsetLeft",z.P)
z.a6.a.bg("offsetRight",z.at)},null,null,0,0,null,"call"]},
Cv:{"^":"aBk;b6,dA:C@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bU,c2,c4,bx,bX,bW,c3,c5,c8,c_,bH,cd,cL,cv,cw,cz,co,cA,cB,cH,ce,cq,cr,cb,c9,cM,cj,cC,cD,bL,cc,cf,cE,cI,ck,cp,cN,cX,cJ,cs,cO,cP,cV,cg,cQ,cR,cl,cS,cW,cT,D,v,N,S,U,Y,V,G,a_,P,at,ag,a6,ac,af,al,ar,aa,aG,aN,aR,ai,aI,aA,aE,am,ao,aF,aO,av,aW,b_,b4,be,b9,b8,aY,aZ,bn,aV,bh,aT,bE,bu,bi,bf,bm,aS,bG,br,bd,bo,bO,bA,bp,bQ,bF,bV,bC,bP,bD,bq,bc,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gds:function(){return this.b6},
sf3:function(a,b){if(J.b(this.G,"none")&&!J.b(b,"none")){this.lt(this,b)
this.e4()}else this.lt(this,b)},
hH:[function(a){this.mK(a)
this.siw(!0)},"$1","gfo",2,0,2,11],
uh:[function(a){this.w9()},"$0","gmW",0,0,0],
a7:[function(){this.siw(!1)
this.fu()
this.C.sGw(!0)
this.C.a7()
this.C.sq6(null)
this.C.sGw(!1)},"$0","gd7",0,0,0],
hZ:[function(){this.siw(!1)
this.fu()},"$0","gkn",0,0,0],
fR:function(){this.Bm()
this.siw(!0)},
w9:function(){if(this.a instanceof F.v)this.C.ic(J.d7(this.b),J.d_(this.b))},
e4:function(){var z,y
this.yN()
this.soy(-1)
z=this.C
y=J.j(z)
y.sba(z,J.D(y.gba(z),1))},
$isbZ:1,
$isc_:1,
$iscK:1},
aBk:{"^":"aM+o5;oy:x$?,vy:y$?",$iscK:1},
b8Y:{"^":"d:36;",
$2:[function(a,b){a.gdA().spu(K.ay(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b8Z:{"^":"d:36;",
$2:[function(a,b){J.Ht(a.gdA(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b9_:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGJ(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b90:{"^":"d:36;",
$2:[function(a,b){a.gdA().sii(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b91:{"^":"d:36;",
$2:[function(a,b){a.gdA().siP(K.aV(b,100))},null,null,4,0,null,0,2,"call"]},
b93:{"^":"d:36;",
$2:[function(a,b){a.gdA().svp(K.I(b,""))},null,null,4,0,null,0,2,"call"]},
b94:{"^":"d:36;",
$2:[function(a,b){a.gdA().sas7(K.a_(b,!1))},null,null,4,0,null,0,2,"call"]},
b95:{"^":"d:36;",
$2:[function(a,b){a.gdA().saXr(K.kw(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
b96:{"^":"d:36;",
$2:[function(a,b){a.gdA().sq6(R.cF(b,16777215))},null,null,4,0,null,0,2,"call"]},
b97:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGk(K.I(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
b98:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGl(K.ay(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
b99:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGm(K.ay(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
b9a:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGo(K.ay(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
b9b:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGn(K.aj(b,0))},null,null,4,0,null,0,2,"call"]},
b9c:{"^":"d:36;",
$2:[function(a,b){a.gdA().saQF(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b9f:{"^":"d:36;",
$2:[function(a,b){a.gdA().saQE(K.ay(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
b9g:{"^":"d:36;",
$2:[function(a,b){a.gdA().sQ0(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
b9h:{"^":"d:36;",
$2:[function(a,b){a.gdA().sQ1(K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
b9i:{"^":"d:36;",
$2:[function(a,b){a.gdA().sSW(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b9j:{"^":"d:36;",
$2:[function(a,b){a.gdA().sSX(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b9k:{"^":"d:36;",
$2:[function(a,b){a.gdA().sSY(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
b9l:{"^":"d:36;",
$2:[function(a,b){a.gdA().sa37(K.aj(b,11))},null,null,4,0,null,0,2,"call"]},
b9m:{"^":"d:36;",
$2:[function(a,b){a.gdA().saQx(K.ay(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
aja:{"^":"agV;N,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,D,v,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sq9:function(a){var z=this.rx
if(z instanceof F.v)H.k(z,"$isv").cu(this.gdt())
this.atM(a)
if(a instanceof F.v)a.di(this.gdt())},
sa36:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cu(this.gdt())
this.atL(a)
if(a instanceof F.v)a.di(this.gdt())},
f1:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.N.a
if(z.O(0,a))z.h(0,a).jt(null)
this.atH(a,b,c,d)
return}if(!!J.n(a).$isb1){z=this.N.a
if(!z.O(0,a))z.l(0,a,new E.bY(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jt(b)
y.skP(c)
y.skx(d)}},
o8:[function(a){this.cm()},"$1","gdt",2,0,2,11]},
Cx:{"^":"aBl;b6,dA:C@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bU,c2,c4,bx,bX,bW,c3,c5,c8,c_,bH,cd,cL,cv,cw,cz,co,cA,cB,cH,ce,cq,cr,cb,c9,cM,cj,cC,cD,bL,cc,cf,cE,cI,ck,cp,cN,cX,cJ,cs,cO,cP,cV,cg,cQ,cR,cl,cS,cW,cT,D,v,N,S,U,Y,V,G,a_,P,at,ag,a6,ac,af,al,ar,aa,aG,aN,aR,ai,aI,aA,aE,am,ao,aF,aO,av,aW,b_,b4,be,b9,b8,aY,aZ,bn,aV,bh,aT,bE,bu,bi,bf,bm,aS,bG,br,bd,bo,bO,bA,bp,bQ,bF,bV,bC,bP,bD,bq,bc,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gds:function(){return this.b6},
sf3:function(a,b){if(J.b(this.G,"none")&&!J.b(b,"none")){this.lt(this,b)
this.e4()}else this.lt(this,b)},
hH:[function(a){this.mK(a)
this.siw(!0)
if(a==null)this.C.ic(J.d7(this.b),J.d_(this.b))},"$1","gfo",2,0,2,11],
uh:[function(a){this.C.ic(J.d7(this.b),J.d_(this.b))},"$0","gmW",0,0,0],
a7:[function(){this.siw(!1)
this.fu()
this.C.sGw(!0)
this.C.a7()
this.C.sq9(null)
this.C.sa36(null)
this.C.sGw(!1)},"$0","gd7",0,0,0],
hZ:[function(){this.siw(!1)
this.fu()},"$0","gkn",0,0,0],
fR:function(){this.Bm()
this.siw(!0)},
e4:function(){var z,y
this.yN()
this.soy(-1)
z=this.C
y=J.j(z)
y.sba(z,J.D(y.gba(z),1))},
w9:function(){this.C.ic(J.d7(this.b),J.d_(this.b))},
$isbZ:1,
$isc_:1},
aBl:{"^":"aM+o5;oy:x$?,vy:y$?",$iscK:1},
b9n:{"^":"d:46;",
$2:[function(a,b){a.gdA().spu(K.ay(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b9o:{"^":"d:46;",
$2:[function(a,b){a.gdA().saZC(K.ay(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
b9q:{"^":"d:46;",
$2:[function(a,b){J.Ht(a.gdA(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b9r:{"^":"d:46;",
$2:[function(a,b){a.gdA().sGJ(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b9s:{"^":"d:46;",
$2:[function(a,b){a.gdA().sa36(R.cF(b,16777215))},null,null,4,0,null,0,2,"call"]},
b9t:{"^":"d:46;",
$2:[function(a,b){a.gdA().saRA(K.aj(b,1))},null,null,4,0,null,0,2,"call"]},
b9u:{"^":"d:46;",
$2:[function(a,b){a.gdA().sq9(R.cF(b,16777215))},null,null,4,0,null,0,2,"call"]},
b9v:{"^":"d:46;",
$2:[function(a,b){a.gdA().sGD(K.aj(b,1))},null,null,4,0,null,0,2,"call"]},
b9w:{"^":"d:46;",
$2:[function(a,b){a.gdA().sQ0(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
b9x:{"^":"d:46;",
$2:[function(a,b){a.gdA().sQ1(K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
b9y:{"^":"d:46;",
$2:[function(a,b){a.gdA().sSW(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b9z:{"^":"d:46;",
$2:[function(a,b){a.gdA().sSX(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b9B:{"^":"d:46;",
$2:[function(a,b){a.gdA().sSY(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
b9C:{"^":"d:46;",
$2:[function(a,b){a.gdA().sa37(K.aj(b,11))},null,null,4,0,null,0,2,"call"]},
b9D:{"^":"d:46;",
$2:[function(a,b){a.gdA().saRB(K.kw(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
b9E:{"^":"d:46;",
$2:[function(a,b){a.gdA().saS7(K.aj(b,2))},null,null,4,0,null,0,2,"call"]},
b9F:{"^":"d:46;",
$2:[function(a,b){a.gdA().saS8(K.kw(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
b9G:{"^":"d:46;",
$2:[function(a,b){a.gdA().saK7(K.aV(b,null))},null,null,4,0,null,0,2,"call"]},
ajb:{"^":"agW;v,N,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,D,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gjQ:function(){return this.N},
sjQ:function(a){var z=this.N
if(z!=null)z.cu(this.ga6m())
this.N=a
if(a!=null)a.di(this.ga6m())
this.b_N(null)},
b_N:[function(a){var z,y,x,w,v,u,t,s
z=this.N
if(z==null){y=H.a([],[F.o])
x=$.F+1
$.F=x
w=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
z=new F.ee(!1,y,0,null,null,x,null,w,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.P(null,null,null,{func:1,v:true,args:[[P.K,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
z.ch=null
z.fI(F.hK(new F.dr(0,255,0,1),0,0))
z.fI(F.hK(new F.dr(0,0,0,1),0,50))}v=z.fK()
y=J.bc(v)
y.es(v,F.rb())
u=[]
if(J.Z(y.gm(v),1))for(y=y.gb5(v);y.u();){t=y.gF()
x=J.j(t)
w=x.giq(t)
s=H.dt(t.i("alpha"))
s.toString
u.push(new N.wd(w,s,J.R(x.gtj(t),100)))}else if(J.b(y.gm(v),1)){t=y.h(v,0)
y=J.j(t)
x=y.giq(t)
w=H.dt(t.i("alpha"))
w.toString
u.push(new N.wd(x,w,0))
y=y.giq(t)
w=H.dt(t.i("alpha"))
w.toString
u.push(new N.wd(y,w,1))}this.sa8l(u)},"$1","ga6m",2,0,5,11],
eD:function(a,b){var z,y,x,w
if(typeof b==="number"&&Math.floor(b)===b){this.a9Z(a,b)
return}if(!!J.n(a).$isb1){z=this.v.a
if(!z.O(0,a))z.l(0,a,new E.bY(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
z=$.F+1
$.F=z
x=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
w=new F.v(z,null,x,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.P(null,null,null,{func:1,v:true,args:[[P.K,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
w.A("fillType",!0).W("gradient")
w.A("gradient",!0).$2(b,!1)
w.A("gradientType",!0).W("linear")
y.jl(w)}},
a7:[function(){var z=this.N
if(z!=null){z.cu(this.ga6m())
this.N=null}this.atN()},"$0","gd7",0,0,0],
axv:function(){var z=$.$get$BA()
if(J.b(z.ry,0)){z.fI(F.hK(new F.dr(0,255,0,1),1,0))
z.fI(F.hK(new F.dr(255,255,0,1),1,50))
z.fI(F.hK(new F.dr(255,0,0,1),1,100))}},
ae:{
ajc:function(){var z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.ajb(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.cy=P.hB()
z.axk()
z.axv()
return z}}},
Cz:{"^":"aBm;b6,dA:C@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bU,c2,c4,bx,bX,bW,c3,c5,c8,c_,bH,cd,cL,cv,cw,cz,co,cA,cB,cH,ce,cq,cr,cb,c9,cM,cj,cC,cD,bL,cc,cf,cE,cI,ck,cp,cN,cX,cJ,cs,cO,cP,cV,cg,cQ,cR,cl,cS,cW,cT,D,v,N,S,U,Y,V,G,a_,P,at,ag,a6,ac,af,al,ar,aa,aG,aN,aR,ai,aI,aA,aE,am,ao,aF,aO,av,aW,b_,b4,be,b9,b8,aY,aZ,bn,aV,bh,aT,bE,bu,bi,bf,bm,aS,bG,br,bd,bo,bO,bA,bp,bQ,bF,bV,bC,bP,bD,bq,bc,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gds:function(){return this.b6},
sf3:function(a,b){if(J.b(this.G,"none")&&!J.b(b,"none")){this.lt(this,b)
this.e4()}else this.lt(this,b)},
hH:[function(a){this.mK(a)
this.siw(!0)},"$1","gfo",2,0,2,11],
uh:[function(a){this.w9()},"$0","gmW",0,0,0],
a7:[function(){this.siw(!1)
this.fu()
this.C.sGw(!0)
this.C.a7()
this.C.sjQ(null)
this.C.sGw(!1)},"$0","gd7",0,0,0],
hZ:[function(){this.siw(!1)
this.fu()},"$0","gkn",0,0,0],
fR:function(){this.Bm()
this.siw(!0)},
e4:function(){var z,y
this.yN()
this.soy(-1)
z=this.C
y=J.j(z)
y.sba(z,J.D(y.gba(z),1))},
w9:function(){if(this.a instanceof F.v)this.C.ic(J.d7(this.b),J.d_(this.b))},
$isbZ:1,
$isc_:1},
aBm:{"^":"aM+o5;oy:x$?,vy:y$?",$iscK:1},
b8L:{"^":"d:65;",
$2:[function(a,b){a.gdA().spu(K.ay(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b8M:{"^":"d:65;",
$2:[function(a,b){J.Ht(a.gdA(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8N:{"^":"d:65;",
$2:[function(a,b){a.gdA().sGJ(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8O:{"^":"d:65;",
$2:[function(a,b){a.gdA().saXq(K.kw(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
b8P:{"^":"d:65;",
$2:[function(a,b){a.gdA().saXo(K.kw(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
b8Q:{"^":"d:65;",
$2:[function(a,b){a.gdA().sj4(K.ay(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
b8R:{"^":"d:65;",
$2:[function(a,b){var z=a.gdA()
z.sjQ(b!=null?F.pk(b):$.$get$BA())},null,null,4,0,null,0,2,"call"]},
b8T:{"^":"d:65;",
$2:[function(a,b){a.gdA().sQ0(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
b8U:{"^":"d:65;",
$2:[function(a,b){a.gdA().sQ1(K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
b8V:{"^":"d:65;",
$2:[function(a,b){a.gdA().sSW(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b8W:{"^":"d:65;",
$2:[function(a,b){a.gdA().sSX(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b8X:{"^":"d:65;",
$2:[function(a,b){a.gdA().sSY(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
xj:{"^":"r;a7m:a@,ii:b@,iP:c@"},
agd:{"^":"le;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,c,d,e,f,r,x,y,z,Q,ch,a,b",
gpT:function(){return this.r1},
spT:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cm()}},
gcG:function(){return this.r2},
scG:function(a){this.aYd(a)},
gjR:function(){return this.go},
iC:function(a,b){var z,y,x,w
this.Ex(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.hB()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.c(a)+"px"
z.width=y
z=this.id.style
y=H.c(b)+"px"
z.height=y
this.f1(this.k1,0,0,"none")
this.eD(this.k1,this.r2.cd)
z=this.k2
y=this.r2
this.f1(z,y.c8,J.aN(y.c_),this.r2.bH)
y=this.k3
z=this.r2
this.f1(y,z.c8,J.aN(z.c_),this.r2.bH)
z=this.db
if(z===2){z=J.Z(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a6(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.ax(a))
y=this.k1
y.toString
y.setAttribute("height",J.a6(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a6(J.Q(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.ax(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.c.ax(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.c(this.cy.b)+" L "+H.c(a)+","+H.c(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.c(J.Q(this.cy.b,this.r1.b))+" L "+H.c(a)+","+H.c(J.Q(this.cy.b,this.r1.b)))}else if(z===1){z=J.Z(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a6(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a6(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.ax(b))}else{x.toString
x.setAttribute("x",J.a6(J.Q(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.c.ax(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.ax(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.c(this.cy.a)+",0 L "+H.c(this.cy.a)+","+H.c(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.c(J.Q(this.cy.a,this.r1.a))+",0 L "+H.c(J.Q(this.cy.a,this.r1.a))+","+H.c(b))}else if(z===3){z=J.Z(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a6(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a6(this.r1.a))}else{y.toString
y.setAttribute("x",J.a6(J.Q(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.c.ax(0-y))}z=J.Z(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a6(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a6(this.r1.b))}else{y.toString
y.setAttribute("y",J.a6(J.Q(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.c.ax(0-y))}z=this.k1
y=this.r2
this.f1(z,y.c8,J.aN(y.c_),this.r2.bH)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
aYd:function(a){var z
this.a5y()
this.a5z()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().H(0)
this.r2.qr(0,"CartesianChartZoomerReset",this.gaih())}this.r2=a
if(a!=null){z=J.cC(a.cx)
z=H.a(new W.C(0,z.a,z.b,W.B(this.gaIf()),z.c),[H.x(z,0)])
z.t()
this.fx.push(z)
this.r2.nI(0,"CartesianChartZoomerReset",this.gaih())}this.dx=null
this.dy=null},
Kg:function(a){var z,y,x,w,v
z=this.I0(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.O)(z),++x){v=J.n(z[x])
if(!(!!v.$isqD||!!v.$ishR||!!v.$isiH))return!1}return!0},
aqa:function(a){var z=J.n(a)
if(!!z.$isiH)return J.b5(a.db)?null:a.db
else if(!!z.$isqG)return a.db
return 0/0},
Wb:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiH){if(b==null)z=null
else{z=J.bv(b)
y=!a.al
x=new P.ai(z,y)
x.ey(z,y)
z=x}a.sii(z)}else if(!!z.$ishR)a.sii(b)
else if(!!z.$isqD)a.sii(b)},
arN:function(a,b){return this.Wb(a,b,!1)},
aq8:function(a){var z=J.n(a)
if(!!z.$isiH)return J.b5(a.cy)?null:a.cy
else if(!!z.$isqG)return a.cy
return 0/0},
Wa:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiH){if(b==null)z=null
else{z=J.bv(b)
y=!a.al
x=new P.ai(z,y)
x.ey(z,y)
z=x}a.siP(z)}else if(!!z.$ishR)a.siP(b)
else if(!!z.$isqD)a.siP(b)},
arM:function(a,b){return this.Wa(a,b,!1)},
a7h:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[N.dZ,L.xj])),[N.dZ,L.xj])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[N.dZ,L.xj])),[N.dZ,L.xj])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.I0(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.O)(v),++u){t=v[u]
s=x.a
if(!s.O(0,t)){r=J.n(t)
r=!!r.$isqD||!!r.$ishR||!!r.$isiH}else r=!1
if(r)s.l(0,t,new L.xj(!1,this.aqa(t),this.aq8(t)))}}y=this.cy
if(z){y=y.b
q=P.aC(y,J.Q(y,b))
y=this.cy.b
p=P.aB(y,J.Q(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aC(y,J.Q(y,b))
y=this.cy.a
m=P.aB(y,J.Q(y,b))
o="h"
q=null
p=null}l=[]
k=N.jt(this.r2.aa,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof N.jH))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.ar:f.al
r=J.n(h)
if(!(!!r.$isqD||!!r.$ishR||!!r.$isiH)){g=f
break c$0}if(J.bG(C.a.cF(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=Q.b6(y,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcG()),e).b)
if(typeof q!=="number")return q.w()
y=H.a(new P.H(0,q-y),[null])
y=f.fr.p1([J.D(y.a,C.c.E(f.cy.offsetLeft)),J.D(y.b,C.c.E(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
j=y[1]
e=Q.b6(f.cy,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcG()),e).b)
if(typeof p!=="number")return p.w()
y=H.a(new P.H(0,p-y),[null])
y=f.fr.p1([J.D(y.a,C.c.E(f.cy.offsetLeft)),J.D(y.b,C.c.E(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
i=y[1]}else{e=Q.b6(y,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcG()),e).a)
if(typeof m!=="number")return m.w()
y=H.a(new P.H(m-y,0),[null])
y=f.fr.p1([J.D(y.a,C.c.E(f.cy.offsetLeft)),J.D(y.b,C.c.E(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
j=y[0]
e=Q.b6(f.cy,H.a(new P.H(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcG()),e).a)
if(typeof n!=="number")return n.w()
y=H.a(new P.H(n-y,0),[null])
y=f.fr.p1([J.D(y.a,C.c.E(f.cy.offsetLeft)),J.D(y.b,C.c.E(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
i=y[0]}if(J.aI(i,j)){d=i
i=j
j=d}this.arN(h,j)
this.arM(h,i)
this.fr=!0
break}k.length===y||(0,H.O)(k);++u}if(!this.fr)return
x.a.h(0,h).sa7m(!0)
if(h!=null&&!c){y=this.r2
if(z){y.c3=j
y.c5=i
y.aoP()}else{y.bx=j
y.bX=i
y.aoc()}}},
apm:function(a,b){return this.a7h(a,b,!1)},
amL:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.I0(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.O)(y),++u){t=y[u]
if(w.O(0,t)){this.Wb(t,w.h(0,t).gii(),!0)
this.Wa(t,w.h(0,t).giP(),!0)
if(w.h(0,t).ga7m())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.bx=0/0
x.bX=0/0
x.aoc()}},
a5y:function(){return this.amL(!1)},
amP:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.I0(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.O)(y),++u){t=y[u]
if(w.O(0,t)){this.Wb(t,w.h(0,t).gii(),!0)
this.Wa(t,w.h(0,t).giP(),!0)
if(w.h(0,t).ga7m())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.c3=0/0
x.c5=0/0
x.aoP()}},
a5z:function(){return this.amP(!1)},
apn:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.a2(a)
if(z.gjI(a)||J.b5(b)){if(this.fr)if(c)this.amP(!0)
else this.amL(!0)
return}if(!this.Kg(c))return
y=this.I0(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aqt(x)
if(w==null)return
v=J.n(b)
if(c){u=J.Q(w.FH(["0",z.ax(a)]).b,this.a8j(w))
t=J.Q(w.FH(["0",v.ax(b)]).b,this.a8j(w))
this.cy=H.a(new P.H(50,u),[null])
this.a7h(2,J.D(t,u),!0)}else{s=J.Q(w.FH([z.ax(a),"0"]).a,this.a8i(w))
r=J.Q(w.FH([v.ax(b),"0"]).a,this.a8i(w))
this.cy=H.a(new P.H(s,50),[null])
this.a7h(1,J.D(r,s),!0)}},
I0:function(a){var z,y,x,w,v,u,t
z=[]
y=N.jt(this.r2.aa,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.O)(y),++v){u=y[v]
if(!(u instanceof N.jH))continue
if(a){t=u.ar
if(t!=null&&J.aI(C.a.cF(z,t),0))z.push(u.ar)}else{t=u.al
if(t!=null&&J.aI(C.a.cF(z,t),0))z.push(u.al)}w=u}return z},
aqt:function(a){var z,y,x,w,v
z=N.jt(this.r2.aa,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.O)(z),++w){v=z[w]
if(!(v instanceof N.jH))continue
if(J.b(v.ar,a)||J.b(v.al,a))return v
x=v}return},
a8i:function(a){var z=Q.b6(a.cy,H.a(new P.H(0,0),[null]))
return J.aN(Q.aP(J.as(a.gcG()),z).a)},
a8j:function(a){var z=Q.b6(a.cy,H.a(new P.H(0,0),[null]))
return J.aN(Q.aP(J.as(a.gcG()),z).b)},
f1:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.O(0,a))z.h(0,a).jt(null)
R.oG(a,b,c,d)
return}if(!!J.n(a).$isb1){z=this.k4.a
if(!z.O(0,a))z.l(0,a,new E.bY(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jt(b)
y.skP(c)
y.skx(d)}},
eD:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.O(0,a))z.h(0,a).jl(null)
R.t3(a,b)
return}if(!!J.n(a).$isb1){z=this.k4.a
if(!z.O(0,a))z.l(0,a,new E.bY(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jl(b)}},
b5l:[function(a){var z,y
z=this.r2
if(!z.c2&&!z.bW)return
z.cx.appendChild(this.go)
z=this.r2
this.ic(z.Q,z.ch)
this.cy=Q.aP(this.go,J.cD(a))
this.cx=!0
z=this.fy
y=C.B.cZ(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gaqL()),y.c),[H.x(y,0)])
y.t()
z.push(y)
y=C.E.cZ(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gaqM()),y.c),[H.x(y,0)])
y.t()
z.push(y)
y=C.a2.cZ(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gG3()),y.c),[H.x(y,0)])
y.t()
z.push(y)
this.db=0
this.spT(null)},"$1","gaIf",2,0,4,4],
b20:[function(a){var z,y
z=Q.aP(this.go,J.cD(a))
if(this.db===0)if(this.r2.c4){if(!(this.Kg(!0)&&this.Kg(!1))){this.Fw()
return}if(J.bG(J.fN(J.D(z.a,this.cy.a)),2)&&J.bG(J.fN(J.D(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.Z(J.fN(J.D(z.b,this.cy.b)),J.fN(J.D(z.a,this.cy.a)))){if(this.Kg(!0))this.db=2
else{this.Fw()
return}y=2}else{if(this.Kg(!1))this.db=1
else{this.Fw()
return}y=1}if(y===1)if(!this.r2.c2){this.Fw()
return}if(y===2)if(!this.r2.bW){this.Fw()
return}}y=this.r2
if(P.bf(0,0,y.Q,y.ch,null).oX(0,z)){y=this.db
if(y===2)this.spT(H.a(new P.H(0,J.D(z.b,this.cy.b)),[null]))
else if(y===1)this.spT(H.a(new P.H(J.D(z.a,this.cy.a),0),[null]))
else if(y===3)this.spT(H.a(new P.H(J.D(z.a,this.cy.a),J.D(z.b,this.cy.b)),[null]))
else this.spT(null)}},"$1","gaqL",2,0,4,4],
b21:[function(a){var z,y
for(z=this.fy;z.length>0;)z.pop().H(0)
J.a4(this.go)
this.cx=!1
this.cm()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.apm(2,z.b)
z=this.db
if(z===1||z===3)this.apm(1,this.r1.a)}else{this.a5y()
F.a9(new L.agf(this))}},"$1","gaqM",2,0,4,4],
aid:[function(a){if(Q.cT(a)===27)this.Fw()},"$1","gG3",2,0,6,4],
Fw:function(){for(var z=this.fy;z.length>0;)z.pop().H(0)
J.a4(this.go)
this.cx=!1
this.cm()},
b7F:[function(a){this.a5y()
F.a9(new L.agg(this))},"$1","gaih",2,0,7,4],
axg:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.z(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ae:{
age:function(){var z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.agd(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.axg()
return z}}},
agf:{"^":"d:3;a",
$0:[function(){this.a.a5z()},null,null,0,0,null,"call"]},
agg:{"^":"d:3;a",
$0:[function(){this.a.a5z()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.bu,args:[F.v,P.e,P.bu]},{func:1,v:true,args:[[P.K,P.e]]},{func:1,ret:Q.bZ},{func:1,v:true,args:[W.cL]},{func:1,v:true,args:[P.r]},{func:1,v:true,args:[W.h5]},{func:1,v:true,args:[E.ci]},{func:1,ret:P.e,args:[N.kQ]}]
init.types.push.apply(init.types,deferredTypes)
$.P0=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["WP","$get$WP",function(){return P.m(["scaleType",new L.b8Y(),"offsetLeft",new L.b8Z(),"offsetRight",new L.b9_(),"minimum",new L.b90(),"maximum",new L.b91(),"formatString",new L.b93(),"showMinMaxOnly",new L.b94(),"percentTextSize",new L.b95(),"labelsColor",new L.b96(),"labelsFontFamily",new L.b97(),"labelsFontStyle",new L.b98(),"labelsFontWeight",new L.b99(),"labelsTextDecoration",new L.b9a(),"labelsLetterSpacing",new L.b9b(),"labelsRotation",new L.b9c(),"labelsAlign",new L.b9f(),"angleFrom",new L.b9g(),"angleTo",new L.b9h(),"percentOriginX",new L.b9i(),"percentOriginY",new L.b9j(),"percentRadius",new L.b9k(),"majorTicksCount",new L.b9l(),"justify",new L.b9m()])},$,"WQ","$get$WQ",function(){var z=P.ah()
z.q(0,E.fr())
z.q(0,$.$get$WP())
return z},$,"WR","$get$WR",function(){return P.m(["scaleType",new L.b9n(),"ticksPlacement",new L.b9o(),"offsetLeft",new L.b9q(),"offsetRight",new L.b9r(),"majorTickStroke",new L.b9s(),"majorTickStrokeWidth",new L.b9t(),"minorTickStroke",new L.b9u(),"minorTickStrokeWidth",new L.b9v(),"angleFrom",new L.b9w(),"angleTo",new L.b9x(),"percentOriginX",new L.b9y(),"percentOriginY",new L.b9z(),"percentRadius",new L.b9B(),"majorTicksCount",new L.b9C(),"majorTicksPercentLength",new L.b9D(),"minorTicksCount",new L.b9E(),"minorTicksPercentLength",new L.b9F(),"cutOffAngle",new L.b9G()])},$,"WS","$get$WS",function(){var z=P.ah()
z.q(0,E.fr())
z.q(0,$.$get$WR())
return z},$,"WT","$get$WT",function(){return P.m(["scaleType",new L.b8L(),"offsetLeft",new L.b8M(),"offsetRight",new L.b8N(),"percentStartThickness",new L.b8O(),"percentEndThickness",new L.b8P(),"placement",new L.b8Q(),"gradient",new L.b8R(),"angleFrom",new L.b8T(),"angleTo",new L.b8U(),"percentOriginX",new L.b8V(),"percentOriginY",new L.b8W(),"percentRadius",new L.b8X()])},$,"WU","$get$WU",function(){var z=P.ah()
z.q(0,E.fr())
z.q(0,$.$get$WT())
return z},$])}
$dart_deferred_initializers$["zOI3gnenqPN3tQ0gX7UidcqHGOY="]=$dart_deferred_initializers$.current

//# sourceMappingURL=remote_dataflow.dart.js_1.part.js.map
