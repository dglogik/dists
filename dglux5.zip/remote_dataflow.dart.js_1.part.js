self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,N,{"^":"",
aCA:function(){var z=document
z=z.createElement("div")
z=new N.Eh(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.oI()
z.abg()
return z},
ago:{"^":"I8;",
sq0:["auc",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cA()}}],
sGk:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cA()}},
sGl:function(a){if(!J.b(this.rx,a)){this.rx=a
this.cA()}},
sGm:function(a){if(!J.b(this.ry,a)){this.ry=a
this.cA()}},
sGo:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cA()}},
sGn:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cA()}},
saRF:function(a){if(!J.b(this.y1,a)){if(J.Z(a,180))a=180
this.y1=J.aG(a,-180)?-180:a
this.cA()}},
saRE:function(a){if(J.b(this.y2,a))return
this.y2=a
this.cA()},
gii:function(){return this.C},
sii:function(a){if(a==null)a=0
if(!J.b(this.C,a)){this.C=a
this.cA()}},
giO:function(){return this.v},
siO:function(a){if(a==null)a=100
if(!J.b(this.v,a)){this.v=a
this.cA()}},
saYt:function(a){if(this.L!==a){this.L=a
this.cA()}},
samd:function(a,b){if(b==null||J.aG(b,0))b=0
if(J.Z(b,4))b=4
if(!J.b(this.R,b)){this.R=b
this.cA()}},
sasF:function(a){if(this.S!==a){this.S=a
this.cA()}},
svo:function(a){this.W=a
this.cA()},
gpp:function(){return this.D},
spp:function(a){if(!J.b(this.D,a)){this.D=a
this.cA()}},
saRu:function(a){if(!J.b(this.Z,a)){this.Z=a
this.cA()}},
guc:function(a){return this.M},
suc:["aaa",function(a,b){if(!J.b(this.M,b))this.M=b}],
sGH:["aab",function(a){if(!J.b(this.aq,a))this.aq=a}],
sa3h:function(a){this.aad(a)
this.cA()},
iD:function(a,b){this.Ez(a,b)
this.MQ()
if(J.b(this.D,"circular"))this.aYE(a,b)
else this.aYF(a,b)},
MQ:function(){var z,y,x,w,v
z=this.S
y=this.k2
if(z){y.se8(0,2)
z=this.k2.f
if(0>=z.length)return H.f(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isd5)z.sbR(x,this.a0z(this.C,this.R))
J.a6(J.bf(x.gaE()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.f(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isd5)z.sbR(x,this.a0z(this.v,this.R))
J.a6(J.bf(x.gaE()),"text-decoration",this.x1)}else{y.se8(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.f(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isd5){y=this.C
w=J.R(y,J.ac(J.di(J.E(this.v,y),J.E(this.fy,1)),v))
z.sbR(x,this.a0z(w,this.R))}J.a6(J.bf(x.gaE()),"text-decoration",this.x1);++v}}this.eA(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.c(this.x2)+"px")},
aYE:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.di(J.E(this.fr,this.dy),z-1)
x=P.az(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.di(a,2)
x=P.az(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.E(w,x*(50-u)/100)
u=J.di(b,2)
x=P.az(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.E(u,x*(50-w)/100)
r=C.c.K(this.L,"%")&&!0
x=this.L
if(r){H.cy("")
x=H.ea(x,"%","")}q=P.fN(x,null)
for(x=J.c0(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.f(w,p)
o=w[p]
w=J.R(J.E(this.dy,90),x.b9(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.I9(o)
w=m.b
u=J.a2(w)
if(u.bJ(w,0)){if(r){l=P.az(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.di(l,w)}else k=0
l=m.a
j=J.c0(l)
i=J.R(j.b9(l,l),u.b9(w,w))
if(typeof i!=="number")H.ag(H.bE(i))
i=Math.sqrt(i)
h=J.ac(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.Z){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.ac(j.de(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.ac(u.de(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a6(J.bf(o.gaE()),"transform","")
i=J.n(o)
if(!!i.$iscJ)i.ix(o,d,c)
else E.er(o.gaE(),d,c)
i=J.bf(o.gaE())
h=J.L(i)
h.m(i,"transform",J.R(h.h(i,"transform")," scale ("+H.c(k)+")"))
if(!J.b(this.y1,0))if(!!J.n(o.gaE()).$isn7){i=J.bf(o.gaE())
h=J.L(i)
h.m(i,"transform",J.R(h.h(i,"transform")," rotate("+H.c(this.y1)+" "+H.c(j.de(l,2))+" "+H.c(J.di(u.fw(w),2))+")"))}else{J.k9(J.I(o.gaE())," rotate("+H.c(this.y1)+"deg)")
J.nr(J.I(o.gaE()),H.c(J.ac(j.de(l,2),k))+" "+H.c(J.ac(u.de(w,2),k)))}}},
aYF:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.di(J.E(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.f(x,0)
w=this.I9(x[0])
v=C.c.K(this.L,"%")&&!0
x=this.L
if(v){H.cy("")
x=H.ea(x,"%","")}u=P.fN(x,null)
x=w.b
t=J.a2(x)
if(t.bJ(x,0))s=J.di(v?J.di(J.ac(a,u),200):u,x)
else s=0
r=J.di(J.ac(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ab(r)))
p=Math.abs(Math.sin(H.ab(r)))
this.aaa(this,J.ac(J.di(J.R(J.ac(w.a,q),t.b9(x,p)),2),s))
this.UL()
x=this.k2.f
if(y<0||y>=x.length)return H.f(x,y)
w=this.I9(x[y])
x=w.b
t=J.a2(x)
if(t.bJ(x,0))s=J.di(v?J.di(J.ac(a,u),200):u,x)
else s=0
this.aab(J.ac(J.di(J.R(J.ac(w.a,q),t.b9(x,p)),2),s))
this.UL()
if(!J.b(this.y1,0)){for(x=J.c0(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.f(t,n)
w=this.I9(t[n])
t=w.b
m=J.a2(t)
if(m.bJ(t,0))J.di(v?J.di(x.b9(a,u),200):u,t)
o=P.aC(J.R(J.ac(w.a,p),m.b9(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.a2(a)
k=J.di(J.E(x.A(a,this.M),this.aq),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.f(y,n)
j=y[n]
y=this.M
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.R(y,t)
w=this.I9(j)
y=w.b
m=J.a2(y)
if(m.bJ(y,0))s=J.di(v?J.di(x.b9(a,u),200):u,y)
else s=0
h=w.a
g=J.a2(h)
i=J.E(i,J.ac(g.de(h,2),s))
J.a6(J.bf(j.gaE()),"transform","")
if(J.b(this.y1,0)){y=J.ac(J.R(g.b9(h,p),m.b9(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$iscJ)y.ix(j,i,f)
else E.er(j.gaE(),i,f)
y=J.bf(j.gaE())
t=J.L(y)
t.m(y,"transform",J.R(t.h(y,"transform")," scale ("+H.c(s)+")"))}else{i=J.E(J.R(this.M,t),g.de(h,2))
t=J.R(g.b9(h,p),m.b9(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$iscJ)t.ix(j,i,e)
else E.er(j.gaE(),i,e)
d=g.de(h,2)
c=-y/2
y=J.bf(j.gaE())
t=J.L(y)
m=s-1
t.m(y,"transform",J.R(t.h(y,"transform")," translate("+H.c(J.ac(J.dB(d),m))+" "+H.c(-c*m)+")"))
m=J.bf(j.gaE())
y=J.L(m)
y.m(m,"transform",J.R(y.h(m,"transform")," scale ("+H.c(s)+")"))
m=J.bf(j.gaE())
y=J.L(m)
y.m(m,"transform",J.R(y.h(m,"transform")," rotate("+H.c(this.y1)+" "+H.c(d)+" "+H.c(c)+")"))}}},
I9:function(a){var z,y,x,w
if(!!J.n(a.gaE()).$ises){z=H.k(a.gaE(),"$ises").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.b9()
w=x*0.7}else{y=J.d6(a.gaE())
y.toString
w=J.d2(a.gaE())
w.toString}return H.a(new P.J(y,w),[null])},
a0G:[function(){return N.Bm()},"$0","gtR",0,0,3],
a0z:function(a,b){var z=this.W
if(z==null||J.b(z,""))return U.nf(a,"0")
else return U.nf(a,this.W)},
a7:[function(){this.aad(0)
this.cA()
var z=this.k2
z.d=!0
z.r=!0
z.se8(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gd6",0,0,0],
axS:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.z(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new N.mU(this.gtR(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
I8:{"^":"le;",
gXA:function(){return this.cy},
sT6:["aug",function(a){if(a==null)a=50
if(J.aG(a,0))a=0
if(J.Z(a,100))a=100
if(!J.b(this.db,a)){this.db=a
this.cA()}}],
sT7:["auh",function(a){if(a==null)a=50
if(J.aG(a,0))a=0
if(J.Z(a,100))a=100
if(!J.b(this.dx,a)){this.dx=a
this.cA()}}],
sQ5:["aud",function(a){if(J.aG(a,-360))a=-360
if(J.Z(a,360))a=360
if(!J.b(this.dy,a)){this.dy=a
this.dU()
this.cA()}}],
safb:["aue",function(a,b){if(J.aG(b,-360))b=-360
if(J.Z(b,360))b=360
if(!J.b(this.fr,b)){this.fr=b
this.dU()
this.cA()}}],
saT8:function(a){if(a==null||J.aG(a,0))a=0
if(J.Z(a,20))a=20
if(!J.b(this.fx,a)){this.fx=a
this.cA()}},
sa3h:["aad",function(a){if(a==null||J.aG(a,2))a=2
if(J.Z(a,30))a=30
if(!J.b(this.fy,a)){this.fy=a
this.cA()}}],
saT9:function(a){if(this.go!==a){this.go=a
this.cA()}},
saSE:function(a){if(this.id!==a){this.id=a
this.cA()}},
sT8:["aui",function(a){if(a==null||J.aG(a,0))a=0
if(J.Z(a,200))a=200
if(!J.b(this.k1,a)){this.k1=a
this.cA()}}],
gjP:function(){return this.cy},
eZ:["auf",function(a,b,c,d){R.oz(a,b,c,d)}],
eA:["aac",function(a,b){R.rZ(a,b)}],
zg:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.j(a)
if(y!=="")J.a6(z.gfu(a),"d",y)
else J.a6(z.gfu(a),"d","M 0,0")}},
agp:{"^":"I8;",
sa3g:["auj",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cA()}}],
saSD:function(a){if(!J.b(this.r2,a)){this.r2=a
this.cA()}},
sq2:["auk",function(a){if(!J.b(this.rx,a)){this.rx=a
this.cA()}}],
sGB:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cA()}},
gpp:function(){return this.x2},
spp:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cA()}},
guc:function(a){return this.y1},
suc:function(a,b){if(!J.b(this.y1,b)){this.y1=b
this.cA()}},
sGH:function(a){if(!J.b(this.y2,a)){this.y2=a
this.cA()}},
sb_E:function(a){if(!J.b(this.I,a)){this.I=a
this.cA()}},
saKW:function(a){var z
if(!J.b(this.C,a)){this.C=a
if(a!=null){z=J.E(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.v=z
this.cA()}},
iD:function(a,b){var z,y
this.Ez(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.eZ(this.k2,this.k4,J.aN(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.eZ(this.k3,this.rx,J.aN(this.x1),this.ry)
if(J.b(this.x2,"circular"))this.aML(a,b)
else this.aMM(a,b)},
aML:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.di(J.E(this.fr,this.dy),J.E(J.R(J.ac(this.fx,J.E(this.fy,1)),this.fy),1))
x=C.c.K(this.go,"%")&&!0
w=this.go
if(x){H.cy("")
w=H.ea(w,"%","")}v=P.fN(w,null)
if(x){w=P.az(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.az(a,b)
w=J.di(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.E(w,t*(50-s)/100)
s=J.di(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.E(s,t*(50-w)/100)
w=P.az(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.b(this.I,"center"))o=0.5
else o=J.b(this.I,"outside")?1:0
w=o-1
s=J.c0(y)
n=0
while(!0){m=J.R(J.ac(this.fx,J.E(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.R(J.E(this.dy,90),s.b9(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++n}this.zg(this.k3)
z.a=""
y=J.di(J.E(this.fr,this.dy),J.E(this.fy,1))
h=C.c.K(this.id,"%")&&!0
s=this.id
if(h){H.cy("")
s=H.ea(s,"%","")}g=P.fN(s,null)
if(h){s=P.az(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.c0(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.R(J.E(this.dy,90),s.b9(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++f}this.zg(this.k2)},
aMM:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.K(this.go,"%")&&!0
y=this.go
if(z){H.cy("")
y=H.ea(y,"%","")}x=P.fN(y,null)
w=z?J.di(J.ac(J.di(a,2),x),100):x
v=C.c.K(this.id,"%")&&!0
y=this.id
if(v){H.cy("")
y=H.ea(y,"%","")}u=P.fN(y,null)
t=v?J.di(J.ac(J.di(a,2),u),100):u
y=this.cx
y.a=""
s=J.a2(a)
r=J.di(J.E(s.A(a,this.y1),this.y2),J.E(J.R(J.ac(this.fx,J.E(this.fy,1)),this.fy),1))
if(J.b(this.I,"center"))q=0.5
else q=J.b(this.I,"outside")?1:0
p=J.a2(t)
o=p.A(t,w)
n=1-q
m=0
while(!0){l=J.R(J.ac(this.fx,J.E(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.A(t,q*o)
y.a+="M "+H.c(k)+","+H.c(n*o)+" "
y.a+="L "+H.c(k)+","+H.c(j)+" ";++m}this.zg(this.k3)
y.a=""
r=J.di(J.E(s.A(a,this.y1),this.y2),J.E(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.c(k)+",0 "
y.a+="L "+H.c(k)+","+H.c(t)+" ";++i}this.zg(this.k2)},
a7:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.zg(z)
this.zg(this.k3)}},"$0","gd6",0,0,0]},
agq:{"^":"I8;",
sT6:function(a){this.aug(a)
this.r2=!0},
sT7:function(a){this.auh(a)
this.r2=!0},
sQ5:function(a){this.aud(a)
this.r2=!0},
safb:function(a,b){this.aue(this,b)
this.r2=!0},
sT8:function(a){this.aui(a)
this.r2=!0},
saYs:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.cA()}},
saYq:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.cA()}},
sa8w:function(a){if(this.x2!==a){this.x2=a
this.dU()
this.cA()}},
gj3:function(){return this.y1},
sj3:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.b(this.y1,a)){this.y1=a
this.r2=!0
this.cA()}},
gpp:function(){return this.y2},
spp:function(a){if(!J.b(this.y2,a)){this.y2=a
this.r2=!0
this.cA()}},
guc:function(a){return this.I},
suc:function(a,b){if(!J.b(this.I,b)){this.I=b
this.r2=!0
this.cA()}},
sGH:function(a){if(!J.b(this.C,a)){this.C=a
this.r2=!0
this.cA()}},
jd:function(){var z,y,x,w,v,u,t,s,r
this.yN()
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.O)(z),++u){t=z[u]
s=J.j(t)
y.push(s.gic(t))
x.push(s.gBT(t))
w.push(s.gtj(t))}if(J.iw(J.E(this.dy,this.fr))===!0){z=J.ha(J.E(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.m.E(0.5*z)}else r=0
this.k2=this.aJP(y,w,r)
this.k3=this.aHm(x,w,r)
this.r2=!0},
iD:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.Ez(a,b)
z=J.c0(a)
y=J.c0(b)
E.Eb(this.k4,z.b9(a,1),y.b9(b,1))
if(J.b(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.az(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.b(this.y2,"circular")){z=P.aC(0,P.az(a,b))
this.rx=z
this.aMO(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.c(this.rx)+" "+H.c(this.rx))}else{z=J.ac(J.E(z.A(a,this.I),this.C),1)
y.b9(b,1)
v=C.c.K(this.ry,"%")&&!0
y=this.ry
if(v){H.cy("")
y=H.ea(y,"%","")}u=P.fN(y,null)
t=v?J.Q(J.ac(z,u),100):u
s=C.c.K(this.x1,"%")&&!0
y=this.x1
if(s){H.cy("")
y=H.ea(y,"%","")}r=P.fN(y,null)
q=s?J.Q(J.ac(z,r),100):r
this.r1.se8(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.E(q,t)
p=q
o=p
m=0
break
case"cross":y=J.a0(q)
x=J.a0(t)
o=J.R(y.de(q,2),x.de(t,2))
n=J.E(y.de(q,2),x.de(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.a(new P.J(this.I,o),[null])
k=H.a(new P.J(this.I,n),[null])
j=H.a(new P.J(J.R(this.I,z),p),[null])
i=H.a(new P.J(J.R(this.I,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.f(y,0)
h=y[0]
this.eA(h.gaE(),this.L)
R.oz(h.gaE(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.c(y)+","+H.c(x)+" "
z.a+="L "+H.c(j.a)+","+H.c(j.b)+" "
z.a+="L "+H.c(i.a)+","+H.c(i.b)+" "
z.a+="L "+H.c(k.a)+","+H.c(k.b)+" "
z.a+="L "+H.c(y)+","+H.c(x)+" "
this.zg(h.gaE())
x=this.cy
x.toString
new W.dK(x).J(0,"viewBox")}},
aJP:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.wZ(J.ac(J.E(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.f(a,y)
t=J.aZ(J.cM(a[y],16),255)
if(y>=a.length)return H.f(a,y)
s=J.aZ(J.cM(a[y],8),255)
if(y>=a.length)return H.f(a,y)
r=J.aZ(a[y],255)
if(x>=a.length)return H.f(a,x)
q=J.aZ(J.cM(a[x],16),255)
if(x>=a.length)return H.f(a,x)
p=J.aZ(J.cM(a[x],8),255)
if(x>=a.length)return H.f(a,x)
o=J.aZ(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.E(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.E(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.E(w*r+m*o)&255)>>>0)}}return z},
aHm:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.wZ(J.ac(J.E(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.f(a,x)
v=a[x]
if(y>=w)return H.f(a,y)
t=J.Q(J.E(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.f(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.R(w,s*t))}}return z},
aMO:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.az(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.K(this.ry,"%")&&!0
z=this.ry
if(v){H.cy("")
z=H.ea(z,"%","")}u=P.fN(z,new N.agr())
if(v){z=P.az(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.K(this.x1,"%")&&!0
z=this.x1
if(s){H.cy("")
z=H.ea(z,"%","")}r=P.fN(z,new N.ags())
if(s){z=P.az(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.az(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.az(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.se8(0,w)
for(z=J.a2(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.E(this.dy,90)
d=J.E(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.R(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.A(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.f(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.f(e,d)
g=J.bv(J.ac(e[d],255))
g=J.bN(J.b(g,0)?1:g,24)
e=h.gaE()
a3=this.k2
if(d>=a3.length)return H.f(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.eA(e,a3+g)
a3=h.gaE()
e=this.k2
if(d>=e.length)return H.f(e,d)
R.oz(a3,e[d]+g,1,"solid")
y.a+="M "+H.c(l)+","+H.c(k)+" "
y.a+="L "+H.c(a)+","+H.c(a0)+" "
y.a+="L "+H.c(a1)+","+H.c(a2)+" "
y.a+="L "+H.c(j)+","+H.c(i)+" "
y.a+="L "+H.c(l)+","+H.c(k)+" "
this.zg(h.gaE())}}},
bd9:[function(){var z,y
z=new N.a2Z(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gaYi",0,0,3],
a7:["aul",function(){var z=this.r1
z.d=!0
z.r=!0
z.se8(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gd6",0,0,0],
axT:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sa8w([new N.w9(65280,0.5,0),new N.w9(16776960,0.8,0.5),new N.w9(16711680,1,1)])
z=new N.mU(this.gaYi(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
agr:{"^":"d:0;",
$1:function(a){return 0}},
ags:{"^":"d:0;",
$1:function(a){return 0}},
w9:{"^":"r;ic:a*,BT:b>,tj:c>"}}],["","",,L,{"^":"",
bA9:[function(a){var z=!!J.n(a.gle().gaE()).$isfI?H.k(a.gle().gaE(),"$isfI"):null
if(z!=null)if(z.gnL()!=null&&!J.b(z.gnL(),""))return L.Sr(a.gle(),z.gnL())
else return z.G_(a)
return""},"$1","aXF",2,0,8,50],
bqo:function(){if($.OV)return
$.OV=!0
$.$get$hx().m(0,"percentTextSize",L.aXI())
$.$get$hx().m(0,"minorTicksPercentLength",L.a9D())
$.$get$hx().m(0,"majorTicksPercentLength",L.a9D())
$.$get$hx().m(0,"percentStartThickness",L.a9F())
$.$get$hx().m(0,"percentEndThickness",L.a9F())
$.$get$hy().m(0,"percentTextSize",L.aXJ())
$.$get$hy().m(0,"minorTicksPercentLength",L.a9E())
$.$get$hy().m(0,"majorTicksPercentLength",L.a9E())
$.$get$hy().m(0,"percentStartThickness",L.a9G())
$.$get$hy().m(0,"percentEndThickness",L.a9G())},
aXD:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$fa())
C.a.q(z,$.$get$BC())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$fa())
C.a.q(z,$.$get$CB())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$fa())
C.a.q(z,$.$get$Cz())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$fa())
C.a.q(z,$.$get$K0())
return z
case"linearAxis":return $.$get$v5()
case"logAxis":return $.$get$v7()
case"categoryAxis":return $.$get$rK()
case"datetimeAxis":return $.$get$uV()
case"axisRenderer":return $.$get$rF()
case"radialAxisRenderer":return $.$get$JU()
case"angularAxisRenderer":return $.$get$Ih()
case"linearAxisRenderer":return $.$get$rF()
case"logAxisRenderer":return $.$get$rF()
case"categoryAxisRenderer":return $.$get$rF()
case"datetimeAxisRenderer":return $.$get$rF()
case"lineSeries":return $.$get$v3()
case"areaSeries":return $.$get$Bi()
case"columnSeries":return $.$get$BF()
case"barSeries":return $.$get$Bq()
case"bubbleSeries":return $.$get$Bx()
case"pieSeries":return $.$get$xQ()
case"spectrumSeries":return $.$get$Kf()
case"radarSeries":return $.$get$xS()
case"lineSet":return $.$get$pV()
case"areaSet":return $.$get$Bk()
case"columnSet":return $.$get$BH()
case"barSet":return $.$get$Bs()
case"gridlines":return $.$get$J7()}return[]},
aXB:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof L.os)return a
else{z=$.$get$TE()
y=H.a([],[N.ew])
x=H.a([],[E.j8])
w=H.a([],[L.iF])
v=H.a([],[E.j8])
u=H.a([],[L.iF])
t=H.a([],[E.j8])
s=H.a([],[L.xn])
r=H.a([],[E.j8])
q=H.a([],[L.xT])
p=H.a([],[E.j8])
o=$.$get$at()
n=$.X+1
$.X=n
n=new L.os(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aw(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.S),null,null,null,null,null,null,null,!1,null,null,null,null)
n.c5(b,"chart")
J.a1(J.z(n.b),"absolute")
o=L.aip()
n.w=o
J.bs(n.b,o.cx)
o=n.w
o.bk=n
o.Nh()
o=L.afJ()
n.U=o
o.scS(n.w)
return n}case"scaleTicks":if(a instanceof L.CA)return a
else{z=$.$get$WW()
y=$.$get$at()
x=$.X+1
$.X=x
x=new L.CA(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aw(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.S),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c5(b,"scale-ticks")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.r,E.bW])),[P.r,E.bW])
z=new L.aiE(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cn(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.cy=P.hA()
x.w=z
J.bs(x.b,z.gXA())
return x}case"scaleLabels":if(a instanceof L.Cy)return a
else{z=$.$get$WU()
y=$.$get$at()
x=$.X+1
$.X=x
x=new L.Cy(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aw(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.S),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c5(b,"scale-labels")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.r,E.bW])),[P.r,E.bW])
z=new L.aiC(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cn(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.cy=P.hA()
z.axS()
x.w=z
J.bs(x.b,z.gXA())
x.w.se0(x)
return x}case"scaleTrack":if(a instanceof L.CC)return a
else{z=$.$get$WY()
y=$.$get$at()
x=$.X+1
$.X=x
x=new L.CC(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aw(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.S),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c5(b,"scale-track")
J.a1(J.z(x.b),"absolute")
J.lO(J.I(x.b),"hidden")
y=L.aiG()
x.w=y
J.bs(x.b,y.gXA())
return x}}return},
bAF:[function(){var z=new L.ajN(null,null,null)
z.ab5()
return z},"$0","aXG",0,0,3],
aip:function(){var z,y,x,w,v,u,t
z=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.r,E.bW])),[P.r,E.bW])
y=P.be(0,0,0,0,null)
x=P.be(0,0,0,0,null)
w=new N.cH(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.a([],[P.fc])
t=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,P.r])),[P.e,P.r])
z=new L.ny(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",N.aXK(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.axQ("chartBase")
z.axO()
z.ayA()
z.sRg("single")
z.ay2()
return z},
bHe:[function(a,b,c){return L.aWk(a,c)},"$3","aXI",6,0,1,15,32,1],
aWk:function(a,b){var z,y,x
z=a.G("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
return J.Q(J.ac(J.b(y.gpp(),"circular")?P.az(x.gbc(y),x.gbC(y)):x.gbc(y),b),200)},
bHf:[function(a,b,c){return L.aWl(a,c)},"$3","aXJ",6,0,1,15,32,1],
aWl:function(a,b){var z,y,x,w
z=a.G("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.ac(b,200)
w=J.j(y)
return J.Q(x,J.b(y.gpp(),"circular")?P.az(w.gbc(y),w.gbC(y)):w.gbc(y))},
bHg:[function(a,b,c){return L.aWm(a,c)},"$3","a9D",6,0,1,15,32,1],
aWm:function(a,b){var z,y,x
z=a.G("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
return J.Q(J.ac(J.b(y.gpp(),"circular")?P.az(x.gbc(y),x.gbC(y)):x.gbc(y),b),200)},
bHh:[function(a,b,c){return L.aWn(a,c)},"$3","a9E",6,0,1,15,32,1],
aWn:function(a,b){var z,y,x,w
z=a.G("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.ac(b,200)
w=J.j(y)
return J.Q(x,J.b(y.gpp(),"circular")?P.az(w.gbc(y),w.gbC(y)):w.gbc(y))},
bHi:[function(a,b,c){return L.aWo(a,c)},"$3","a9F",6,0,1,15,32,1],
aWo:function(a,b){var z,y,x
z=a.G("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
if(J.b(y.gpp(),"circular")){x=P.az(x.gbc(y),x.gbC(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.Q(J.ac(x.gbc(y),b),100)
return x},
bHj:[function(a,b,c){return L.aWp(a,c)},"$3","a9G",6,0,1,15,32,1],
aWp:function(a,b){var z,y,x,w
z=a.G("view")
if(z==null)return
y=z.gdB()
if(y==null)return
x=J.j(y)
w=J.c0(b)
return J.b(y.gpp(),"circular")?J.Q(w.b9(b,200),P.az(x.gbc(y),x.gbC(y))):J.Q(w.b9(b,100),x.gbc(y))},
ajN:{"^":"Kz;a,b,c",
sbR:function(a,b){var z,y,x,w,v
if(J.b(this.b,b))return
this.av0(this,b)
if(b instanceof N.kQ){z=b.e
if(z.gaE() instanceof N.ew&&H.k(z.gaE(),"$isew").I!=null){J.l4(J.I(this.a),"")
return}y=K.bP(b.r,"fault")
if(y==="fault"&&b.r instanceof F.v){x=b.r
if(J.b(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof F.eo&&J.Z(w.ry,0)){z=H.k(w.cB(0),"$iskh")
y=K.f3(z.gic(z),null,"rgba(0,0,0,0)")}}}v=H.c(y==="fault"?K.f3(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.l4(J.I(this.a),v)}}},
aiC:{"^":"ago;ad,a5,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,I,C,v,L,R,S,W,T,D,Z,M,aq,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sq0:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cI(this.gdu())
this.auc(a)
if(a instanceof F.v)a.di(this.gdu())},
suc:function(a,b){this.aaa(this,b)
this.UL()},
sGH:function(a){this.aab(a)
this.UL()},
ge0:function(){return this.a5},
se0:function(a){H.k(a,"$isaL")
this.a5=a
if(a!=null)F.ci(this.gb14())},
eA:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.aac(a,b)
return}if(!!J.n(a).$isb1){z=this.ad.a
if(!z.O(0,a))z.m(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jk(b)}},
o7:[function(a){this.cA()},"$1","gdu",2,0,2,11],
UL:[function(){var z=this.a5
if(z!=null)if(z.a instanceof F.v)F.a9(new L.aiD(this))},"$0","gb14",0,0,0]},
aiD:{"^":"d:3;a",
$0:[function(){var z=this.a
z.a5.a.bm("offsetLeft",z.M)
z.a5.a.bm("offsetRight",z.aq)},null,null,0,0,null,"call"]},
Cy:{"^":"aAZ;aV,dB:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bk,bS,c_,c6,bx,bX,bW,c0,c7,c8,bZ,bK,cd,cE,co,cp,ct,cm,cu,cv,cF,ce,cq,cr,ca,c9,cJ,cj,cw,cC,bL,cb,cg,cD,cG,ck,cn,cK,cV,cH,cs,cL,cM,cR,ci,cN,cO,cl,cP,cT,cQ,C,v,L,R,S,W,T,D,Z,M,aq,ad,a5,aa,ac,ah,ap,a9,aJ,aO,aS,af,aK,aA,aC,aj,am,aD,aQ,at,aZ,b0,b5,bd,b7,b6,aX,b_,bn,aY,bh,aU,bD,bu,bj,bg,bl,aT,bG,bs,bb,bo,bN,bz,bp,bQ,bE,bV,bA,bO,bB,bq,b8,x1,x2,y1,y2,I,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdn:function(){return this.aV},
sf_:function(a,b){if(J.b(this.D,"none")&&!J.b(b,"none")){this.lu(this,b)
this.e2()}else this.lu(this,b)},
hG:[function(a){this.mK(a)
this.sie(!0)},"$1","gfp",2,0,2,11],
te:[function(a){this.w6()},"$0","gmB",0,0,0],
a7:[function(){this.sie(!1)
this.ft()
this.w.sGu(!0)
this.w.a7()
this.w.sq0(null)
this.w.sGu(!1)},"$0","gd6",0,0,0],
hW:[function(){this.sie(!1)
this.ft()},"$0","gkn",0,0,0],
fO:function(){this.Bj()
this.sie(!0)},
w6:function(){if(this.a instanceof F.v)this.w.i9(J.d6(this.b),J.d2(this.b))},
e2:function(){var z,y
this.yO()
this.snV(-1)
z=this.w
y=J.j(z)
y.sbc(z,J.E(y.gbc(z),1))},
$isbS:1,
$isbT:1,
$iscI:1},
aAZ:{"^":"aL+mY;nV:x$?,u3:y$?",$iscI:1},
b9x:{"^":"d:37;",
$2:[function(a,b){a.gdB().spp(K.ax(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b9y:{"^":"d:37;",
$2:[function(a,b){J.Hr(a.gdB(),K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9z:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGH(K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9A:{"^":"d:37;",
$2:[function(a,b){a.gdB().sii(K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9B:{"^":"d:37;",
$2:[function(a,b){a.gdB().siO(K.aU(b,100))},null,null,4,0,null,0,2,"call"]},
b9C:{"^":"d:37;",
$2:[function(a,b){a.gdB().svo(K.G(b,""))},null,null,4,0,null,0,2,"call"]},
b9D:{"^":"d:37;",
$2:[function(a,b){a.gdB().sasF(K.a_(b,!1))},null,null,4,0,null,0,2,"call"]},
b9E:{"^":"d:37;",
$2:[function(a,b){a.gdB().saYt(K.kx(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
b9G:{"^":"d:37;",
$2:[function(a,b){a.gdB().sq0(R.cF(b,16777215))},null,null,4,0,null,0,2,"call"]},
b9H:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGk(K.G(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
b9I:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGl(K.ax(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
b9J:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGm(K.ax(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
b9K:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGo(K.ax(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
b9L:{"^":"d:37;",
$2:[function(a,b){a.gdB().sGn(K.al(b,0))},null,null,4,0,null,0,2,"call"]},
b9M:{"^":"d:37;",
$2:[function(a,b){a.gdB().saRF(K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9N:{"^":"d:37;",
$2:[function(a,b){a.gdB().saRE(K.ax(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
b9O:{"^":"d:37;",
$2:[function(a,b){a.gdB().sQ5(K.aU(b,-120))},null,null,4,0,null,0,2,"call"]},
b9P:{"^":"d:37;",
$2:[function(a,b){J.He(a.gdB(),K.aU(b,120))},null,null,4,0,null,0,2,"call"]},
b9R:{"^":"d:37;",
$2:[function(a,b){a.gdB().sT6(K.aU(b,50))},null,null,4,0,null,0,2,"call"]},
b9S:{"^":"d:37;",
$2:[function(a,b){a.gdB().sT7(K.aU(b,50))},null,null,4,0,null,0,2,"call"]},
b9T:{"^":"d:37;",
$2:[function(a,b){a.gdB().sT8(K.aU(b,90))},null,null,4,0,null,0,2,"call"]},
b9U:{"^":"d:37;",
$2:[function(a,b){a.gdB().sa3h(K.al(b,11))},null,null,4,0,null,0,2,"call"]},
b9V:{"^":"d:37;",
$2:[function(a,b){a.gdB().saRu(K.ax(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
aiE:{"^":"agp;L,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,I,C,v,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sq2:function(a){var z=this.rx
if(z instanceof F.v)H.k(z,"$isv").cI(this.gdu())
this.auk(a)
if(a instanceof F.v)a.di(this.gdu())},
sa3g:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cI(this.gdu())
this.auj(a)
if(a instanceof F.v)a.di(this.gdu())},
eZ:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.L.a
if(z.O(0,a))z.h(0,a).jv(null)
this.auf(a,b,c,d)
return}if(!!J.n(a).$isb1){z=this.L.a
if(!z.O(0,a))z.m(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jv(b)
y.skO(c)
y.skx(d)}},
o7:[function(a){this.cA()},"$1","gdu",2,0,2,11]},
CA:{"^":"aB_;aV,dB:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bk,bS,c_,c6,bx,bX,bW,c0,c7,c8,bZ,bK,cd,cE,co,cp,ct,cm,cu,cv,cF,ce,cq,cr,ca,c9,cJ,cj,cw,cC,bL,cb,cg,cD,cG,ck,cn,cK,cV,cH,cs,cL,cM,cR,ci,cN,cO,cl,cP,cT,cQ,C,v,L,R,S,W,T,D,Z,M,aq,ad,a5,aa,ac,ah,ap,a9,aJ,aO,aS,af,aK,aA,aC,aj,am,aD,aQ,at,aZ,b0,b5,bd,b7,b6,aX,b_,bn,aY,bh,aU,bD,bu,bj,bg,bl,aT,bG,bs,bb,bo,bN,bz,bp,bQ,bE,bV,bA,bO,bB,bq,b8,x1,x2,y1,y2,I,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdn:function(){return this.aV},
sf_:function(a,b){if(J.b(this.D,"none")&&!J.b(b,"none")){this.lu(this,b)
this.e2()}else this.lu(this,b)},
hG:[function(a){this.mK(a)
this.sie(!0)
if(a==null)this.w.i9(J.d6(this.b),J.d2(this.b))},"$1","gfp",2,0,2,11],
te:[function(a){this.w.i9(J.d6(this.b),J.d2(this.b))},"$0","gmB",0,0,0],
a7:[function(){this.sie(!1)
this.ft()
this.w.sGu(!0)
this.w.a7()
this.w.sq2(null)
this.w.sa3g(null)
this.w.sGu(!1)},"$0","gd6",0,0,0],
hW:[function(){this.sie(!1)
this.ft()},"$0","gkn",0,0,0],
fO:function(){this.Bj()
this.sie(!0)},
e2:function(){var z,y
this.yO()
this.snV(-1)
z=this.w
y=J.j(z)
y.sbc(z,J.E(y.gbc(z),1))},
w6:function(){this.w.i9(J.d6(this.b),J.d2(this.b))},
$isbS:1,
$isbT:1},
aB_:{"^":"aL+mY;nV:x$?,u3:y$?",$iscI:1},
b9W:{"^":"d:46;",
$2:[function(a,b){a.gdB().spp(K.ax(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b9X:{"^":"d:46;",
$2:[function(a,b){a.gdB().sb_E(K.ax(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
b9Y:{"^":"d:46;",
$2:[function(a,b){J.Hr(a.gdB(),K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9Z:{"^":"d:46;",
$2:[function(a,b){a.gdB().sGH(K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
ba_:{"^":"d:46;",
$2:[function(a,b){a.gdB().sa3g(R.cF(b,16777215))},null,null,4,0,null,0,2,"call"]},
ba1:{"^":"d:46;",
$2:[function(a,b){a.gdB().saSD(K.al(b,1))},null,null,4,0,null,0,2,"call"]},
ba2:{"^":"d:46;",
$2:[function(a,b){a.gdB().sq2(R.cF(b,16777215))},null,null,4,0,null,0,2,"call"]},
ba3:{"^":"d:46;",
$2:[function(a,b){a.gdB().sGB(K.al(b,1))},null,null,4,0,null,0,2,"call"]},
ba4:{"^":"d:46;",
$2:[function(a,b){a.gdB().sQ5(K.aU(b,-120))},null,null,4,0,null,0,2,"call"]},
ba5:{"^":"d:46;",
$2:[function(a,b){J.He(a.gdB(),K.aU(b,120))},null,null,4,0,null,0,2,"call"]},
ba6:{"^":"d:46;",
$2:[function(a,b){a.gdB().sT6(K.aU(b,50))},null,null,4,0,null,0,2,"call"]},
ba7:{"^":"d:46;",
$2:[function(a,b){a.gdB().sT7(K.aU(b,50))},null,null,4,0,null,0,2,"call"]},
ba8:{"^":"d:46;",
$2:[function(a,b){a.gdB().sT8(K.aU(b,90))},null,null,4,0,null,0,2,"call"]},
ba9:{"^":"d:46;",
$2:[function(a,b){a.gdB().sa3h(K.al(b,11))},null,null,4,0,null,0,2,"call"]},
baa:{"^":"d:46;",
$2:[function(a,b){a.gdB().saSE(K.kx(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bac:{"^":"d:46;",
$2:[function(a,b){a.gdB().saT8(K.al(b,2))},null,null,4,0,null,0,2,"call"]},
bad:{"^":"d:46;",
$2:[function(a,b){a.gdB().saT9(K.kx(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bae:{"^":"d:46;",
$2:[function(a,b){a.gdB().saKW(K.aU(b,null))},null,null,4,0,null,0,2,"call"]},
aiF:{"^":"agq;v,L,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,I,C,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gjO:function(){return this.L},
sjO:function(a){var z=this.L
if(z!=null)z.cI(this.ga6w())
this.L=a
if(a!=null)a.di(this.ga6w())
this.b0N(null)},
b0N:[function(a){var z,y,x,w,v,u,t,s
z=this.L
if(z==null){y=H.a([],[F.o])
x=$.H+1
$.H=x
w=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
z=new F.eo(!1,y,0,null,null,x,null,w,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.P(null,null,null,{func:1,v:true,args:[[P.M,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
z.ch=null
z.ia(F.hJ(new F.dp(0,255,0,1),0,0))
z.ia(F.hJ(new F.dp(0,0,0,1),0,50))}v=J.hH(z)
y=J.ba(v)
y.eu(v,F.r2())
u=[]
if(J.Z(y.gl(v),1))for(y=y.gbe(v);y.u();){t=y.gH()
x=J.j(t)
w=x.gic(t)
s=H.dr(t.i("alpha"))
s.toString
u.push(new N.w9(w,s,J.Q(x.gtj(t),100)))}else if(J.b(y.gl(v),1)){t=y.h(v,0)
y=J.j(t)
x=y.gic(t)
w=H.dr(t.i("alpha"))
w.toString
u.push(new N.w9(x,w,0))
y=y.gic(t)
w=H.dr(t.i("alpha"))
w.toString
u.push(new N.w9(y,w,1))}this.sa8w(u)},"$1","ga6w",2,0,5,11],
eA:function(a,b){var z,y,x,w
if(typeof b==="number"&&Math.floor(b)===b){this.aac(a,b)
return}if(!!J.n(a).$isb1){z=this.v.a
if(!z.O(0,a))z.m(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
z=$.H+1
$.H=z
x=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
w=new F.v(z,null,x,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.P(null,null,null,{func:1,v:true,args:[[P.M,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
w.an("fillType",!0).bf("gradient")
w.an("gradient",!0).$2(b,!1)
w.an("gradientType",!0).bf("linear")
y.jk(w)}},
a7:[function(){var z=this.L
if(z!=null){z.cI(this.ga6w())
this.L=null}this.aul()},"$0","gd6",0,0,0],
ay3:function(){var z=$.$get$BD()
if(J.b(z.ry,0)){z.ia(F.hJ(new F.dp(0,255,0,1),1,0))
z.ia(F.hJ(new F.dp(255,255,0,1),1,50))
z.ia(F.hJ(new F.dp(255,0,0,1),1,100))}},
ae:{
aiG:function(){var z=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.r,E.bW])),[P.r,E.bW])
z=new L.aiF(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cn(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.cy=P.hA()
z.axT()
z.ay3()
return z}}},
CC:{"^":"aB0;aV,dB:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bk,bS,c_,c6,bx,bX,bW,c0,c7,c8,bZ,bK,cd,cE,co,cp,ct,cm,cu,cv,cF,ce,cq,cr,ca,c9,cJ,cj,cw,cC,bL,cb,cg,cD,cG,ck,cn,cK,cV,cH,cs,cL,cM,cR,ci,cN,cO,cl,cP,cT,cQ,C,v,L,R,S,W,T,D,Z,M,aq,ad,a5,aa,ac,ah,ap,a9,aJ,aO,aS,af,aK,aA,aC,aj,am,aD,aQ,at,aZ,b0,b5,bd,b7,b6,aX,b_,bn,aY,bh,aU,bD,bu,bj,bg,bl,aT,bG,bs,bb,bo,bN,bz,bp,bQ,bE,bV,bA,bO,bB,bq,b8,x1,x2,y1,y2,I,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdn:function(){return this.aV},
sf_:function(a,b){if(J.b(this.D,"none")&&!J.b(b,"none")){this.lu(this,b)
this.e2()}else this.lu(this,b)},
hG:[function(a){this.mK(a)
this.sie(!0)},"$1","gfp",2,0,2,11],
te:[function(a){this.w6()},"$0","gmB",0,0,0],
a7:[function(){this.sie(!1)
this.ft()
this.w.sGu(!0)
this.w.a7()
this.w.sjO(null)
this.w.sGu(!1)},"$0","gd6",0,0,0],
hW:[function(){this.sie(!1)
this.ft()},"$0","gkn",0,0,0],
fO:function(){this.Bj()
this.sie(!0)},
e2:function(){var z,y
this.yO()
this.snV(-1)
z=this.w
y=J.j(z)
y.sbc(z,J.E(y.gbc(z),1))},
w6:function(){if(this.a instanceof F.v)this.w.i9(J.d6(this.b),J.d2(this.b))},
$isbS:1,
$isbT:1},
aB0:{"^":"aL+mY;nV:x$?,u3:y$?",$iscI:1},
b9k:{"^":"d:68;",
$2:[function(a,b){a.gdB().spp(K.ax(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b9l:{"^":"d:68;",
$2:[function(a,b){J.Hr(a.gdB(),K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9m:{"^":"d:68;",
$2:[function(a,b){a.gdB().sGH(K.aU(b,0))},null,null,4,0,null,0,2,"call"]},
b9n:{"^":"d:68;",
$2:[function(a,b){a.gdB().saYs(K.kx(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
b9o:{"^":"d:68;",
$2:[function(a,b){a.gdB().saYq(K.kx(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
b9p:{"^":"d:68;",
$2:[function(a,b){a.gdB().sj3(K.ax(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
b9q:{"^":"d:68;",
$2:[function(a,b){var z=a.gdB()
z.sjO(b!=null?F.pc(b):$.$get$BD())},null,null,4,0,null,0,2,"call"]},
b9r:{"^":"d:68;",
$2:[function(a,b){a.gdB().sQ5(K.aU(b,-120))},null,null,4,0,null,0,2,"call"]},
b9s:{"^":"d:68;",
$2:[function(a,b){J.He(a.gdB(),K.aU(b,120))},null,null,4,0,null,0,2,"call"]},
b9t:{"^":"d:68;",
$2:[function(a,b){a.gdB().sT6(K.aU(b,50))},null,null,4,0,null,0,2,"call"]},
b9v:{"^":"d:68;",
$2:[function(a,b){a.gdB().sT7(K.aU(b,50))},null,null,4,0,null,0,2,"call"]},
b9w:{"^":"d:68;",
$2:[function(a,b){a.gdB().sT8(K.aU(b,90))},null,null,4,0,null,0,2,"call"]},
xg:{"^":"r;a7x:a@,ii:b@,iO:c@"},
afI:{"^":"le;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,c,d,e,f,r,x,y,z,Q,ch,a,b",
gpQ:function(){return this.r1},
spQ:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cA()}},
gcS:function(){return this.r2},
scS:function(a){this.aZf(a)},
gjP:function(){return this.go},
iD:function(a,b){var z,y,x,w
this.Ez(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.hA()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.c(a)+"px"
z.width=y
z=this.id.style
y=H.c(b)+"px"
z.height=y
this.eZ(this.k1,0,0,"none")
this.eA(this.k1,this.r2.cd)
z=this.k2
y=this.r2
this.eZ(z,y.c8,J.aN(y.bZ),this.r2.bK)
y=this.k3
z=this.r2
this.eZ(y,z.c8,J.aN(z.bZ),this.r2.bK)
z=this.db
if(z===2){z=J.Z(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.aa(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aB(a))
y=this.k1
y.toString
y.setAttribute("height",J.aa(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.aa(J.R(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aB(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aB(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.c(this.cy.b)+" L "+H.c(a)+","+H.c(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.c(J.R(this.cy.b,this.r1.b))+" L "+H.c(a)+","+H.c(J.R(this.cy.b,this.r1.b)))}else if(z===1){z=J.Z(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.aa(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.aa(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aB(b))}else{x.toString
x.setAttribute("x",J.aa(J.R(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aB(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aB(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.c(this.cy.a)+",0 L "+H.c(this.cy.a)+","+H.c(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.c(J.R(this.cy.a,this.r1.a))+",0 L "+H.c(J.R(this.cy.a,this.r1.a))+","+H.c(b))}else if(z===3){z=J.Z(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.aa(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.aa(this.r1.a))}else{y.toString
y.setAttribute("x",J.aa(J.R(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aB(0-y))}z=J.Z(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.aa(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.aa(this.r1.b))}else{y.toString
y.setAttribute("y",J.aa(J.R(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aB(0-y))}z=this.k1
y=this.r2
this.eZ(z,y.c8,J.aN(y.bZ),this.r2.bK)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
aZf:function(a){var z
this.a5H()
this.a5I()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().F(0)
this.r2.qk(0,"CartesianChartZoomerReset",this.gaiC())}this.r2=a
if(a!=null){z=J.cD(a.cx)
z=H.a(new W.C(0,z.a,z.b,W.B(this.gaIY()),z.c),[H.w(z,0)])
z.t()
this.fx.push(z)
this.r2.nG(0,"CartesianChartZoomerReset",this.gaiC())}this.dx=null
this.dy=null},
Kd:function(a){var z,y,x,w,v
z=this.HY(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.O)(z),++x){v=J.n(z[x])
if(!(!!v.$isqw||!!v.$ishQ||!!v.$isiJ))return!1}return!0},
aqA:function(a){var z=J.n(a)
if(!!z.$isiJ)return J.b4(a.db)?null:a.db
else if(!!z.$isqz)return a.db
return 0/0},
Wi:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiJ){if(b==null)z=null
else{z=J.bv(b)
y=!a.ah
x=new P.ai(z,y)
x.ex(z,y)
z=x}a.sii(z)}else if(!!z.$ishQ)a.sii(b)
else if(!!z.$isqw)a.sii(b)},
asi:function(a,b){return this.Wi(a,b,!1)},
aqy:function(a){var z=J.n(a)
if(!!z.$isiJ)return J.b4(a.cy)?null:a.cy
else if(!!z.$isqz)return a.cy
return 0/0},
Wh:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiJ){if(b==null)z=null
else{z=J.bv(b)
y=!a.ah
x=new P.ai(z,y)
x.ex(z,y)
z=x}a.siO(z)}else if(!!z.$ishQ)a.siO(b)
else if(!!z.$isqw)a.siO(b)},
ash:function(a,b){return this.Wh(a,b,!1)},
a7s:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[N.dW,L.xg])),[N.dW,L.xg])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[N.dW,L.xg])),[N.dW,L.xg])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.HY(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.O)(v),++u){t=v[u]
s=x.a
if(!s.O(0,t)){r=J.n(t)
r=!!r.$isqw||!!r.$ishQ||!!r.$isiJ}else r=!1
if(r)s.m(0,t,new L.xg(!1,this.aqA(t),this.aqy(t)))}}y=this.cy
if(z){y=y.b
q=P.aC(y,J.R(y,b))
y=this.cy.b
p=P.az(y,J.R(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aC(y,J.R(y,b))
y=this.cy.a
m=P.az(y,J.R(y,b))
o="h"
q=null
p=null}l=[]
k=N.js(this.r2.a9,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof N.jH))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.ap:f.ah
r=J.n(h)
if(!(!!r.$isqw||!!r.$ishQ||!!r.$isiJ)){g=f
break c$0}if(J.bF(C.a.cY(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=Q.b6(y,H.a(new P.J(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcS()),e).b)
if(typeof q!=="number")return q.A()
y=H.a(new P.J(0,q-y),[null])
y=f.fr.oY([J.E(y.a,C.b.E(f.cy.offsetLeft)),J.E(y.b,C.b.E(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
j=y[1]
e=Q.b6(f.cy,H.a(new P.J(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcS()),e).b)
if(typeof p!=="number")return p.A()
y=H.a(new P.J(0,p-y),[null])
y=f.fr.oY([J.E(y.a,C.b.E(f.cy.offsetLeft)),J.E(y.b,C.b.E(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
i=y[1]}else{e=Q.b6(y,H.a(new P.J(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcS()),e).a)
if(typeof m!=="number")return m.A()
y=H.a(new P.J(m-y,0),[null])
y=f.fr.oY([J.E(y.a,C.b.E(f.cy.offsetLeft)),J.E(y.b,C.b.E(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
j=y[0]
e=Q.b6(f.cy,H.a(new P.J(0,0),[null]))
y=J.aN(Q.aP(J.as(f.gcS()),e).a)
if(typeof n!=="number")return n.A()
y=H.a(new P.J(n-y,0),[null])
y=f.fr.oY([J.E(y.a,C.b.E(f.cy.offsetLeft)),J.E(y.b,C.b.E(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
i=y[0]}if(J.aG(i,j)){d=i
i=j
j=d}this.asi(h,j)
this.ash(h,i)
this.fr=!0
break}k.length===y||(0,H.O)(k);++u}if(!this.fr)return
x.a.h(0,h).sa7x(!0)
if(h!=null&&!c){y=this.r2
if(z){y.c0=j
y.c7=i
y.apg()}else{y.bx=j
y.bX=i
y.aoE()}}},
apM:function(a,b){return this.a7s(a,b,!1)},
anc:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.HY(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.O)(y),++u){t=y[u]
if(w.O(0,t)){this.Wi(t,w.h(0,t).gii(),!0)
this.Wh(t,w.h(0,t).giO(),!0)
if(w.h(0,t).ga7x())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.bx=0/0
x.bX=0/0
x.aoE()}},
a5H:function(){return this.anc(!1)},
ang:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.HY(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.O)(y),++u){t=y[u]
if(w.O(0,t)){this.Wi(t,w.h(0,t).gii(),!0)
this.Wh(t,w.h(0,t).giO(),!0)
if(w.h(0,t).ga7x())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.c0=0/0
x.c7=0/0
x.apg()}},
a5I:function(){return this.ang(!1)},
apN:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.a2(a)
if(z.gjH(a)||J.b4(b)){if(this.fr)if(c)this.ang(!0)
else this.anc(!0)
return}if(!this.Kd(c))return
y=this.HY(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aqT(x)
if(w==null)return
v=J.n(b)
if(c){u=J.R(w.FJ(["0",z.aB(a)]).b,this.a8u(w))
t=J.R(w.FJ(["0",v.aB(b)]).b,this.a8u(w))
this.cy=H.a(new P.J(50,u),[null])
this.a7s(2,J.E(t,u),!0)}else{s=J.R(w.FJ([z.aB(a),"0"]).a,this.a8t(w))
r=J.R(w.FJ([v.aB(b),"0"]).a,this.a8t(w))
this.cy=H.a(new P.J(s,50),[null])
this.a7s(1,J.E(r,s),!0)}},
HY:function(a){var z,y,x,w,v,u,t
z=[]
y=N.js(this.r2.a9,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.O)(y),++v){u=y[v]
if(!(u instanceof N.jH))continue
if(a){t=u.ap
if(t!=null&&J.aG(C.a.cY(z,t),0))z.push(u.ap)}else{t=u.ah
if(t!=null&&J.aG(C.a.cY(z,t),0))z.push(u.ah)}w=u}return z},
aqT:function(a){var z,y,x,w,v
z=N.js(this.r2.a9,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.O)(z),++w){v=z[w]
if(!(v instanceof N.jH))continue
if(J.b(v.ap,a)||J.b(v.ah,a))return v
x=v}return},
a8t:function(a){var z=Q.b6(a.cy,H.a(new P.J(0,0),[null]))
return J.aN(Q.aP(J.as(a.gcS()),z).a)},
a8u:function(a){var z=Q.b6(a.cy,H.a(new P.J(0,0),[null]))
return J.aN(Q.aP(J.as(a.gcS()),z).b)},
eZ:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.O(0,a))z.h(0,a).jv(null)
R.oz(a,b,c,d)
return}if(!!J.n(a).$isb1){z=this.k4.a
if(!z.O(0,a))z.m(0,a,new E.bW(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jv(b)
y.skO(c)
y.skx(d)}},
eA:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.O(0,a))z.h(0,a).jk(null)
R.rZ(a,b)
return}if(!!J.n(a).$isb1){z=this.k4.a
if(!z.O(0,a))z.m(0,a,new E.bW(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jk(b)}},
b6k:[function(a){var z,y
z=this.r2
if(!z.c_&&!z.bW)return
z.cx.appendChild(this.go)
z=this.r2
this.i9(z.Q,z.ch)
this.cy=Q.aP(this.go,J.cE(a))
this.cx=!0
z=this.fy
y=C.C.d0(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.garb()),y.c),[H.w(y,0)])
y.t()
z.push(y)
y=C.E.d0(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gard()),y.c),[H.w(y,0)])
y.t()
z.push(y)
y=C.a2.d0(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gG4()),y.c),[H.w(y,0)])
y.t()
z.push(y)
this.db=0
this.spQ(null)},"$1","gaIY",2,0,4,4],
b31:[function(a){var z,y
z=Q.aP(this.go,J.cE(a))
if(this.db===0)if(this.r2.c6){if(!(this.Kd(!0)&&this.Kd(!1))){this.Fy()
return}if(J.bF(J.ha(J.E(z.a,this.cy.a)),2)&&J.bF(J.ha(J.E(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.Z(J.ha(J.E(z.b,this.cy.b)),J.ha(J.E(z.a,this.cy.a)))){if(this.Kd(!0))this.db=2
else{this.Fy()
return}y=2}else{if(this.Kd(!1))this.db=1
else{this.Fy()
return}y=1}if(y===1)if(!this.r2.c_){this.Fy()
return}if(y===2)if(!this.r2.bW){this.Fy()
return}}y=this.r2
if(P.be(0,0,y.Q,y.ch,null).oS(0,z)){y=this.db
if(y===2)this.spQ(H.a(new P.J(0,J.E(z.b,this.cy.b)),[null]))
else if(y===1)this.spQ(H.a(new P.J(J.E(z.a,this.cy.a),0),[null]))
else if(y===3)this.spQ(H.a(new P.J(J.E(z.a,this.cy.a),J.E(z.b,this.cy.b)),[null]))
else this.spQ(null)}},"$1","garb",2,0,4,4],
b32:[function(a){var z,y
for(z=this.fy;z.length>0;)z.pop().F(0)
J.a3(this.go)
this.cx=!1
this.cA()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.apM(2,z.b)
z=this.db
if(z===1||z===3)this.apM(1,this.r1.a)}else{this.a5H()
F.a9(new L.afK(this))}},"$1","gard",2,0,4,4],
aiy:[function(a){if(Q.cU(a)===27)this.Fy()},"$1","gG4",2,0,6,4],
Fy:function(){for(var z=this.fy;z.length>0;)z.pop().F(0)
J.a3(this.go)
this.cx=!1
this.cA()},
b8E:[function(a){this.a5H()
F.a9(new L.afL(this))},"$1","gaiC",2,0,7,4],
axP:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.z(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ae:{
afJ:function(){var z=H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.r,E.bW])),[P.r,E.bW])
z=new L.afI(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.x(0,null,null,null,null,null,0),[P.e,[P.A,P.aI]])),[P.e,[P.A,P.aI]]))
z.a=z
z.axP()
return z}}},
afK:{"^":"d:3;a",
$0:[function(){this.a.a5I()},null,null,0,0,null,"call"]},
afL:{"^":"d:3;a",
$0:[function(){this.a.a5I()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.br,args:[F.v,P.e,P.br]},{func:1,v:true,args:[[P.M,P.e]]},{func:1,ret:Q.bS},{func:1,v:true,args:[W.cL]},{func:1,v:true,args:[P.r]},{func:1,v:true,args:[W.h7]},{func:1,v:true,args:[E.ck]},{func:1,ret:P.e,args:[N.kQ]}]
init.types.push.apply(init.types,deferredTypes)
$.OV=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["WT","$get$WT",function(){return P.m(["scaleType",new L.b9x(),"offsetLeft",new L.b9y(),"offsetRight",new L.b9z(),"minimum",new L.b9A(),"maximum",new L.b9B(),"formatString",new L.b9C(),"showMinMaxOnly",new L.b9D(),"percentTextSize",new L.b9E(),"labelsColor",new L.b9G(),"labelsFontFamily",new L.b9H(),"labelsFontStyle",new L.b9I(),"labelsFontWeight",new L.b9J(),"labelsTextDecoration",new L.b9K(),"labelsLetterSpacing",new L.b9L(),"labelsRotation",new L.b9M(),"labelsAlign",new L.b9N(),"angleFrom",new L.b9O(),"angleTo",new L.b9P(),"percentOriginX",new L.b9R(),"percentOriginY",new L.b9S(),"percentRadius",new L.b9T(),"majorTicksCount",new L.b9U(),"justify",new L.b9V()])},$,"WU","$get$WU",function(){var z=P.af()
z.q(0,E.eV())
z.q(0,$.$get$WT())
return z},$,"WV","$get$WV",function(){return P.m(["scaleType",new L.b9W(),"ticksPlacement",new L.b9X(),"offsetLeft",new L.b9Y(),"offsetRight",new L.b9Z(),"majorTickStroke",new L.ba_(),"majorTickStrokeWidth",new L.ba1(),"minorTickStroke",new L.ba2(),"minorTickStrokeWidth",new L.ba3(),"angleFrom",new L.ba4(),"angleTo",new L.ba5(),"percentOriginX",new L.ba6(),"percentOriginY",new L.ba7(),"percentRadius",new L.ba8(),"majorTicksCount",new L.ba9(),"majorTicksPercentLength",new L.baa(),"minorTicksCount",new L.bac(),"minorTicksPercentLength",new L.bad(),"cutOffAngle",new L.bae()])},$,"WW","$get$WW",function(){var z=P.af()
z.q(0,E.eV())
z.q(0,$.$get$WV())
return z},$,"WX","$get$WX",function(){return P.m(["scaleType",new L.b9k(),"offsetLeft",new L.b9l(),"offsetRight",new L.b9m(),"percentStartThickness",new L.b9n(),"percentEndThickness",new L.b9o(),"placement",new L.b9p(),"gradient",new L.b9q(),"angleFrom",new L.b9r(),"angleTo",new L.b9s(),"percentOriginX",new L.b9t(),"percentOriginY",new L.b9v(),"percentRadius",new L.b9w()])},$,"WY","$get$WY",function(){var z=P.af()
z.q(0,E.eV())
z.q(0,$.$get$WX())
return z},$])}
$dart_deferred_initializers$["MCAn9O47Lec1E2ZbQGkQvwo/UzI="]=$dart_deferred_initializers$.current

//# sourceMappingURL=remote_dataflow.dart.js_1.part.js.map
