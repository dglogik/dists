self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,N,{"^":"",
aCv:function(){var z=document
z=z.createElement("div")
z=new N.E3(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.oN()
z.ab2()
return z},
agt:{"^":"HW;",
sq7:["atC",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cm()}}],
sGj:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cm()}},
sGk:function(a){if(!J.b(this.rx,a)){this.rx=a
this.cm()}},
sGl:function(a){if(!J.b(this.ry,a)){this.ry=a
this.cm()}},
sGn:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cm()}},
sGm:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cm()}},
saQy:function(a){if(!J.b(this.y1,a)){if(J.W(a,180))a=180
this.y1=J.ax(a,-180)?-180:a
this.cm()}},
saQx:function(a){if(J.b(this.y2,a))return
this.y2=a
this.cm()},
gii:function(){return this.G},
sii:function(a){if(a==null)a=0
if(!J.b(this.G,a)){this.G=a
this.cm()}},
giP:function(){return this.v},
siP:function(a){if(a==null)a=100
if(!J.b(this.v,a)){this.v=a
this.cm()}},
saXk:function(a){if(this.O!==a){this.O=a
this.cm()}},
salN:function(a,b){if(b==null||J.ax(b,0))b=0
if(J.W(b,4))b=4
if(!J.b(this.T,b)){this.T=b
this.cm()}},
sas5:function(a){if(this.U!==a){this.U=a
this.cm()}},
svp:function(a){this.Y=a
this.cm()},
gpv:function(){return this.F},
spv:function(a){if(!J.b(this.F,a)){this.F=a
this.cm()}},
saQq:function(a){if(!J.b(this.a_,a)){this.a_=a
this.cm()}},
gud:function(a){return this.P},
sud:["a9W",function(a,b){if(!J.b(this.P,b))this.P=b}],
sGI:["a9X",function(a){if(!J.b(this.at,a))this.at=a}],
sa34:function(a){this.a9Z(a)
this.cm()},
iC:function(a,b){this.Ew(a,b)
this.ML()
if(J.b(this.F,"circular"))this.aXv(a,b)
else this.aXw(a,b)},
ML:function(){var z,y,x,w,v
z=this.U
y=this.k2
if(z){y.se7(0,2)
z=this.k2.f
if(0>=z.length)return H.f(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isd5)z.sbT(x,this.a0i(this.G,this.T))
J.ac(J.b9(x.gaC()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.f(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isd5)z.sbT(x,this.a0i(this.v,this.T))
J.ac(J.b9(x.gaC()),"text-decoration",this.x1)}else{y.se7(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.f(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isd5){y=this.G
w=J.Q(y,J.aa(J.dw(J.E(this.v,y),J.E(this.fy,1)),v))
z.sbT(x,this.a0i(w,this.T))}J.ac(J.b9(x.gaC()),"text-decoration",this.x1);++v}}this.eC(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.c(this.x2)+"px")},
aXv:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.dw(J.E(this.fr,this.dy),z-1)
x=P.aB(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.dw(a,2)
x=P.aB(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.E(w,x*(50-u)/100)
u=J.dw(b,2)
x=P.aB(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.E(u,x*(50-w)/100)
r=C.b.N(this.O,"%")&&!0
x=this.O
if(r){H.cy("")
x=H.dU(x,"%","")}q=P.e1(x,null)
for(x=J.bV(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.f(w,p)
o=w[p]
w=J.Q(J.E(this.dy,90),x.b1(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.Id(o)
w=m.b
u=J.a0(w)
if(u.bw(w,0)){if(r){l=P.aB(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.dw(l,w)}else k=0
l=m.a
j=J.bV(l)
i=J.Q(j.b1(l,l),u.b1(w,w))
if(typeof i!=="number")H.ad(H.bo(i))
i=Math.sqrt(i)
h=J.aa(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.a_){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.aa(j.dd(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.aa(u.dd(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.ac(J.b9(o.gaC()),"transform","")
if(!!J.n(o).$iscI)o.i8(d,c)
else E.et(o.gaC(),d,c)
i=J.b9(o.gaC())
h=J.M(i)
h.l(i,"transform",J.Q(h.h(i,"transform")," scale ("+H.c(k)+")"))
if(!J.b(this.y1,0))if(!!J.n(o.gaC()).$ismf){i=J.b9(o.gaC())
h=J.M(i)
h.l(i,"transform",J.Q(h.h(i,"transform")," rotate("+H.c(this.y1)+" "+H.c(j.dd(l,2))+" "+H.c(J.dw(u.fv(w),2))+")"))}else{J.k4(J.J(o.gaC())," rotate("+H.c(this.y1)+"deg)")
J.ns(J.J(o.gaC()),H.c(J.aa(j.dd(l,2),k))+" "+H.c(J.aa(u.dd(w,2),k)))}}},
aXw:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.dw(J.E(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.f(x,0)
w=this.Id(x[0])
v=C.b.N(this.O,"%")&&!0
x=this.O
if(v){H.cy("")
x=H.dU(x,"%","")}u=P.e1(x,null)
x=w.b
t=J.a0(x)
if(t.bw(x,0))s=J.dw(v?J.dw(J.aa(a,u),200):u,x)
else s=0
r=J.dw(J.aa(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ab(r)))
p=Math.abs(Math.sin(H.ab(r)))
this.a9W(this,J.aa(J.dw(J.Q(J.aa(w.a,q),t.b1(x,p)),2),s))
this.UB()
x=this.k2.f
if(y<0||y>=x.length)return H.f(x,y)
w=this.Id(x[y])
x=w.b
t=J.a0(x)
if(t.bw(x,0))s=J.dw(v?J.dw(J.aa(a,u),200):u,x)
else s=0
this.a9X(J.aa(J.dw(J.Q(J.aa(w.a,q),t.b1(x,p)),2),s))
this.UB()
if(!J.b(this.y1,0)){for(x=J.bV(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.f(t,n)
w=this.Id(t[n])
t=w.b
m=J.a0(t)
if(m.bw(t,0))J.dw(v?J.dw(x.b1(a,u),200):u,t)
o=P.aC(J.Q(J.aa(w.a,p),m.b1(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.a0(a)
k=J.dw(J.E(x.w(a,this.P),this.at),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.f(y,n)
j=y[n]
y=this.P
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.Q(y,t)
w=this.Id(j)
y=w.b
m=J.a0(y)
if(m.bw(y,0))s=J.dw(v?J.dw(x.b1(a,u),200):u,y)
else s=0
h=w.a
g=J.a0(h)
i=J.E(i,J.aa(g.dd(h,2),s))
J.ac(J.b9(j.gaC()),"transform","")
if(J.b(this.y1,0)){y=J.aa(J.Q(g.b1(h,p),m.b1(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
if(!!J.n(j).$iscI)j.i8(i,f)
else E.et(j.gaC(),i,f)
y=J.b9(j.gaC())
t=J.M(y)
t.l(y,"transform",J.Q(t.h(y,"transform")," scale ("+H.c(s)+")"))}else{i=J.E(J.Q(this.P,t),g.dd(h,2))
t=J.Q(g.b1(h,p),m.b1(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
if(!!J.n(j).$iscI)j.i8(i,e)
else E.et(j.gaC(),i,e)
d=g.dd(h,2)
c=-y/2
y=J.b9(j.gaC())
t=J.M(y)
m=s-1
t.l(y,"transform",J.Q(t.h(y,"transform")," translate("+H.c(J.aa(J.d4(d),m))+" "+H.c(-c*m)+")"))
m=J.b9(j.gaC())
y=J.M(m)
y.l(m,"transform",J.Q(y.h(m,"transform")," scale ("+H.c(s)+")"))
m=J.b9(j.gaC())
y=J.M(m)
y.l(m,"transform",J.Q(y.h(m,"transform")," rotate("+H.c(this.y1)+" "+H.c(d)+" "+H.c(c)+")"))}}},
Id:function(a){var z,y,x,w
if(!!J.n(a.gaC()).$isef){z=H.k(a.gaC(),"$isef").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.b1()
w=x*0.7}else{y=J.d8(a.gaC())
y.toString
w=J.d0(a.gaC())
w.toString}return H.a(new P.H(y,w),[null])},
a0p:[function(){return N.B8()},"$0","gtV",0,0,3],
a0i:function(a,b){var z=this.Y
if(z==null||J.b(z,""))return U.ng(a,"0")
else return U.ng(a,this.Y)},
a7:[function(){this.a9Z(0)
this.cm()
var z=this.k2
z.d=!0
z.r=!0
z.se7(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gd7",0,0,0],
axh:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.z(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new N.mW(this.gtV(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
HW:{"^":"l7;",
gXo:function(){return this.cy},
sSV:["atG",function(a){if(a==null)a=50
if(J.ax(a,0))a=0
if(J.W(a,100))a=100
if(!J.b(this.db,a)){this.db=a
this.cm()}}],
sSW:["atH",function(a){if(a==null)a=50
if(J.ax(a,0))a=0
if(J.W(a,100))a=100
if(!J.b(this.dx,a)){this.dx=a
this.cm()}}],
sPZ:["atD",function(a){if(J.ax(a,-360))a=-360
if(J.W(a,360))a=360
if(!J.b(this.dy,a)){this.dy=a
this.dU()
this.cm()}}],
sQ_:["atE",function(a){if(J.ax(a,-360))a=-360
if(J.W(a,360))a=360
if(!J.b(this.fr,a)){this.fr=a
this.dU()
this.cm()}}],
saS0:function(a){if(a==null||J.ax(a,0))a=0
if(J.W(a,20))a=20
if(!J.b(this.fx,a)){this.fx=a
this.cm()}},
sa34:["a9Z",function(a){if(a==null||J.ax(a,2))a=2
if(J.W(a,30))a=30
if(!J.b(this.fy,a)){this.fy=a
this.cm()}}],
saS1:function(a){if(this.go!==a){this.go=a
this.cm()}},
saRu:function(a){if(this.id!==a){this.id=a
this.cm()}},
sSX:["atI",function(a){if(a==null||J.ax(a,0))a=0
if(J.W(a,200))a=200
if(!J.b(this.k1,a)){this.k1=a
this.cm()}}],
gjR:function(){return this.cy},
f1:["atF",function(a,b,c,d){R.oy(a,b,c,d)}],
eC:["a9Y",function(a,b){R.rZ(a,b)}],
zf:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.j(a)
if(y!=="")J.ac(z.gfc(a),"d",y)
else J.ac(z.gfc(a),"d","M 0,0")}},
agu:{"^":"HW;",
sa33:["atJ",function(a){if(!J.b(this.k4,a)){this.k4=a
this.cm()}}],
saRt:function(a){if(!J.b(this.r2,a)){this.r2=a
this.cm()}},
sqa:["atK",function(a){if(!J.b(this.rx,a)){this.rx=a
this.cm()}}],
sGC:function(a){if(!J.b(this.x1,a)){this.x1=a
this.cm()}},
gpv:function(){return this.x2},
spv:function(a){if(!J.b(this.x2,a)){this.x2=a
this.cm()}},
gud:function(a){return this.y1},
sud:function(a,b){if(!J.b(this.y1,b)){this.y1=b
this.cm()}},
sGI:function(a){if(!J.b(this.y2,a)){this.y2=a
this.cm()}},
saZu:function(a){if(!J.b(this.K,a)){this.K=a
this.cm()}},
saK3:function(a){var z
if(!J.b(this.G,a)){this.G=a
if(a!=null){z=J.E(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.v=z
this.cm()}},
iC:function(a,b){var z,y
this.Ew(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.f1(this.k2,this.k4,J.aM(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.f1(this.k3,this.rx,J.aM(this.x1),this.ry)
if(J.b(this.x2,"circular"))this.aLP(a,b)
else this.aLQ(a,b)},
aLP:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.dw(J.E(this.fr,this.dy),J.E(J.Q(J.aa(this.fx,J.E(this.fy,1)),this.fy),1))
x=C.b.N(this.go,"%")&&!0
w=this.go
if(x){H.cy("")
w=H.dU(w,"%","")}v=P.e1(w,null)
if(x){w=P.aB(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aB(a,b)
w=J.dw(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.E(w,t*(50-s)/100)
s=J.dw(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.E(s,t*(50-w)/100)
w=P.aB(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.b(this.K,"center"))o=0.5
else o=J.b(this.K,"outside")?1:0
w=o-1
s=J.bV(y)
n=0
while(!0){m=J.Q(J.aa(this.fx,J.E(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.Q(J.E(this.dy,90),s.b1(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++n}this.zf(this.k3)
z.a=""
y=J.dw(J.E(this.fr,this.dy),J.E(this.fy,1))
h=C.b.N(this.id,"%")&&!0
s=this.id
if(h){H.cy("")
s=H.dU(s,"%","")}g=P.e1(s,null)
if(h){s=P.aB(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.bV(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.Q(J.E(this.dy,90),s.b1(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.c(m*k+r)+","+H.c(m*j+q)+" "
z.a+="L "+H.c(i*k+r)+","+H.c(i*j+q)+" ";++f}this.zf(this.k2)},
aLQ:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.b.N(this.go,"%")&&!0
y=this.go
if(z){H.cy("")
y=H.dU(y,"%","")}x=P.e1(y,null)
w=z?J.dw(J.aa(J.dw(a,2),x),100):x
v=C.b.N(this.id,"%")&&!0
y=this.id
if(v){H.cy("")
y=H.dU(y,"%","")}u=P.e1(y,null)
t=v?J.dw(J.aa(J.dw(a,2),u),100):u
y=this.cx
y.a=""
s=J.a0(a)
r=J.dw(J.E(s.w(a,this.y1),this.y2),J.E(J.Q(J.aa(this.fx,J.E(this.fy,1)),this.fy),1))
if(J.b(this.K,"center"))q=0.5
else q=J.b(this.K,"outside")?1:0
p=J.a0(t)
o=p.w(t,w)
n=1-q
m=0
while(!0){l=J.Q(J.aa(this.fx,J.E(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.w(t,q*o)
y.a+="M "+H.c(k)+","+H.c(n*o)+" "
y.a+="L "+H.c(k)+","+H.c(j)+" ";++m}this.zf(this.k3)
y.a=""
r=J.dw(J.E(s.w(a,this.y1),this.y2),J.E(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.c(k)+",0 "
y.a+="L "+H.c(k)+","+H.c(t)+" ";++i}this.zf(this.k2)},
a7:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.zf(z)
this.zf(this.k3)}},"$0","gd7",0,0,0]},
agv:{"^":"HW;",
sSV:function(a){this.atG(a)
this.r2=!0},
sSW:function(a){this.atH(a)
this.r2=!0},
sPZ:function(a){this.atD(a)
this.r2=!0},
sQ_:function(a){this.atE(a)
this.r2=!0},
sSX:function(a){this.atI(a)
this.r2=!0},
saXj:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.cm()}},
saXh:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.cm()}},
sa8k:function(a){if(this.x2!==a){this.x2=a
this.dU()
this.cm()}},
gj4:function(){return this.y1},
sj4:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.b(this.y1,a)){this.y1=a
this.r2=!0
this.cm()}},
gpv:function(){return this.y2},
spv:function(a){if(!J.b(this.y2,a)){this.y2=a
this.r2=!0
this.cm()}},
gud:function(a){return this.K},
sud:function(a,b){if(!J.b(this.K,b)){this.K=b
this.r2=!0
this.cm()}},
sGI:function(a){if(!J.b(this.G,a)){this.G=a
this.r2=!0
this.cm()}},
jd:function(){var z,y,x,w,v,u,t,s,r
this.yM()
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.O)(z),++u){t=z[u]
s=J.j(t)
y.push(s.giq(t))
x.push(s.gBU(t))
w.push(s.gtk(t))}if(J.cO(J.E(this.dy,this.fr))===!0){z=J.ip(J.E(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.m.D(0.5*z)}else r=0
this.k2=this.aIY(y,w,r)
this.k3=this.aGE(x,w,r)
this.r2=!0},
iC:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.Ew(a,b)
z=J.bV(a)
y=J.bV(b)
E.DX(this.k4,z.b1(a,1),y.b1(b,1))
if(J.b(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aB(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.b(this.y2,"circular")){z=P.aC(0,P.aB(a,b))
this.rx=z
this.aLS(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.c(this.rx)+" "+H.c(this.rx))}else{z=J.aa(J.E(z.w(a,this.K),this.G),1)
y.b1(b,1)
v=C.b.N(this.ry,"%")&&!0
y=this.ry
if(v){H.cy("")
y=H.dU(y,"%","")}u=P.e1(y,null)
t=v?J.R(J.aa(z,u),100):u
s=C.b.N(this.x1,"%")&&!0
y=this.x1
if(s){H.cy("")
y=H.dU(y,"%","")}r=P.e1(y,null)
q=s?J.R(J.aa(z,r),100):r
this.r1.se7(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.E(q,t)
p=q
o=p
m=0
break
case"cross":y=J.a2(q)
x=J.a2(t)
o=J.Q(y.dd(q,2),x.dd(t,2))
n=J.E(y.dd(q,2),x.dd(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.a(new P.H(this.K,o),[null])
k=H.a(new P.H(this.K,n),[null])
j=H.a(new P.H(J.Q(this.K,z),p),[null])
i=H.a(new P.H(J.Q(this.K,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.f(y,0)
h=y[0]
this.eC(h.gaC(),this.O)
R.oy(h.gaC(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.c(y)+","+H.c(x)+" "
z.a+="L "+H.c(j.a)+","+H.c(j.b)+" "
z.a+="L "+H.c(i.a)+","+H.c(i.b)+" "
z.a+="L "+H.c(k.a)+","+H.c(k.b)+" "
z.a+="L "+H.c(y)+","+H.c(x)+" "
this.zf(h.gaC())
x=this.cy
x.toString
new W.df(x).L(0,"viewBox")}},
aIY:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.wV(J.aa(J.E(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.f(a,y)
t=J.ae(J.c1(a[y],16),255)
if(y>=a.length)return H.f(a,y)
s=J.ae(J.c1(a[y],8),255)
if(y>=a.length)return H.f(a,y)
r=J.ae(a[y],255)
if(x>=a.length)return H.f(a,x)
q=J.ae(J.c1(a[x],16),255)
if(x>=a.length)return H.f(a,x)
p=J.ae(J.c1(a[x],8),255)
if(x>=a.length)return H.f(a,x)
o=J.ae(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.c.D(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.c.D(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.c.D(w*r+m*o)&255)>>>0)}}return z},
aGE:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.f(b,x)
v=b[x]
if(y>=w)return H.f(b,y)
u=J.wV(J.aa(J.E(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.f(a,x)
v=a[x]
if(y>=w)return H.f(a,y)
t=J.R(J.E(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.f(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.Q(w,s*t))}}return z},
aLS:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aB(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.b.N(this.ry,"%")&&!0
z=this.ry
if(v){H.cy("")
z=H.dU(z,"%","")}u=P.e1(z,new N.agw())
if(v){z=P.aB(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.b.N(this.x1,"%")&&!0
z=this.x1
if(s){H.cy("")
z=H.dU(z,"%","")}r=P.e1(z,new N.agx())
if(s){z=P.aB(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aB(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aB(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.se7(0,w)
for(z=J.a0(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.E(this.dy,90)
d=J.E(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.Q(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.w(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.f(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.f(e,d)
g=J.bz(J.aa(e[d],255))
g=J.b_(J.b(g,0)?1:g,24)
e=h.gaC()
a3=this.k2
if(d>=a3.length)return H.f(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.eC(e,a3+g)
a3=h.gaC()
e=this.k2
if(d>=e.length)return H.f(e,d)
R.oy(a3,e[d]+g,1,"solid")
y.a+="M "+H.c(l)+","+H.c(k)+" "
y.a+="L "+H.c(a)+","+H.c(a0)+" "
y.a+="L "+H.c(a1)+","+H.c(a2)+" "
y.a+="L "+H.c(j)+","+H.c(i)+" "
y.a+="L "+H.c(l)+","+H.c(k)+" "
this.zf(h.gaC())}}},
bc4:[function(){var z,y
z=new N.a2N(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gaX9",0,0,3],
a7:["atL",function(){var z=this.r1
z.d=!0
z.r=!0
z.se7(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gd7",0,0,0],
axi:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sa8k([new N.w6(65280,0.5,0),new N.w6(16776960,0.8,0.5),new N.w6(16711680,1,1)])
z=new N.mW(this.gaX9(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
agw:{"^":"d:0;",
$1:function(a){return 0}},
agx:{"^":"d:0;",
$1:function(a){return 0}},
w6:{"^":"r;iq:a*,BU:b>,tk:c>"}}],["","",,L,{"^":"",
bzf:[function(a){var z=!!J.n(a.gle().gaC()).$isfF?H.k(a.gle().gaC(),"$isfF"):null
if(z!=null)if(z.gnO()!=null&&!J.b(z.gnO(),""))return L.S3(a.gle(),z.gnO())
else return z.FY(a)
return""},"$1","aXj",2,0,8,49],
bpr:function(){if($.OK)return
$.OK=!0
$.$get$ht().l(0,"percentTextSize",L.aXm())
$.$get$ht().l(0,"minorTicksPercentLength",L.a9L())
$.$get$ht().l(0,"majorTicksPercentLength",L.a9L())
$.$get$ht().l(0,"percentStartThickness",L.a9N())
$.$get$ht().l(0,"percentEndThickness",L.a9N())
$.$get$hu().l(0,"percentTextSize",L.aXn())
$.$get$hu().l(0,"minorTicksPercentLength",L.a9M())
$.$get$hu().l(0,"majorTicksPercentLength",L.a9M())
$.$get$hu().l(0,"percentStartThickness",L.a9O())
$.$get$hu().l(0,"percentEndThickness",L.a9O())},
aXh:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$jL())
C.a.q(z,$.$get$Bo())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$jL())
C.a.q(z,$.$get$Cm())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$jL())
C.a.q(z,$.$get$Ck())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$jL())
C.a.q(z,$.$get$JS())
return z
case"linearAxis":return $.$get$v2()
case"logAxis":return $.$get$v4()
case"categoryAxis":return $.$get$rK()
case"datetimeAxis":return $.$get$uS()
case"axisRenderer":return $.$get$rF()
case"radialAxisRenderer":return $.$get$JL()
case"angularAxisRenderer":return $.$get$I7()
case"linearAxisRenderer":return $.$get$rF()
case"logAxisRenderer":return $.$get$rF()
case"categoryAxisRenderer":return $.$get$rF()
case"datetimeAxisRenderer":return $.$get$rF()
case"lineSeries":return $.$get$v0()
case"areaSeries":return $.$get$B4()
case"columnSeries":return $.$get$Br()
case"barSeries":return $.$get$Bc()
case"bubbleSeries":return $.$get$Bj()
case"pieSeries":return $.$get$xJ()
case"spectrumSeries":return $.$get$K6()
case"radarSeries":return $.$get$xL()
case"lineSet":return $.$get$pW()
case"areaSet":return $.$get$B6()
case"columnSet":return $.$get$Bt()
case"barSet":return $.$get$Be()
case"gridlines":return $.$get$IZ()}return[]},
aXf:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof L.oq)return a
else{z=$.$get$Tf()
y=H.a([],[N.ey])
x=H.a([],[E.j2])
w=H.a([],[L.iz])
v=H.a([],[E.j2])
u=H.a([],[L.iz])
t=H.a([],[E.j2])
s=H.a([],[L.xg])
r=H.a([],[E.j2])
q=H.a([],[L.xM])
p=H.a([],[E.j2])
o=$.$get$av()
n=$.Z+1
$.Z=n
n=new L.oq(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
n.c9(b,"chart")
J.a1(J.z(n.b),"absolute")
o=L.aiv()
n.C=o
J.by(n.b,o.cx)
o=n.C
o.bj=n
o.Nc()
o=L.afO()
n.a8=o
o.scG(n.C)
return n}case"scaleTicks":if(a instanceof L.Cl)return a
else{z=$.$get$Wt()
y=$.$get$av()
x=$.Z+1
$.Z=x
x=new L.Cl(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c9(b,"scale-ticks")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.aiK(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.cy=P.hx()
x.C=z
J.by(x.b,z.gXo())
return x}case"scaleLabels":if(a instanceof L.Cj)return a
else{z=$.$get$Wr()
y=$.$get$av()
x=$.Z+1
$.Z=x
x=new L.Cj(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c9(b,"scale-labels")
J.a1(J.z(x.b),"absolute")
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.aiI(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.cy=P.hx()
z.axh()
x.C=z
J.by(x.b,z.gXo())
x.C.se0(x)
return x}case"scaleTrack":if(a instanceof L.Cn)return a
else{z=$.$get$Wv()
y=$.$get$av()
x=$.Z+1
$.Z=x
x=new L.Cn(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$az(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.P(null,null,null,P.T),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c9(b,"scale-track")
J.a1(J.z(x.b),"absolute")
J.lK(J.J(x.b),"hidden")
y=L.aiM()
x.C=y
J.by(x.b,y.gXo())
return x}}return},
bzG:[function(){var z=new L.ajT(null,null,null)
z.aaS()
return z},"$0","aXk",0,0,3],
aiv:function(){var z,y,x,w,v,u,t
z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
y=P.bf(0,0,0,0,null)
x=P.bf(0,0,0,0,null)
w=new N.cH(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.a([],[P.fe])
t=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,P.r])),[P.e,P.r])
z=new L.nz(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",N.aXo(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.axf("chartBase")
z.axd()
z.ay_()
z.sR7("single")
z.axs()
return z},
bF1:[function(a,b,c){return L.aW_(a,c)},"$3","aXm",6,0,1,15,35,1],
aW_:function(a,b){var z,y,x
z=a.J("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
return J.R(J.aa(J.b(y.gpv(),"circular")?P.aB(x.gba(y),x.gbs(y)):x.gba(y),b),200)},
bF2:[function(a,b,c){return L.aW0(a,c)},"$3","aXn",6,0,1,15,35,1],
aW0:function(a,b){var z,y,x,w
z=a.J("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.aa(b,200)
w=J.j(y)
return J.R(x,J.b(y.gpv(),"circular")?P.aB(w.gba(y),w.gbs(y)):w.gba(y))},
bF3:[function(a,b,c){return L.aW1(a,c)},"$3","a9L",6,0,1,15,35,1],
aW1:function(a,b){var z,y,x
z=a.J("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
return J.R(J.aa(J.b(y.gpv(),"circular")?P.aB(x.gba(y),x.gbs(y)):x.gba(y),b),200)},
bF4:[function(a,b,c){return L.aW2(a,c)},"$3","a9M",6,0,1,15,35,1],
aW2:function(a,b){var z,y,x,w
z=a.J("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.aa(b,200)
w=J.j(y)
return J.R(x,J.b(y.gpv(),"circular")?P.aB(w.gba(y),w.gbs(y)):w.gba(y))},
bF5:[function(a,b,c){return L.aW3(a,c)},"$3","a9N",6,0,1,15,35,1],
aW3:function(a,b){var z,y,x
z=a.J("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
if(J.b(y.gpv(),"circular")){x=P.aB(x.gba(y),x.gbs(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.R(J.aa(x.gba(y),b),100)
return x},
bF6:[function(a,b,c){return L.aW4(a,c)},"$3","a9O",6,0,1,15,35,1],
aW4:function(a,b){var z,y,x,w
z=a.J("view")
if(z==null)return
y=z.gdA()
if(y==null)return
x=J.j(y)
w=J.bV(b)
return J.b(y.gpv(),"circular")?J.R(w.b1(b,200),P.aB(x.gba(y),x.gbs(y))):J.R(w.b1(b,100),x.gba(y))},
ajT:{"^":"Kp;a,b,c",
sbT:function(a,b){var z,y,x,w,v
if(J.b(this.b,b))return
this.auq(this,b)
if(b instanceof N.kK){z=b.e
if(z.gaC() instanceof N.ey&&H.k(z.gaC(),"$isey").K!=null){J.kZ(J.J(this.a),"")
return}y=K.bS(b.r,"fault")
if(y==="fault"&&b.r instanceof F.v){x=b.r
if(J.b(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof F.ee&&J.W(w.ry,0)){z=H.k(w.cn(0),"$isjh")
y=K.hj(z.giq(z),null,"rgba(0,0,0,0)")}}}v=H.c(y==="fault"?K.hj(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.kZ(J.J(this.a),v)}}},
aiI:{"^":"agt;ag,a6,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,G,v,O,T,U,Y,V,F,a_,P,at,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sq7:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cu(this.gdt())
this.atC(a)
if(a instanceof F.v)a.di(this.gdt())},
sud:function(a,b){this.a9W(this,b)
this.UB()},
sGI:function(a){this.a9X(a)
this.UB()},
ge0:function(){return this.a6},
se0:function(a){H.k(a,"$isaN")
this.a6=a
if(a!=null)F.cn(this.gb_X())},
eC:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.a9Y(a,b)
return}if(!!J.n(a).$isb1){z=this.ag.a
if(!z.M(0,a))z.l(0,a,new E.bY(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jk(b)}},
o8:[function(a){this.cm()},"$1","gdt",2,0,2,11],
UB:[function(){var z=this.a6
if(z!=null)if(z.a instanceof F.v)F.a9(new L.aiJ(this))},"$0","gb_X",0,0,0]},
aiJ:{"^":"d:3;a",
$0:[function(){var z=this.a
z.a6.a.bg("offsetLeft",z.P)
z.a6.a.bg("offsetRight",z.at)},null,null,0,0,null,"call"]},
Cj:{"^":"aAV;b6,dA:C@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bU,c2,c4,bx,bX,bW,c3,c5,c7,c_,bH,cd,cL,cv,cw,cz,co,cA,cB,cH,ce,cq,cr,cb,c8,cM,cj,cC,cD,bK,cc,cf,cE,cI,ck,cp,cN,cX,cJ,cs,cO,cP,cV,cg,cQ,cR,cl,cS,cW,cT,G,v,O,T,U,Y,V,F,a_,P,at,ag,a6,ac,af,ak,ar,aa,aG,aN,aR,ah,aI,aA,aE,al,ao,aF,aO,av,aW,b_,b4,be,b9,b8,aZ,aY,bn,aV,bh,aT,bE,bu,bi,bf,bm,aS,bG,br,bd,bo,bN,bA,bp,bP,bF,bV,bC,bO,bD,bq,bc,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gds:function(){return this.b6},
sf3:function(a,b){if(J.b(this.F,"none")&&!J.b(b,"none")){this.lt(this,b)
this.e4()}else this.lt(this,b)},
hH:[function(a){this.mK(a)
this.siw(!0)},"$1","gfo",2,0,2,11],
ui:[function(a){this.w9()},"$0","gmW",0,0,0],
a7:[function(){this.siw(!1)
this.fu()
this.C.sGv(!0)
this.C.a7()
this.C.sq7(null)
this.C.sGv(!1)},"$0","gd7",0,0,0],
hZ:[function(){this.siw(!1)
this.fu()},"$0","gkn",0,0,0],
fR:function(){this.Bl()
this.siw(!0)},
w9:function(){if(this.a instanceof F.v)this.C.ic(J.d8(this.b),J.d0(this.b))},
e4:function(){var z,y
this.yN()
this.soy(-1)
z=this.C
y=J.j(z)
y.sba(z,J.E(y.gba(z),1))},
$isc_:1,
$isc0:1,
$iscK:1},
aAV:{"^":"aN+o_;oy:x$?,vy:y$?",$iscK:1},
b8w:{"^":"d:36;",
$2:[function(a,b){a.gdA().spv(K.ay(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b8x:{"^":"d:36;",
$2:[function(a,b){J.Hd(a.gdA(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8y:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGI(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8z:{"^":"d:36;",
$2:[function(a,b){a.gdA().sii(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8A:{"^":"d:36;",
$2:[function(a,b){a.gdA().siP(K.aV(b,100))},null,null,4,0,null,0,2,"call"]},
b8C:{"^":"d:36;",
$2:[function(a,b){a.gdA().svp(K.I(b,""))},null,null,4,0,null,0,2,"call"]},
b8D:{"^":"d:36;",
$2:[function(a,b){a.gdA().sas5(K.a_(b,!1))},null,null,4,0,null,0,2,"call"]},
b8E:{"^":"d:36;",
$2:[function(a,b){a.gdA().saXk(K.kr(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
b8F:{"^":"d:36;",
$2:[function(a,b){a.gdA().sq7(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
b8G:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGj(K.I(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
b8H:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGk(K.ay(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
b8I:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGl(K.ay(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
b8J:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGn(K.ay(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
b8K:{"^":"d:36;",
$2:[function(a,b){a.gdA().sGm(K.ak(b,0))},null,null,4,0,null,0,2,"call"]},
b8L:{"^":"d:36;",
$2:[function(a,b){a.gdA().saQy(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8O:{"^":"d:36;",
$2:[function(a,b){a.gdA().saQx(K.ay(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
b8P:{"^":"d:36;",
$2:[function(a,b){a.gdA().sPZ(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
b8Q:{"^":"d:36;",
$2:[function(a,b){a.gdA().sQ_(K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
b8R:{"^":"d:36;",
$2:[function(a,b){a.gdA().sSV(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b8S:{"^":"d:36;",
$2:[function(a,b){a.gdA().sSW(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b8T:{"^":"d:36;",
$2:[function(a,b){a.gdA().sSX(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
b8U:{"^":"d:36;",
$2:[function(a,b){a.gdA().sa34(K.ak(b,11))},null,null,4,0,null,0,2,"call"]},
b8V:{"^":"d:36;",
$2:[function(a,b){a.gdA().saQq(K.ay(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
aiK:{"^":"agu;O,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,G,v,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sqa:function(a){var z=this.rx
if(z instanceof F.v)H.k(z,"$isv").cu(this.gdt())
this.atK(a)
if(a instanceof F.v)a.di(this.gdt())},
sa33:function(a){var z=this.k4
if(z instanceof F.v)H.k(z,"$isv").cu(this.gdt())
this.atJ(a)
if(a instanceof F.v)a.di(this.gdt())},
f1:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.O.a
if(z.M(0,a))z.h(0,a).jt(null)
this.atF(a,b,c,d)
return}if(!!J.n(a).$isb1){z=this.O.a
if(!z.M(0,a))z.l(0,a,new E.bY(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jt(b)
y.skP(c)
y.skx(d)}},
o8:[function(a){this.cm()},"$1","gdt",2,0,2,11]},
Cl:{"^":"aAW;b6,dA:C@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bU,c2,c4,bx,bX,bW,c3,c5,c7,c_,bH,cd,cL,cv,cw,cz,co,cA,cB,cH,ce,cq,cr,cb,c8,cM,cj,cC,cD,bK,cc,cf,cE,cI,ck,cp,cN,cX,cJ,cs,cO,cP,cV,cg,cQ,cR,cl,cS,cW,cT,G,v,O,T,U,Y,V,F,a_,P,at,ag,a6,ac,af,ak,ar,aa,aG,aN,aR,ah,aI,aA,aE,al,ao,aF,aO,av,aW,b_,b4,be,b9,b8,aZ,aY,bn,aV,bh,aT,bE,bu,bi,bf,bm,aS,bG,br,bd,bo,bN,bA,bp,bP,bF,bV,bC,bO,bD,bq,bc,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gds:function(){return this.b6},
sf3:function(a,b){if(J.b(this.F,"none")&&!J.b(b,"none")){this.lt(this,b)
this.e4()}else this.lt(this,b)},
hH:[function(a){this.mK(a)
this.siw(!0)
if(a==null)this.C.ic(J.d8(this.b),J.d0(this.b))},"$1","gfo",2,0,2,11],
ui:[function(a){this.C.ic(J.d8(this.b),J.d0(this.b))},"$0","gmW",0,0,0],
a7:[function(){this.siw(!1)
this.fu()
this.C.sGv(!0)
this.C.a7()
this.C.sqa(null)
this.C.sa33(null)
this.C.sGv(!1)},"$0","gd7",0,0,0],
hZ:[function(){this.siw(!1)
this.fu()},"$0","gkn",0,0,0],
fR:function(){this.Bl()
this.siw(!0)},
e4:function(){var z,y
this.yN()
this.soy(-1)
z=this.C
y=J.j(z)
y.sba(z,J.E(y.gba(z),1))},
w9:function(){this.C.ic(J.d8(this.b),J.d0(this.b))},
$isc_:1,
$isc0:1},
aAW:{"^":"aN+o_;oy:x$?,vy:y$?",$iscK:1},
b8W:{"^":"d:46;",
$2:[function(a,b){a.gdA().spv(K.ay(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b8X:{"^":"d:46;",
$2:[function(a,b){a.gdA().saZu(K.ay(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
b8Z:{"^":"d:46;",
$2:[function(a,b){J.Hd(a.gdA(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b9_:{"^":"d:46;",
$2:[function(a,b){a.gdA().sGI(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b90:{"^":"d:46;",
$2:[function(a,b){a.gdA().sa33(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
b91:{"^":"d:46;",
$2:[function(a,b){a.gdA().saRt(K.ak(b,1))},null,null,4,0,null,0,2,"call"]},
b92:{"^":"d:46;",
$2:[function(a,b){a.gdA().sqa(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
b93:{"^":"d:46;",
$2:[function(a,b){a.gdA().sGC(K.ak(b,1))},null,null,4,0,null,0,2,"call"]},
b94:{"^":"d:46;",
$2:[function(a,b){a.gdA().sPZ(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
b95:{"^":"d:46;",
$2:[function(a,b){a.gdA().sQ_(K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
b96:{"^":"d:46;",
$2:[function(a,b){a.gdA().sSV(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b97:{"^":"d:46;",
$2:[function(a,b){a.gdA().sSW(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b99:{"^":"d:46;",
$2:[function(a,b){a.gdA().sSX(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
b9a:{"^":"d:46;",
$2:[function(a,b){a.gdA().sa34(K.ak(b,11))},null,null,4,0,null,0,2,"call"]},
b9b:{"^":"d:46;",
$2:[function(a,b){a.gdA().saRu(K.kr(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
b9c:{"^":"d:46;",
$2:[function(a,b){a.gdA().saS0(K.ak(b,2))},null,null,4,0,null,0,2,"call"]},
b9d:{"^":"d:46;",
$2:[function(a,b){a.gdA().saS1(K.kr(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
b9e:{"^":"d:46;",
$2:[function(a,b){a.gdA().saK3(K.aV(b,null))},null,null,4,0,null,0,2,"call"]},
aiL:{"^":"agv;v,O,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,G,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gjQ:function(){return this.O},
sjQ:function(a){var z=this.O
if(z!=null)z.cu(this.ga6k())
this.O=a
if(a!=null)a.di(this.ga6k())
this.b_F(null)},
b_F:[function(a){var z,y,x,w,v,u,t,s
z=this.O
if(z==null){y=H.a([],[F.o])
x=$.F+1
$.F=x
w=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
z=new F.ee(!1,y,0,null,null,x,null,w,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.P(null,null,null,{func:1,v:true,args:[[P.L,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
z.ch=null
z.fH(F.hG(new F.dt(0,255,0,1),0,0))
z.fH(F.hG(new F.dt(0,0,0,1),0,50))}v=z.fJ()
y=J.bc(v)
y.es(v,F.r6())
u=[]
if(J.W(y.gm(v),1))for(y=y.gb5(v);y.u();){t=y.gE()
x=J.j(t)
w=x.giq(t)
s=H.dv(t.i("alpha"))
s.toString
u.push(new N.w6(w,s,J.R(x.gtk(t),100)))}else if(J.b(y.gm(v),1)){t=y.h(v,0)
y=J.j(t)
x=y.giq(t)
w=H.dv(t.i("alpha"))
w.toString
u.push(new N.w6(x,w,0))
y=y.giq(t)
w=H.dv(t.i("alpha"))
w.toString
u.push(new N.w6(y,w,1))}this.sa8k(u)},"$1","ga6k",2,0,5,11],
eC:function(a,b){var z,y,x,w
if(typeof b==="number"&&Math.floor(b)===b){this.a9Y(a,b)
return}if(!!J.n(a).$isb1){z=this.v.a
if(!z.M(0,a))z.l(0,a,new E.bY(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
z=$.F+1
$.F=z
x=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o])
w=new F.v(z,null,x,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,F.o])),[P.e,F.o]),null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,P.P(null,null,null,{func:1,v:true,args:[[P.L,P.e]]}),!1,H.a([],[P.e]),!1,0,null,null,null,null,null)
w.A("fillType",!0).W("gradient")
w.A("gradient",!0).$2(b,!1)
w.A("gradientType",!0).W("linear")
y.jk(w)}},
a7:[function(){var z=this.O
if(z!=null){z.cu(this.ga6k())
this.O=null}this.atL()},"$0","gd7",0,0,0],
axt:function(){var z=$.$get$Bp()
if(J.b(z.ry,0)){z.fH(F.hG(new F.dt(0,255,0,1),1,0))
z.fH(F.hG(new F.dt(255,255,0,1),1,50))
z.fH(F.hG(new F.dt(255,0,0,1),1,100))}},
ae:{
aiM:function(){var z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.aiL(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.co(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.cy=P.hx()
z.axi()
z.axt()
return z}}},
Cn:{"^":"aAX;b6,dA:C@,a$,b$,c$,d$,e$,f$,r$,x$,y$,bY,bj,bU,c2,c4,bx,bX,bW,c3,c5,c7,c_,bH,cd,cL,cv,cw,cz,co,cA,cB,cH,ce,cq,cr,cb,c8,cM,cj,cC,cD,bK,cc,cf,cE,cI,ck,cp,cN,cX,cJ,cs,cO,cP,cV,cg,cQ,cR,cl,cS,cW,cT,G,v,O,T,U,Y,V,F,a_,P,at,ag,a6,ac,af,ak,ar,aa,aG,aN,aR,ah,aI,aA,aE,al,ao,aF,aO,av,aW,b_,b4,be,b9,b8,aZ,aY,bn,aV,bh,aT,bE,bu,bi,bf,bm,aS,bG,br,bd,bo,bN,bA,bp,bP,bF,bV,bC,bO,bD,bq,bc,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gds:function(){return this.b6},
sf3:function(a,b){if(J.b(this.F,"none")&&!J.b(b,"none")){this.lt(this,b)
this.e4()}else this.lt(this,b)},
hH:[function(a){this.mK(a)
this.siw(!0)},"$1","gfo",2,0,2,11],
ui:[function(a){this.w9()},"$0","gmW",0,0,0],
a7:[function(){this.siw(!1)
this.fu()
this.C.sGv(!0)
this.C.a7()
this.C.sjQ(null)
this.C.sGv(!1)},"$0","gd7",0,0,0],
hZ:[function(){this.siw(!1)
this.fu()},"$0","gkn",0,0,0],
fR:function(){this.Bl()
this.siw(!0)},
e4:function(){var z,y
this.yN()
this.soy(-1)
z=this.C
y=J.j(z)
y.sba(z,J.E(y.gba(z),1))},
w9:function(){if(this.a instanceof F.v)this.C.ic(J.d8(this.b),J.d0(this.b))},
$isc_:1,
$isc0:1},
aAX:{"^":"aN+o_;oy:x$?,vy:y$?",$iscK:1},
b8j:{"^":"d:66;",
$2:[function(a,b){a.gdA().spv(K.ay(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
b8k:{"^":"d:66;",
$2:[function(a,b){J.Hd(a.gdA(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8l:{"^":"d:66;",
$2:[function(a,b){a.gdA().sGI(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
b8m:{"^":"d:66;",
$2:[function(a,b){a.gdA().saXj(K.kr(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
b8n:{"^":"d:66;",
$2:[function(a,b){a.gdA().saXh(K.kr(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
b8o:{"^":"d:66;",
$2:[function(a,b){a.gdA().sj4(K.ay(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
b8p:{"^":"d:66;",
$2:[function(a,b){var z=a.gdA()
z.sjQ(b!=null?F.pc(b):$.$get$Bp())},null,null,4,0,null,0,2,"call"]},
b8r:{"^":"d:66;",
$2:[function(a,b){a.gdA().sPZ(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
b8s:{"^":"d:66;",
$2:[function(a,b){a.gdA().sQ_(K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
b8t:{"^":"d:66;",
$2:[function(a,b){a.gdA().sSV(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b8u:{"^":"d:66;",
$2:[function(a,b){a.gdA().sSW(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
b8v:{"^":"d:66;",
$2:[function(a,b){a.gdA().sSX(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
xc:{"^":"r;a7k:a@,ii:b@,iP:c@"},
afN:{"^":"l7;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,c,d,e,f,r,x,y,z,Q,ch,a,b",
gpU:function(){return this.r1},
spU:function(a){if(!J.b(this.r1,a)){this.r1=a
this.cm()}},
gcG:function(){return this.r2},
scG:function(a){this.aY5(a)},
gjR:function(){return this.go},
iC:function(a,b){var z,y,x,w
this.Ew(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.hx()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.c(a)+"px"
z.width=y
z=this.id.style
y=H.c(b)+"px"
z.height=y
this.f1(this.k1,0,0,"none")
this.eC(this.k1,this.r2.cd)
z=this.k2
y=this.r2
this.f1(z,y.c7,J.aM(y.c_),this.r2.bH)
y=this.k3
z=this.r2
this.f1(y,z.c7,J.aM(z.c_),this.r2.bH)
z=this.db
if(z===2){z=J.W(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a6(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.ax(a))
y=this.k1
y.toString
y.setAttribute("height",J.a6(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a6(J.Q(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.ax(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.c.ax(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.c(this.cy.b)+" L "+H.c(a)+","+H.c(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.c(J.Q(this.cy.b,this.r1.b))+" L "+H.c(a)+","+H.c(J.Q(this.cy.b,this.r1.b)))}else if(z===1){z=J.W(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a6(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a6(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.ax(b))}else{x.toString
x.setAttribute("x",J.a6(J.Q(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.c.ax(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.ax(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.c(this.cy.a)+",0 L "+H.c(this.cy.a)+","+H.c(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.c(J.Q(this.cy.a,this.r1.a))+",0 L "+H.c(J.Q(this.cy.a,this.r1.a))+","+H.c(b))}else if(z===3){z=J.W(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a6(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a6(this.r1.a))}else{y.toString
y.setAttribute("x",J.a6(J.Q(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.c.ax(0-y))}z=J.W(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a6(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a6(this.r1.b))}else{y.toString
y.setAttribute("y",J.a6(J.Q(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.c.ax(0-y))}z=this.k1
y=this.r2
this.f1(z,y.c7,J.aM(y.c_),this.r2.bH)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
aY5:function(a){var z
this.a5v()
this.a5w()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().H(0)
this.r2.qr(0,"CartesianChartZoomerReset",this.gaif())}this.r2=a
if(a!=null){z=J.cB(a.cx)
z=H.a(new W.C(0,z.a,z.b,W.B(this.gaIc()),z.c),[H.x(z,0)])
z.t()
this.fx.push(z)
this.r2.nI(0,"CartesianChartZoomerReset",this.gaif())}this.dx=null
this.dy=null},
Kg:function(a){var z,y,x,w,v
z=this.I1(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.O)(z),++x){v=J.n(z[x])
if(!(!!v.$isqx||!!v.$ishN||!!v.$isiD))return!1}return!0},
aq8:function(a){var z=J.n(a)
if(!!z.$isiD)return J.b6(a.db)?null:a.db
else if(!!z.$isqA)return a.db
return 0/0},
W8:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiD){if(b==null)z=null
else{z=J.bz(b)
y=!a.ak
x=new P.aj(z,y)
x.ey(z,y)
z=x}a.sii(z)}else if(!!z.$ishN)a.sii(b)
else if(!!z.$isqx)a.sii(b)},
arL:function(a,b){return this.W8(a,b,!1)},
aq6:function(a){var z=J.n(a)
if(!!z.$isiD)return J.b6(a.cy)?null:a.cy
else if(!!z.$isqA)return a.cy
return 0/0},
W7:function(a,b,c){var z,y,x
z=J.n(a)
if(!!z.$isiD){if(b==null)z=null
else{z=J.bz(b)
y=!a.ak
x=new P.aj(z,y)
x.ey(z,y)
z=x}a.siP(z)}else if(!!z.$ishN)a.siP(b)
else if(!!z.$isqx)a.siP(b)},
arK:function(a,b){return this.W7(a,b,!1)},
a7f:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[N.dY,L.xc])),[N.dY,L.xc])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[N.dY,L.xc])),[N.dY,L.xc])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.I1(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.O)(v),++u){t=v[u]
s=x.a
if(!s.M(0,t)){r=J.n(t)
r=!!r.$isqx||!!r.$ishN||!!r.$isiD}else r=!1
if(r)s.l(0,t,new L.xc(!1,this.aq8(t),this.aq6(t)))}}y=this.cy
if(z){y=y.b
q=P.aC(y,J.Q(y,b))
y=this.cy.b
p=P.aB(y,J.Q(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aC(y,J.Q(y,b))
y=this.cy.a
m=P.aB(y,J.Q(y,b))
o="h"
q=null
p=null}l=[]
k=N.jo(this.r2.aa,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof N.jB))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.ar:f.ak
r=J.n(h)
if(!(!!r.$isqx||!!r.$ishN||!!r.$isiD)){g=f
break c$0}if(J.bB(C.a.cF(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=Q.b5(y,H.a(new P.H(0,0),[null]))
y=J.aM(Q.aP(J.as(f.gcG()),e).b)
if(typeof q!=="number")return q.w()
y=H.a(new P.H(0,q-y),[null])
y=f.fr.p2([J.E(y.a,C.c.D(f.cy.offsetLeft)),J.E(y.b,C.c.D(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
j=y[1]
e=Q.b5(f.cy,H.a(new P.H(0,0),[null]))
y=J.aM(Q.aP(J.as(f.gcG()),e).b)
if(typeof p!=="number")return p.w()
y=H.a(new P.H(0,p-y),[null])
y=f.fr.p2([J.E(y.a,C.c.D(f.cy.offsetLeft)),J.E(y.b,C.c.D(f.cy.offsetTop))])
if(1>=y.length)return H.f(y,1)
i=y[1]}else{e=Q.b5(y,H.a(new P.H(0,0),[null]))
y=J.aM(Q.aP(J.as(f.gcG()),e).a)
if(typeof m!=="number")return m.w()
y=H.a(new P.H(m-y,0),[null])
y=f.fr.p2([J.E(y.a,C.c.D(f.cy.offsetLeft)),J.E(y.b,C.c.D(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
j=y[0]
e=Q.b5(f.cy,H.a(new P.H(0,0),[null]))
y=J.aM(Q.aP(J.as(f.gcG()),e).a)
if(typeof n!=="number")return n.w()
y=H.a(new P.H(n-y,0),[null])
y=f.fr.p2([J.E(y.a,C.c.D(f.cy.offsetLeft)),J.E(y.b,C.c.D(f.cy.offsetTop))])
if(0>=y.length)return H.f(y,0)
i=y[0]}if(J.ax(i,j)){d=i
i=j
j=d}this.arL(h,j)
this.arK(h,i)
this.fr=!0
break}k.length===y||(0,H.O)(k);++u}if(!this.fr)return
x.a.h(0,h).sa7k(!0)
if(h!=null&&!c){y=this.r2
if(z){y.c3=j
y.c5=i
y.aoN()}else{y.bx=j
y.bX=i
y.aoa()}}},
apk:function(a,b){return this.a7f(a,b,!1)},
amJ:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.I1(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.O)(y),++u){t=y[u]
if(w.M(0,t)){this.W8(t,w.h(0,t).gii(),!0)
this.W7(t,w.h(0,t).giP(),!0)
if(w.h(0,t).ga7k())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.bx=0/0
x.bX=0/0
x.aoa()}},
a5v:function(){return this.amJ(!1)},
amN:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.I1(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.O)(y),++u){t=y[u]
if(w.M(0,t)){this.W8(t,w.h(0,t).gii(),!0)
this.W7(t,w.h(0,t).giP(),!0)
if(w.h(0,t).ga7k())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.c3=0/0
x.c5=0/0
x.aoN()}},
a5w:function(){return this.amN(!1)},
apl:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.a0(a)
if(z.gjI(a)||J.b6(b)){if(this.fr)if(c)this.amN(!0)
else this.amJ(!0)
return}if(!this.Kg(c))return
y=this.I1(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aqr(x)
if(w==null)return
v=J.n(b)
if(c){u=J.Q(w.FG(["0",z.ax(a)]).b,this.a8i(w))
t=J.Q(w.FG(["0",v.ax(b)]).b,this.a8i(w))
this.cy=H.a(new P.H(50,u),[null])
this.a7f(2,J.E(t,u),!0)}else{s=J.Q(w.FG([z.ax(a),"0"]).a,this.a8h(w))
r=J.Q(w.FG([v.ax(b),"0"]).a,this.a8h(w))
this.cy=H.a(new P.H(s,50),[null])
this.a7f(1,J.E(r,s),!0)}},
I1:function(a){var z,y,x,w,v,u,t
z=[]
y=N.jo(this.r2.aa,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.O)(y),++v){u=y[v]
if(!(u instanceof N.jB))continue
if(a){t=u.ar
if(t!=null&&J.ax(C.a.cF(z,t),0))z.push(u.ar)}else{t=u.ak
if(t!=null&&J.ax(C.a.cF(z,t),0))z.push(u.ak)}w=u}return z},
aqr:function(a){var z,y,x,w,v
z=N.jo(this.r2.aa,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.O)(z),++w){v=z[w]
if(!(v instanceof N.jB))continue
if(J.b(v.ar,a)||J.b(v.ak,a))return v
x=v}return},
a8h:function(a){var z=Q.b5(a.cy,H.a(new P.H(0,0),[null]))
return J.aM(Q.aP(J.as(a.gcG()),z).a)},
a8i:function(a){var z=Q.b5(a.cy,H.a(new P.H(0,0),[null]))
return J.aM(Q.aP(J.as(a.gcG()),z).b)},
f1:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.M(0,a))z.h(0,a).jt(null)
R.oy(a,b,c,d)
return}if(!!J.n(a).$isb1){z=this.k4.a
if(!z.M(0,a))z.l(0,a,new E.bY(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jt(b)
y.skP(c)
y.skx(d)}},
eC:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.M(0,a))z.h(0,a).jk(null)
R.rZ(a,b)
return}if(!!J.n(a).$isb1){z=this.k4.a
if(!z.M(0,a))z.l(0,a,new E.bY(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jk(b)}},
b5c:[function(a){var z,y
z=this.r2
if(!z.c2&&!z.bW)return
z.cx.appendChild(this.go)
z=this.r2
this.ic(z.Q,z.ch)
this.cy=Q.aP(this.go,J.cC(a))
this.cx=!0
z=this.fy
y=C.B.cZ(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gaqJ()),y.c),[H.x(y,0)])
y.t()
z.push(y)
y=C.E.cZ(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gaqK()),y.c),[H.x(y,0)])
y.t()
z.push(y)
y=C.a2.cZ(document)
y=H.a(new W.C(0,y.a,y.b,W.B(this.gG2()),y.c),[H.x(y,0)])
y.t()
z.push(y)
this.db=0
this.spU(null)},"$1","gaIc",2,0,4,4],
b1S:[function(a){var z,y
z=Q.aP(this.go,J.cC(a))
if(this.db===0)if(this.r2.c4){if(!(this.Kg(!0)&&this.Kg(!1))){this.Fv()
return}if(J.bB(J.ip(J.E(z.a,this.cy.a)),2)&&J.bB(J.ip(J.E(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.W(J.ip(J.E(z.b,this.cy.b)),J.ip(J.E(z.a,this.cy.a)))){if(this.Kg(!0))this.db=2
else{this.Fv()
return}y=2}else{if(this.Kg(!1))this.db=1
else{this.Fv()
return}y=1}if(y===1)if(!this.r2.c2){this.Fv()
return}if(y===2)if(!this.r2.bW){this.Fv()
return}}y=this.r2
if(P.bf(0,0,y.Q,y.ch,null).oY(0,z)){y=this.db
if(y===2)this.spU(H.a(new P.H(0,J.E(z.b,this.cy.b)),[null]))
else if(y===1)this.spU(H.a(new P.H(J.E(z.a,this.cy.a),0),[null]))
else if(y===3)this.spU(H.a(new P.H(J.E(z.a,this.cy.a),J.E(z.b,this.cy.b)),[null]))
else this.spU(null)}},"$1","gaqJ",2,0,4,4],
b1T:[function(a){var z,y
for(z=this.fy;z.length>0;)z.pop().H(0)
J.a4(this.go)
this.cx=!1
this.cm()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.apk(2,z.b)
z=this.db
if(z===1||z===3)this.apk(1,this.r1.a)}else{this.a5v()
F.a9(new L.afP(this))}},"$1","gaqK",2,0,4,4],
aib:[function(a){if(Q.cU(a)===27)this.Fv()},"$1","gG2",2,0,6,4],
Fv:function(){for(var z=this.fy;z.length>0;)z.pop().H(0)
J.a4(this.go)
this.cx=!1
this.cm()},
b7w:[function(a){this.a5v()
F.a9(new L.afQ(this))},"$1","gaif",2,0,7,4],
axe:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.z(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ae:{
afO:function(){var z=H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.r,E.bY])),[P.r,E.bY])
z=new L.afN(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.a(new K.y(H.a(new H.w(0,null,null,null,null,null,0),[P.e,[P.A,P.aH]])),[P.e,[P.A,P.aH]]))
z.a=z
z.axe()
return z}}},
afP:{"^":"d:3;a",
$0:[function(){this.a.a5w()},null,null,0,0,null,"call"]},
afQ:{"^":"d:3;a",
$0:[function(){this.a.a5w()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.bH,args:[F.v,P.e,P.bH]},{func:1,v:true,args:[[P.L,P.e]]},{func:1,ret:Q.c_},{func:1,v:true,args:[W.cM]},{func:1,v:true,args:[P.r]},{func:1,v:true,args:[W.hv]},{func:1,v:true,args:[E.ck]},{func:1,ret:P.e,args:[N.kK]}]
init.types.push.apply(init.types,deferredTypes)
$.OK=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["Wq","$get$Wq",function(){return P.m(["scaleType",new L.b8w(),"offsetLeft",new L.b8x(),"offsetRight",new L.b8y(),"minimum",new L.b8z(),"maximum",new L.b8A(),"formatString",new L.b8C(),"showMinMaxOnly",new L.b8D(),"percentTextSize",new L.b8E(),"labelsColor",new L.b8F(),"labelsFontFamily",new L.b8G(),"labelsFontStyle",new L.b8H(),"labelsFontWeight",new L.b8I(),"labelsTextDecoration",new L.b8J(),"labelsLetterSpacing",new L.b8K(),"labelsRotation",new L.b8L(),"labelsAlign",new L.b8O(),"angleFrom",new L.b8P(),"angleTo",new L.b8Q(),"percentOriginX",new L.b8R(),"percentOriginY",new L.b8S(),"percentRadius",new L.b8T(),"majorTicksCount",new L.b8U(),"justify",new L.b8V()])},$,"Wr","$get$Wr",function(){var z=P.ai()
z.q(0,E.fp())
z.q(0,$.$get$Wq())
return z},$,"Ws","$get$Ws",function(){return P.m(["scaleType",new L.b8W(),"ticksPlacement",new L.b8X(),"offsetLeft",new L.b8Z(),"offsetRight",new L.b9_(),"majorTickStroke",new L.b90(),"majorTickStrokeWidth",new L.b91(),"minorTickStroke",new L.b92(),"minorTickStrokeWidth",new L.b93(),"angleFrom",new L.b94(),"angleTo",new L.b95(),"percentOriginX",new L.b96(),"percentOriginY",new L.b97(),"percentRadius",new L.b99(),"majorTicksCount",new L.b9a(),"majorTicksPercentLength",new L.b9b(),"minorTicksCount",new L.b9c(),"minorTicksPercentLength",new L.b9d(),"cutOffAngle",new L.b9e()])},$,"Wt","$get$Wt",function(){var z=P.ai()
z.q(0,E.fp())
z.q(0,$.$get$Ws())
return z},$,"Wu","$get$Wu",function(){return P.m(["scaleType",new L.b8j(),"offsetLeft",new L.b8k(),"offsetRight",new L.b8l(),"percentStartThickness",new L.b8m(),"percentEndThickness",new L.b8n(),"placement",new L.b8o(),"gradient",new L.b8p(),"angleFrom",new L.b8r(),"angleTo",new L.b8s(),"percentOriginX",new L.b8t(),"percentOriginY",new L.b8u(),"percentRadius",new L.b8v()])},$,"Wv","$get$Wv",function(){var z=P.ai()
z.q(0,E.fp())
z.q(0,$.$get$Wu())
return z},$])}
$dart_deferred_initializers$["jCbhL6rotVklFL6DCorwls63rJ4="]=$dart_deferred_initializers$.current

//# sourceMappingURL=remote_dataflow.dart.js_1.part.js.map
