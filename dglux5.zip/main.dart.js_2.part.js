self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,D,{"^":"",
aWI:function(){var z=document
z=z.createElement("div")
z=new D.JS(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,[P.C,P.aI]])),[P.u,[P.C,P.aI]]))
z.a=z
z.rH()
z.ao_()
return z},
atg:{"^":"OC;",
sui:["aM6",function(a){if(!J.a(this.k4,a)){this.k4=a
this.ds()}}],
sMy:function(a){if(!J.a(this.r1,a)){this.r1=a
this.ds()}},
sT3:function(a){if(!J.a(this.r2,a)){this.r2=a
this.ds()}},
sMz:function(a){if(!J.a(this.rx,a)){this.rx=a
this.ds()}},
sMA:function(a){if(!J.a(this.ry,a)){this.ry=a
this.ds()}},
sMC:function(a){if(!J.a(this.x1,a)){this.x1=a
this.ds()}},
sMB:function(a){if(!J.a(this.x2,a)){this.x2=a
this.ds()}},
sbcX:function(a){if(!J.a(this.y1,a)){if(J.x(a,180))a=180
this.y1=J.Q(a,-180)?-180:a
this.ds()}},
sbcW:function(a){if(J.a(this.y2,a))return
this.y2=a
this.ds()},
gjQ:function(a){return this.A},
sjQ:function(a,b){if(b==null)b=0
if(!J.a(this.A,b)){this.A=b
this.ds()}},
gkE:function(a){return this.S},
skE:function(a,b){if(b==null)b=100
if(!J.a(this.S,b)){this.S=b
this.ds()}},
sbli:function(a){if(this.J!==a){this.J=a
this.ds()}},
gy3:function(a){return this.a2},
sy3:function(a,b){if(b==null||J.Q(b,0))b=0
if(J.x(b,4))b=4
if(!J.a(this.a2,b)){this.a2=b
this.ds()}},
saK9:function(a){if(this.O!==a){this.O=a
this.ds()}},
szo:function(a){this.a4=a
this.ds()},
gtB:function(){return this.T},
stB:function(a){if(!J.a(this.T,a)){this.T=a
this.ds()}},
sbcH:function(a){if(!J.a(this.W,a)){this.W=a
this.ds()}},
gwD:function(a){return this.M},
swD:["amq",function(a,b){if(!J.a(this.M,b))this.M=b}],
sMY:["amr",function(a){if(!J.a(this.ag,a))this.ag=a}],
saeu:function(a){this.amt(a)
this.ds()},
jT:function(a,b){this.Kg(a,b)
this.Uq()
if(J.a(this.T,"circular"))this.blB(a,b)
else this.blC(a,b)},
Uq:function(){var z,y,x,w,v
z=this.O
y=this.k2
if(z){y.seX(0,2)
z=this.k2.f
if(0>=z.length)return H.e(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isdz)z.sbT(x,this.ab4(this.A,this.a2))
J.a6(J.b9(x.gb_()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.e(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isdz)z.sbT(x,this.ab4(this.S,this.a2))
J.a6(J.b9(x.gb_()),"text-decoration",this.x1)}else{y.seX(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.e(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isdz){y=this.A
w=J.k(y,J.B(J.M(J.q(this.S,y),J.q(this.fy,1)),v))
z.sbT(x,this.ab4(w,this.a2))}J.a6(J.b9(x.gb_()),"text-decoration",this.x1);++v}}this.fv(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",H.b(this.r2)+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.b(this.x2)+"px")},
blB:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.M(J.q(this.fr,this.dy),z-1)
x=P.aB(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.M(a,2)
x=P.aB(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.q(w,x*(50-u)/100)
u=J.M(b,2)
x=P.aB(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.q(u,x*(50-w)/100)
r=C.c.B(this.J,"%")&&!0
x=this.J
if(r){H.cr("")
x=H.e4(x,"%","")}q=P.dI(x,null)
for(x=J.aA(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.e(w,p)
o=w[p]
w=J.k(J.q(this.dy,90),x.bD(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.OD(o)
w=m.b
u=J.G(w)
if(u.bx(w,0)){if(r){l=P.aB(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.M(l,w)}else k=0
l=m.a
j=J.aA(l)
i=J.k(j.bD(l,l),u.bD(w,w))
if(typeof i!=="number")H.ab(H.br(i))
i=Math.sqrt(i)
h=J.B(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.W){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.B(j.dP(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.B(u.dP(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a6(J.b9(o.gb_()),"transform","")
i=J.n(o)
if(!!i.$isdb)i.jz(o,d,c)
else N.fx(o.gb_(),d,c)
i=J.b9(o.gb_())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," scale ("+H.b(k)+")"))
if(!J.a(this.y1,0))if(!!J.n(o.gb_()).$isnY){i=J.b9(o.gb_())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," rotate("+H.b(this.y1)+" "+H.b(j.dP(l,2))+" "+H.b(J.M(u.fF(w),2))+")"))}else{J.hR(J.J(o.gb_())," rotate("+H.b(this.y1)+"deg)")
J.ps(J.J(o.gb_()),H.b(J.B(j.dP(l,2),k))+" "+H.b(J.B(u.dP(w,2),k)))}}},
blC:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.M(J.q(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.e(x,0)
w=this.OD(x[0])
v=C.c.B(this.J,"%")&&!0
x=this.J
if(v){H.cr("")
x=H.e4(x,"%","")}u=P.dI(x,null)
x=w.b
t=J.G(x)
if(t.bx(x,0))s=J.M(v?J.M(J.B(a,u),200):u,x)
else s=0
r=J.M(J.B(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ai(r)))
p=Math.abs(Math.sin(H.ai(r)))
this.amq(this,J.B(J.M(J.k(J.B(w.a,q),t.bD(x,p)),2),s))
this.a2U()
x=this.k2.f
if(y<0||y>=x.length)return H.e(x,y)
w=this.OD(x[y])
x=w.b
t=J.G(x)
if(t.bx(x,0))s=J.M(v?J.M(J.B(a,u),200):u,x)
else s=0
this.amr(J.B(J.M(J.k(J.B(w.a,q),t.bD(x,p)),2),s))
this.a2U()
if(!J.a(this.y1,0)){for(x=J.aA(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.e(t,n)
w=this.OD(t[n])
t=w.b
m=J.G(t)
if(m.bx(t,0))J.M(v?J.M(x.bD(a,u),200):u,t)
o=P.aH(J.k(J.B(w.a,p),m.bD(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.G(a)
k=J.M(J.q(x.E(a,this.M),this.ag),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.e(y,n)
j=y[n]
y=this.M
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.k(y,t)
w=this.OD(j)
y=w.b
m=J.G(y)
if(m.bx(y,0))s=J.M(v?J.M(x.bD(a,u),200):u,y)
else s=0
h=w.a
g=J.G(h)
i=J.q(i,J.B(g.dP(h,2),s))
J.a6(J.b9(j.gb_()),"transform","")
if(J.a(this.y1,0)){y=J.B(J.k(g.bD(h,p),m.bD(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$isdb)y.jz(j,i,f)
else N.fx(j.gb_(),i,f)
y=J.b9(j.gb_())
t=J.H(y)
t.l(y,"transform",J.k(t.h(y,"transform")," scale ("+H.b(s)+")"))}else{i=J.q(J.k(this.M,t),g.dP(h,2))
t=J.k(g.bD(h,p),m.bD(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$isdb)t.jz(j,i,e)
else N.fx(j.gb_(),i,e)
d=g.dP(h,2)
c=-y/2
y=J.b9(j.gb_())
t=J.H(y)
m=s-1
t.l(y,"transform",J.k(t.h(y,"transform")," translate("+H.b(J.B(J.bJ(d),m))+" "+H.b(-c*m)+")"))
m=J.b9(j.gb_())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," scale ("+H.b(s)+")"))
m=J.b9(j.gb_())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," rotate("+H.b(this.y1)+" "+H.b(d)+" "+H.b(c)+")"))}}},
OD:function(a){var z,y,x,w
if(!!J.n(a.gb_()).$isf9){z=H.j(a.gb_(),"$isf9").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.bD()
w=x*0.7}else{y=J.dc(a.gb_())
y.toString
w=J.d1(a.gb_())
w.toString}return H.d(new P.F(y,w),[null])},
abh:[function(){return D.Gv()},"$0","gxy",0,0,3],
ab4:function(a,b){var z=this.a4
if(z==null||J.a(z,""))return O.ql(a,"0",null,null)
else return O.ql(a,this.a4,null,null)},
X:[function(){this.amt(0)
this.ds()
var z=this.k2
z.d=!0
z.r=!0
z.seX(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gdu",0,0,0],
aQk:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.w(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new D.oO(this.gxy(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
OC:{"^":"mF;",
ga6x:function(){return this.cy},
sa0O:["aMa",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.x(a,100))a=100
if(!J.a(this.db,a)){this.db=a
this.ds()}}],
sa0P:["aMb",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.x(a,100))a=100
if(!J.a(this.dx,a)){this.dx=a
this.ds()}}],
sYs:["aM7",function(a){if(J.Q(a,-360))a=-360
if(J.x(a,360))a=360
if(!J.a(this.dy,a)){this.dy=a
this.eB()
this.ds()}}],
sasQ:["aM8",function(a,b){if(J.Q(b,-360))b=-360
if(J.x(b,360))b=360
if(!J.a(this.fr,b)){this.fr=b
this.eB()
this.ds()}}],
sbeJ:function(a){if(a==null||J.Q(a,0))a=0
if(J.x(a,20))a=20
if(!J.a(this.fx,a)){this.fx=a
this.ds()}},
saeu:["amt",function(a){if(a==null||J.Q(a,2))a=2
if(J.x(a,30))a=30
if(!J.a(this.fy,a)){this.fy=a
this.ds()}}],
sbeK:function(a){if(this.go!==a){this.go=a
this.ds()}},
sbe8:function(a){if(this.id!==a){this.id=a
this.ds()}},
sa0Q:["aMc",function(a){if(a==null||J.Q(a,0))a=0
if(J.x(a,200))a=200
if(!J.a(this.k1,a)){this.k1=a
this.ds()}}],
glb:function(){return this.cy},
fQ:["aM9",function(a,b,c,d){R.qW(a,b,c,d)}],
fv:["ams",function(a,b){R.vX(a,b)}],
DY:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.h(a)
if(y!=="")J.a6(z.gfK(a),"d",y)
else J.a6(z.gfK(a),"d","M 0,0")}},
ath:{"^":"OC;",
saet:["aMd",function(a){if(!J.a(this.k4,a)){this.k4=a
this.ds()}}],
sbe7:function(a){if(!J.a(this.r2,a)){this.r2=a
this.ds()}},
sul:["aMe",function(a){if(!J.a(this.rx,a)){this.rx=a
this.ds()}}],
saeM:function(a){if(!J.a(this.ry,a)){this.ry=a
this.ds()}},
sMS:function(a){if(!J.a(this.x1,a)){this.x1=a
this.ds()}},
gtB:function(){return this.x2},
stB:function(a){if(!J.a(this.x2,a)){this.x2=a
this.ds()}},
gwD:function(a){return this.y1},
swD:function(a,b){if(!J.a(this.y1,b)){this.y1=b
this.ds()}},
sMY:function(a){if(!J.a(this.y2,a)){this.y2=a
this.ds()}},
sbon:function(a){if(!J.a(this.w,a)){this.w=a
this.ds()}},
sb4u:function(a){var z
if(!J.a(this.A,a)){this.A=a
if(a!=null){z=J.q(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.S=z
this.ds()}},
jT:function(a,b){var z,y
this.Kg(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.fQ(this.k2,this.k4,J.aR(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.fQ(this.k3,this.rx,J.aR(this.x1),this.ry)
if(J.a(this.x2,"circular"))this.b6U(a,b)
else this.b6V(a,b)},
b6U:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.M(J.q(this.fr,this.dy),J.q(J.k(J.B(this.fx,J.q(this.fy,1)),this.fy),1))
x=C.c.B(this.go,"%")&&!0
w=this.go
if(x){H.cr("")
w=H.e4(w,"%","")}v=P.dI(w,null)
if(x){w=P.aB(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aB(a,b)
w=J.M(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.q(w,t*(50-s)/100)
s=J.M(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.q(s,t*(50-w)/100)
w=P.aB(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.a(this.w,"center"))o=0.5
else o=J.a(this.w,"outside")?1:0
w=o-1
s=J.aA(y)
n=0
while(!0){m=J.k(J.B(this.fx,J.q(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.k(J.q(this.dy,90),s.bD(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.S
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++n}this.DY(this.k3)
z.a=""
y=J.M(J.q(this.fr,this.dy),J.q(this.fy,1))
h=C.c.B(this.id,"%")&&!0
s=this.id
if(h){H.cr("")
s=H.e4(s,"%","")}g=P.dI(s,null)
if(h){s=P.aB(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.aA(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.k(J.q(this.dy,90),s.bD(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.S
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++f}this.DY(this.k2)},
b6V:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.B(this.go,"%")&&!0
y=this.go
if(z){H.cr("")
y=H.e4(y,"%","")}x=P.dI(y,null)
w=z?J.M(J.B(J.M(a,2),x),100):x
v=C.c.B(this.id,"%")&&!0
y=this.id
if(v){H.cr("")
y=H.e4(y,"%","")}u=P.dI(y,null)
t=v?J.M(J.B(J.M(a,2),u),100):u
y=this.cx
y.a=""
s=J.G(a)
r=J.M(J.q(s.E(a,this.y1),this.y2),J.q(J.k(J.B(this.fx,J.q(this.fy,1)),this.fy),1))
if(J.a(this.w,"center"))q=0.5
else q=J.a(this.w,"outside")?1:0
p=J.G(t)
o=p.E(t,w)
n=1-q
m=0
while(!0){l=J.k(J.B(this.fx,J.q(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.E(t,q*o)
y.a+="M "+H.b(k)+","+H.b(n*o)+" "
y.a+="L "+H.b(k)+","+H.b(j)+" ";++m}this.DY(this.k3)
y.a=""
r=J.M(J.q(s.E(a,this.y1),this.y2),J.q(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.b(k)+",0 "
y.a+="L "+H.b(k)+","+H.b(t)+" ";++i}this.DY(this.k2)},
X:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.DY(z)
this.DY(this.k3)}},"$0","gdu",0,0,0]},
ati:{"^":"OC;",
sa0O:function(a){this.aMa(a)
this.r2=!0},
sa0P:function(a){this.aMb(a)
this.r2=!0},
sYs:function(a){this.aM7(a)
this.r2=!0},
sasQ:function(a,b){this.aM8(this,b)
this.r2=!0},
sa0Q:function(a){this.aMc(a)
this.r2=!0},
sblh:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.ds()}},
sblg:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.ds()}},
sakq:function(a){if(this.x2!==a){this.x2=a
this.eB()
this.ds()}},
gka:function(){return this.y1},
ska:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.a(this.y1,a)){this.y1=a
this.r2=!0
this.ds()}},
gtB:function(){return this.y2},
stB:function(a){if(!J.a(this.y2,a)){this.y2=a
this.r2=!0
this.ds()}},
gwD:function(a){return this.w},
swD:function(a,b){if(!J.a(this.w,b)){this.w=b
this.r2=!0
this.ds()}},
sMY:function(a){if(!J.a(this.A,a)){this.A=a
this.r2=!0
this.ds()}},
kz:function(a){var z,y,x,w,v,u,t,s,r
this.Dt(this)
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.K)(z),++u){t=z[u]
s=J.h(t)
y.push(s.ghU(t))
x.push(s.gDX(t))
w.push(s.gvw(t))}if(J.c8(J.q(this.dy,this.fr))===!0){z=J.aW(J.q(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.f.U(0.5*z)}else r=0
this.k2=this.b3a(y,w,r)
this.k3=this.b07(x,w,r)
this.r2=!0},
jT:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.Kg(a,b)
z=J.aA(a)
y=J.aA(b)
N.JH(this.k4,z.bD(a,1),y.bD(b,1))
if(J.a(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aB(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.a(this.y2,"circular")){z=P.aH(0,P.aB(a,b))
this.rx=z
this.b6X(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.b(this.rx)+" "+H.b(this.rx))}else{z=J.B(J.q(z.E(a,this.w),this.A),1)
y.bD(b,1)
v=C.c.B(this.ry,"%")&&!0
y=this.ry
if(v){H.cr("")
y=H.e4(y,"%","")}u=P.dI(y,null)
t=v?J.M(J.B(z,u),100):u
s=C.c.B(this.x1,"%")&&!0
y=this.x1
if(s){H.cr("")
y=H.e4(y,"%","")}r=P.dI(y,null)
q=s?J.M(J.B(z,r),100):r
this.r1.seX(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.q(q,t)
p=q
o=p
m=0
break
case"cross":y=J.G(q)
x=J.G(t)
o=J.k(y.dP(q,2),x.dP(t,2))
n=J.q(y.dP(q,2),x.dP(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.d(new P.F(this.w,o),[null])
k=H.d(new P.F(this.w,n),[null])
j=H.d(new P.F(J.k(this.w,z),p),[null])
i=H.d(new P.F(J.k(this.w,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.e(y,0)
h=y[0]
this.fv(h.gb_(),this.J)
R.qW(h.gb_(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.b(y)+","+H.b(x)+" "
z.a+="L "+H.b(j.a)+","+H.b(j.b)+" "
z.a+="L "+H.b(i.a)+","+H.b(i.b)+" "
z.a+="L "+H.b(k.a)+","+H.b(k.b)+" "
z.a+="L "+H.b(y)+","+H.b(x)+" "
this.DY(h.gb_())
x=this.cy
x.toString
new W.e1(x).K(0,"viewBox")}},
b3a:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.lo(J.B(J.q(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.e(a,y)
t=J.a2(J.cb(a[y],16),255)
if(y>=a.length)return H.e(a,y)
s=J.a2(J.cb(a[y],8),255)
if(y>=a.length)return H.e(a,y)
r=J.a2(a[y],255)
if(x>=a.length)return H.e(a,x)
q=J.a2(J.cb(a[x],16),255)
if(x>=a.length)return H.e(a,x)
p=J.a2(J.cb(a[x],8),255)
if(x>=a.length)return H.e(a,x)
o=J.a2(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.U(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.U(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.U(w*r+m*o)&255)>>>0)}}return z},
b07:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.lo(J.B(J.q(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.e(a,x)
v=a[x]
if(y>=w)return H.e(a,y)
t=J.M(J.q(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.e(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.k(w,s*t))}}return z},
b6X:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aB(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.B(this.ry,"%")&&!0
z=this.ry
if(v){H.cr("")
z=H.e4(z,"%","")}u=P.dI(z,new D.atj())
if(v){z=P.aB(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.B(this.x1,"%")&&!0
z=this.x1
if(s){H.cr("")
z=H.e4(z,"%","")}r=P.dI(z,new D.atk())
if(s){z=P.aB(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aB(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aB(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.seX(0,w)
for(z=J.G(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.q(this.dy,90)
d=J.q(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.k(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.E(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.e(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.e(e,d)
g=J.aV(J.B(e[d],255))
g=J.bi(J.a(g,0)?1:g,24)
e=h.gb_()
a3=this.k2
if(d>=a3.length)return H.e(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.fv(e,a3+g)
a3=h.gb_()
e=this.k2
if(d>=e.length)return H.e(e,d)
R.qW(a3,e[d]+g,1,"solid")
y.a+="M "+H.b(l)+","+H.b(k)+" "
y.a+="L "+H.b(a)+","+H.b(a0)+" "
y.a+="L "+H.b(a1)+","+H.b(a2)+" "
y.a+="L "+H.b(j)+","+H.b(i)+" "
y.a+="L "+H.b(l)+","+H.b(k)+" "
this.DY(h.gb_())}}},
bFt:[function(){var z,y
z=new D.adx(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gbl7",0,0,3],
X:["aMf",function(){var z=this.r1
z.d=!0
z.r=!0
z.seX(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gdu",0,0,0],
aQl:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sakq([new D.zO(65280,0.5,0),new D.zO(16776960,0.8,0.5),new D.zO(16711680,1,1)])
z=new D.oO(this.gbl7(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
atj:{"^":"c:0;",
$1:function(a){return 0}},
atk:{"^":"c:0;",
$1:function(a){return 0}},
zO:{"^":"t;hU:a*,DX:b>,vw:c>"}}],["","",,E,{"^":"",
c5Y:[function(a){var z=!!J.n(a.gmE().gb_()).$ishl?H.j(a.gmE().gb_(),"$ishl"):null
if(z!=null)if(z.gpH()!=null&&!J.a(z.gpH(),""))return E.a_X(a.gmE(),z.gpH())
else return z.Mc(a)
return""},"$1","bXZ",2,0,9,57],
bUL:function(){if($.WP)return
$.WP=!0
$.$get$iy().l(0,"percentTextSize",E.bY3())
$.$get$iy().l(0,"minorTicksPercentLength",E.alo())
$.$get$iy().l(0,"majorTicksPercentLength",E.alo())
$.$get$iy().l(0,"percentStartThickness",E.alq())
$.$get$iy().l(0,"percentEndThickness",E.alq())
$.$get$iz().l(0,"percentTextSize",E.bY4())
$.$get$iz().l(0,"minorTicksPercentLength",E.alp())
$.$get$iz().l(0,"majorTicksPercentLength",E.alp())
$.$get$iz().l(0,"percentStartThickness",E.alr())
$.$get$iz().l(0,"percentEndThickness",E.alr())},
blT:function(a){var z
switch(a){case"chart":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$GM())
return z
case"scaleTicks":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$HX())
return z
case"scaleLabels":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$HV())
return z
case"scaleTrack":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$QU())
return z
case"linearAxis":return $.$get$yv()
case"logAxis":return $.$get$yy()
case"categoryAxis":return $.$get$vM()
case"datetimeAxis":return $.$get$yg()
case"axisRenderer":return $.$get$vF()
case"radialAxisRenderer":return $.$get$QN()
case"angularAxisRenderer":return $.$get$OO()
case"linearAxisRenderer":return $.$get$vF()
case"logAxisRenderer":return $.$get$vF()
case"categoryAxisRenderer":return $.$get$vF()
case"datetimeAxisRenderer":return $.$get$vF()
case"lineSeries":return $.$get$yt()
case"areaSeries":return $.$get$Gs()
case"columnSeries":return $.$get$GO()
case"barSeries":return $.$get$Gz()
case"bubbleSeries":return $.$get$GG()
case"pieSeries":return $.$get$C8()
case"spectrumSeries":return $.$get$R8()
case"radarSeries":return $.$get$Ce()
case"lineSet":return $.$get$tI()
case"areaSet":return $.$get$Gu()
case"columnSet":return $.$get$GQ()
case"barSet":return $.$get$GB()
case"gridlines":return $.$get$PV()}return[]},
blR:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof E.oo)return a
else{z=$.$get$a1u()
y=H.d([],[D.eE])
x=H.d([],[N.k5])
w=H.d([],[E.j8])
v=H.d([],[N.k5])
u=H.d([],[E.j8])
t=H.d([],[N.k5])
s=H.d([],[E.Bx])
r=H.d([],[N.k5])
q=H.d([],[E.Cf])
p=H.d([],[N.k5])
o=$.$get$aq()
n=$.T+1
$.T=n
n=new E.oo(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,null,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a9(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
n.cb(b,"chart")
J.V(J.w(n.b),"absolute")
o=E.avP()
n.v=o
J.bF(n.b,o.cx)
o=n.v
o.bB=n
o.UW()
o=E.asv()
n.C=o
o.sdq(n.v)
return n}case"scaleTicks":if(a instanceof E.HW)return a
else{z=$.$get$a55()
y=$.$get$aq()
x=$.T+1
$.T=x
x=new E.HW(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a9(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cb(b,"scale-ticks")
J.V(J.w(x.b),"absolute")
z=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.t,N.ce])),[P.t,N.ce])
z=new E.aw3(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cx(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,[P.C,P.aI]])),[P.u,[P.C,P.aI]]))
z.a=z
z.cy=P.iF()
x.v=z
J.bF(x.b,z.ga6x())
return x}case"scaleLabels":if(a instanceof E.HU)return a
else{z=$.$get$a53()
y=$.$get$aq()
x=$.T+1
$.T=x
x=new E.HU(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a9(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cb(b,"scale-labels")
J.V(J.w(x.b),"absolute")
z=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.t,N.ce])),[P.t,N.ce])
z=new E.aw1(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cx(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,[P.C,P.aI]])),[P.u,[P.C,P.aI]]))
z.a=z
z.cy=P.iF()
z.aQk()
x.v=z
J.bF(x.b,z.ga6x())
x.v.sec(x)
return x}case"scaleTrack":if(a instanceof E.HY)return a
else{z=$.$get$a57()
y=$.$get$aq()
x=$.T+1
$.T=x
x=new E.HY(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a9(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cb(b,"scale-track")
J.V(J.w(x.b),"absolute")
J.lp(J.J(x.b),"hidden")
y=E.aw5()
x.v=y
J.bF(x.b,y.ga6x())
return x}}return},
c6t:[function(){var z=new E.axf(null,null,null)
z.anO()
return z},"$0","bY_",0,0,3],
avP:function(){var z,y,x,w,v,u,t
z=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.t,N.ce])),[P.t,N.ce])
y=P.bp(0,0,0,0,null)
x=P.bp(0,0,0,0,null)
w=new D.da(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.d([],[P.fn])
t=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,P.t])),[P.u,P.t])
z=new E.on(z,null,"none",!1,!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",D.bXs(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,[P.C,P.aI]])),[P.u,[P.C,P.aI]]))
z.a=z
z.aQj("chartBase")
z.aQh()
z.aR2()
z.sZB("single")
z.aQw()
return z},
cdw:[function(a,b,c){return E.bkr(a,c)},"$3","bY3",6,0,1,17,31,1],
bkr:function(a,b){var z,y,x
z=a.G("view")
if(z==null)return
y=J.d9(z)
if(y==null)return
x=J.h(y)
return J.M(J.B(J.a(y.gtB(),"circular")?P.aB(x.gbK(y),x.gcm(y)):x.gbK(y),b),200)},
cdx:[function(a,b,c){return E.bks(a,c)},"$3","bY4",6,0,1,17,31,1],
bks:function(a,b){var z,y,x,w
z=a.G("view")
if(z==null)return
y=J.d9(z)
if(y==null)return
x=J.B(b,200)
w=J.h(y)
return J.M(x,J.a(y.gtB(),"circular")?P.aB(w.gbK(y),w.gcm(y)):w.gbK(y))},
cdy:[function(a,b,c){return E.bkt(a,c)},"$3","alo",6,0,1,17,31,1],
bkt:function(a,b){var z,y,x
z=a.G("view")
if(z==null)return
y=J.d9(z)
if(y==null)return
x=J.h(y)
return J.M(J.B(J.a(y.gtB(),"circular")?P.aB(x.gbK(y),x.gcm(y)):x.gbK(y),b),200)},
cdz:[function(a,b,c){return E.bku(a,c)},"$3","alp",6,0,1,17,31,1],
bku:function(a,b){var z,y,x,w
z=a.G("view")
if(z==null)return
y=J.d9(z)
if(y==null)return
x=J.B(b,200)
w=J.h(y)
return J.M(x,J.a(y.gtB(),"circular")?P.aB(w.gbK(y),w.gcm(y)):w.gbK(y))},
cdA:[function(a,b,c){return E.bkv(a,c)},"$3","alq",6,0,1,17,31,1],
bkv:function(a,b){var z,y,x
z=a.G("view")
if(z==null)return
y=J.d9(z)
if(y==null)return
x=J.h(y)
if(J.a(y.gtB(),"circular")){x=P.aB(x.gbK(y),x.gcm(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.M(J.B(x.gbK(y),b),100)
return x},
cdB:[function(a,b,c){return E.bkw(a,c)},"$3","alr",6,0,1,17,31,1],
bkw:function(a,b){var z,y,x,w
z=a.G("view")
if(z==null)return
y=J.d9(z)
if(y==null)return
x=J.aA(b)
w=J.h(y)
return J.a(y.gtB(),"circular")?J.M(x.bD(b,200),P.aB(w.gbK(y),w.gcm(y))):J.M(x.bD(b,100),w.gbK(y))},
axf:{"^":"RB;a,b,c",
sbT:function(a,b){var z,y,x,w,v
if(J.a(this.b,b))return
this.aN7(this,b)
if(b instanceof D.mb){z=b.e
if(z.gb_() instanceof D.eE&&H.j(z.gb_(),"$iseE").w!=null){J.AW(J.J(this.a),"")
return}y=U.c5(b.r,"fault")
if(y==="fault"&&b.r instanceof V.v){x=b.r
if(J.a(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof V.eV&&J.x(w.x1,0)){z=H.j(w.dn(0),"$iski")
y=U.e2(z.ghU(z),null,"rgba(0,0,0,0)")}}}v=H.b(y==="fault"?U.e2(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.AW(J.J(this.a),v)}},
al1:function(a){J.aY(this.a,a,$.$get$ax())}},
aw1:{"^":"atg;ac,aa,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,S,J,a2,O,a4,a5,T,W,M,ag,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sui:function(a){var z=this.k4
if(z instanceof V.v)H.j(z,"$isv").dr(this.ges())
this.aM6(a)
if(a instanceof V.v)a.dM(this.ges())},
swD:function(a,b){this.amq(this,b)
this.a2U()},
sMY:function(a){this.amr(a)
this.a2U()},
gec:function(){return this.aa},
sec:function(a){H.j(a,"$isaU")
this.aa=a
if(a!=null)V.bc(this.gbqr())},
fv:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.ams(a,b)
return}if(!!J.n(a).$isbl){z=this.ac.a
if(!z.V(0,a))z.l(0,a,new N.ce(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kJ(b)}},
rs:[function(a){this.ds()},"$1","ges",2,0,2,9],
a2U:[function(){var z=this.aa
if(z!=null)if(z.a instanceof V.v)V.W(new E.aw2(this))},"$0","gbqr",0,0,0]},
aw2:{"^":"c:3;a",
$0:[function(){var z=this.a
z.aa.a.bj("offsetLeft",z.M)
z.aa.a.bj("offsetRight",z.ag)},null,null,0,0,null,"call"]},
HU:{"^":"aUS;aK,fz:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cg,cc,c6,cs,cp,ct,cE,cP,bW,cQ,cv,cB,cH,c3,cq,cu,cw,cL,cC,cM,cI,cT,cU,cJ,cK,cR,cz,cV,cd,cY,bJ,cA,cS,cZ,cF,cl,cG,d_,dh,d1,d4,di,d2,cW,d5,d6,dd,cr,d7,d8,cN,d9,de,df,d3,da,d0,co,dg,dc,O,a4,a5,T,W,M,ag,ac,aa,ad,ar,ae,al,a8,aw,av,aJ,ai,aT,aD,aF,aq,ay,aU,aX,aE,aW,bb,aN,b6,bl,bm,aV,bp,bd,bc,bt,bh,bz,bO,by,bg,bu,b4,bv,bq,bw,bP,ce,c1,bV,c_,bR,c7,bS,bZ,bY,c0,bE,bC,bB,bG,cf,cn,bF,c5,c8,y2,w,A,S,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdV:function(){return this.aK},
seY:function(a,b){if(J.a(this.ac,"none")&&!J.a(b,"none")){this.mV(this,b)
this.eA()}else this.mV(this,b)},
h4:[function(a,b){this.mW(this,b)
this.shF(!0)},"$1","gfg",2,0,2,9],
k8:[function(a){this.uG()},"$0","giv",0,0,0],
X:[function(){this.shF(!1)
this.fU()
this.v.sMK(!0)
this.v.X()
this.v.sui(null)
this.v.sMK(!1)},"$0","gdu",0,0,0],
iq:[function(){this.shF(!1)
this.fU()},"$0","gkC",0,0,0],
hg:function(){this.x7()
this.shF(!0)},
uG:function(){if(this.a instanceof V.v)this.v.jn(J.dc(this.b),J.d1(this.b))},
eA:function(){var z,y
this.Dw()
this.soK(-1)
z=this.v
y=J.h(z)
y.sbK(z,J.q(y.gbK(z),1))},
$isbO:1,
$isbQ:1,
$isct:1},
aUS:{"^":"aU+lH;oK:x$?,uj:y$?",$isct:1},
bEo:{"^":"c:44;",
$2:[function(a,b){J.d9(a).stB(U.ap(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bEp:{"^":"c:44;",
$2:[function(a,b){J.NC(J.d9(a),U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bEq:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sMY(U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bEr:{"^":"c:44;",
$2:[function(a,b){J.xK(J.d9(a),U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bEt:{"^":"c:44;",
$2:[function(a,b){J.xJ(J.d9(a),U.b4(b,100))},null,null,4,0,null,0,2,"call"]},
bEu:{"^":"c:44;",
$2:[function(a,b){J.d9(a).szo(U.E(b,""))},null,null,4,0,null,0,2,"call"]},
bEv:{"^":"c:44;",
$2:[function(a,b){J.d9(a).saK9(U.R(b,!1))},null,null,4,0,null,0,2,"call"]},
bEw:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sbli(U.kx(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bEx:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sui(R.cZ(b,16777215))},null,null,4,0,null,0,2,"call"]},
bEy:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sMy($.hJ.$3(a.gI(),b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bEz:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sMz(U.ap(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bEA:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sMA(U.ap(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bEB:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sMC(U.ap(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bEC:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sMB(U.ah(b,0))},null,null,4,0,null,0,2,"call"]},
bEE:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sbcX(U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bEF:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sbcW(U.ap(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bEG:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sYs(U.b4(b,-120))},null,null,4,0,null,0,2,"call"]},
bEH:{"^":"c:44;",
$2:[function(a,b){J.Nn(J.d9(a),U.b4(b,120))},null,null,4,0,null,0,2,"call"]},
bEI:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sa0O(U.b4(b,50))},null,null,4,0,null,0,2,"call"]},
bEJ:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sa0P(U.b4(b,50))},null,null,4,0,null,0,2,"call"]},
bEK:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sa0Q(U.b4(b,90))},null,null,4,0,null,0,2,"call"]},
bEL:{"^":"c:44;",
$2:[function(a,b){J.d9(a).saeu(U.ah(b,11))},null,null,4,0,null,0,2,"call"]},
bEM:{"^":"c:44;",
$2:[function(a,b){J.d9(a).sbcH(U.ap(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
aw3:{"^":"ath;J,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,S,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sul:function(a){var z=this.rx
if(z instanceof V.v)H.j(z,"$isv").dr(this.ges())
this.aMe(a)
if(a instanceof V.v)a.dM(this.ges())},
saet:function(a){var z=this.k4
if(z instanceof V.v)H.j(z,"$isv").dr(this.ges())
this.aMd(a)
if(a instanceof V.v)a.dM(this.ges())},
fQ:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.J.a
if(z.V(0,a))z.h(0,a).kT(null)
this.aM9(a,b,c,d)
return}if(!!J.n(a).$isbl){z=this.J.a
if(!z.V(0,a))z.l(0,a,new N.ce(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kT(b)
y.smw(c)
y.sma(d)}},
rs:[function(a){this.ds()},"$1","ges",2,0,2,9]},
HW:{"^":"aUT;aK,fz:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cg,cc,c6,cs,cp,ct,cE,cP,bW,cQ,cv,cB,cH,c3,cq,cu,cw,cL,cC,cM,cI,cT,cU,cJ,cK,cR,cz,cV,cd,cY,bJ,cA,cS,cZ,cF,cl,cG,d_,dh,d1,d4,di,d2,cW,d5,d6,dd,cr,d7,d8,cN,d9,de,df,d3,da,d0,co,dg,dc,O,a4,a5,T,W,M,ag,ac,aa,ad,ar,ae,al,a8,aw,av,aJ,ai,aT,aD,aF,aq,ay,aU,aX,aE,aW,bb,aN,b6,bl,bm,aV,bp,bd,bc,bt,bh,bz,bO,by,bg,bu,b4,bv,bq,bw,bP,ce,c1,bV,c_,bR,c7,bS,bZ,bY,c0,bE,bC,bB,bG,cf,cn,bF,c5,c8,y2,w,A,S,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdV:function(){return this.aK},
seY:function(a,b){if(J.a(this.ac,"none")&&!J.a(b,"none")){this.mV(this,b)
this.eA()}else this.mV(this,b)},
h4:[function(a,b){this.mW(this,b)
this.shF(!0)
if(b==null)this.v.jn(J.dc(this.b),J.d1(this.b))},"$1","gfg",2,0,2,9],
k8:[function(a){this.v.jn(J.dc(this.b),J.d1(this.b))},"$0","giv",0,0,0],
X:[function(){this.shF(!1)
this.fU()
this.v.sMK(!0)
this.v.X()
this.v.sul(null)
this.v.saet(null)
this.v.sMK(!1)},"$0","gdu",0,0,0],
iq:[function(){this.shF(!1)
this.fU()},"$0","gkC",0,0,0],
hg:function(){this.x7()
this.shF(!0)},
eA:function(){var z,y
this.Dw()
this.soK(-1)
z=this.v
y=J.h(z)
y.sbK(z,J.q(y.gbK(z),1))},
uG:function(){this.v.jn(J.dc(this.b),J.d1(this.b))},
$isbO:1,
$isbQ:1},
aUT:{"^":"aU+lH;oK:x$?,uj:y$?",$isct:1},
bEN:{"^":"c:54;",
$2:[function(a,b){J.d9(a).stB(U.ap(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bEP:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sbon(U.ap(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bEQ:{"^":"c:54;",
$2:[function(a,b){J.NC(J.d9(a),U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bER:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sMY(U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bES:{"^":"c:54;",
$2:[function(a,b){J.d9(a).saet(R.cZ(b,16777215))},null,null,4,0,null,0,2,"call"]},
bET:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sbe7(U.ah(b,1))},null,null,4,0,null,0,2,"call"]},
bEU:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sul(R.cZ(b,16777215))},null,null,4,0,null,0,2,"call"]},
bEV:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sMS(U.ah(b,1))},null,null,4,0,null,0,2,"call"]},
bEW:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sYs(U.b4(b,-120))},null,null,4,0,null,0,2,"call"]},
bEX:{"^":"c:54;",
$2:[function(a,b){J.Nn(J.d9(a),U.b4(b,120))},null,null,4,0,null,0,2,"call"]},
bEY:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sa0O(U.b4(b,50))},null,null,4,0,null,0,2,"call"]},
bF_:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sa0P(U.b4(b,50))},null,null,4,0,null,0,2,"call"]},
bF0:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sa0Q(U.b4(b,90))},null,null,4,0,null,0,2,"call"]},
bF1:{"^":"c:54;",
$2:[function(a,b){J.d9(a).saeu(U.ah(b,11))},null,null,4,0,null,0,2,"call"]},
bF2:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sbe8(U.kx(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bF3:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sbeJ(U.ah(b,2))},null,null,4,0,null,0,2,"call"]},
bF4:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sbeK(U.kx(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bF5:{"^":"c:54;",
$2:[function(a,b){J.d9(a).sb4u(U.b4(b,null))},null,null,4,0,null,0,2,"call"]},
aw4:{"^":"ati;S,J,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gkc:function(){return this.J},
skc:function(a){var z=this.J
if(z!=null)z.dr(this.gai3())
this.J=a
if(a!=null)a.dM(this.gai3())
if(!this.r)this.bq_(null)},
asn:function(a){if(a!=null){a.h0(V.ie(new V.dR(0,255,0,1),0,0))
a.h0(V.ie(new V.dR(0,0,0,1),0,50))}},
bq_:[function(a){var z,y,x,w,v,u,t,s,r,q
z=this.J
if(z==null){z=new V.eV(!1,null,H.d([],[V.aE]),0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!1,null,null,-1,null,!1,null,!1,null,!1,0,null,null,null,null,null)
z.br()
z.aS(!1,null)
z.ch=null
this.asn(z)}else{y=J.h(z)
x=y.hH(z)
for(w=J.H(x),v=J.q(w.gm(x),1);u=J.G(v),u.dm(v,0);v=u.E(v,1))if(w.h(x,v)==null)y.K(z,v)
if(J.a(J.I(y.hH(z)),0))this.asn(z)}t=J.h3(z)
y=J.b2(t)
y.eO(t,V.rO())
s=[]
if(J.x(y.gm(t),1))for(y=y.gb1(t);y.u();){r=y.gH()
w=J.h(r)
u=w.ghU(r)
q=H.dr(r.i("alpha"))
q.toString
s.push(new D.zO(u,q,J.M(w.gvw(r),100)))}else if(J.a(y.gm(t),1)){r=y.h(t,0)
y=J.h(r)
w=y.ghU(r)
u=H.dr(r.i("alpha"))
u.toString
s.push(new D.zO(w,u,0))
y=y.ghU(r)
u=H.dr(r.i("alpha"))
u.toString
s.push(new D.zO(y,u,1))}this.sakq(s)},"$1","gai3",2,0,6,9],
fv:function(a,b){var z,y,x
if(typeof b==="number"&&Math.floor(b)===b){this.ams(a,b)
return}if(!!J.n(a).$isbl){z=this.S.a
if(!z.V(0,a))z.l(0,a,new N.ce(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
x=V.d5(!1,null)
x.R("fillType",!0).am("gradient")
x.R("gradient",!0).$2(b,!1)
x.R("gradientType",!0).am("linear")
y.kJ(x)
x.X()}},
X:[function(){var z=this.J
if(z!=null&&!J.a(z,$.$get$BI())){this.J.dr(this.gai3())
this.J=null}this.aMf()},"$0","gdu",0,0,0],
aQx:function(){var z=$.$get$BI()
if(J.a(z.x1,0)){z.h0(V.ie(new V.dR(0,255,0,1),1,0))
z.h0(V.ie(new V.dR(255,255,0,1),1,50))
z.h0(V.ie(new V.dR(255,0,0,1),1,100))}},
aj:{
aw5:function(){var z=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.t,N.ce])),[P.t,N.ce])
z=new E.aw4(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cx(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,[P.C,P.aI]])),[P.u,[P.C,P.aI]]))
z.a=z
z.cy=P.iF()
z.aQl()
z.aQx()
return z}}},
HY:{"^":"aUU;aK,fz:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cg,cc,c6,cs,cp,ct,cE,cP,bW,cQ,cv,cB,cH,c3,cq,cu,cw,cL,cC,cM,cI,cT,cU,cJ,cK,cR,cz,cV,cd,cY,bJ,cA,cS,cZ,cF,cl,cG,d_,dh,d1,d4,di,d2,cW,d5,d6,dd,cr,d7,d8,cN,d9,de,df,d3,da,d0,co,dg,dc,O,a4,a5,T,W,M,ag,ac,aa,ad,ar,ae,al,a8,aw,av,aJ,ai,aT,aD,aF,aq,ay,aU,aX,aE,aW,bb,aN,b6,bl,bm,aV,bp,bd,bc,bt,bh,bz,bO,by,bg,bu,b4,bv,bq,bw,bP,ce,c1,bV,c_,bR,c7,bS,bZ,bY,c0,bE,bC,bB,bG,cf,cn,bF,c5,c8,y2,w,A,S,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdV:function(){return this.aK},
seY:function(a,b){if(J.a(this.ac,"none")&&!J.a(b,"none")){this.mV(this,b)
this.eA()}else this.mV(this,b)},
h4:[function(a,b){this.mW(this,b)
this.shF(!0)},"$1","gfg",2,0,2,9],
k8:[function(a){this.uG()},"$0","giv",0,0,0],
X:[function(){this.shF(!1)
this.fU()
this.v.sMK(!0)
this.v.X()
this.v.skc(null)
this.v.sMK(!1)},"$0","gdu",0,0,0],
iq:[function(){this.shF(!1)
this.fU()},"$0","gkC",0,0,0],
hg:function(){this.x7()
this.shF(!0)},
eA:function(){var z,y
this.Dw()
this.soK(-1)
z=this.v
y=J.h(z)
y.sbK(z,J.q(y.gbK(z),1))},
uG:function(){if(this.a instanceof V.v)this.v.jn(J.dc(this.b),J.d1(this.b))},
$isbO:1,
$isbQ:1},
aUU:{"^":"aU+lH;oK:x$?,uj:y$?",$isct:1},
bEb:{"^":"c:86;",
$2:[function(a,b){J.d9(a).stB(U.ap(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bEc:{"^":"c:86;",
$2:[function(a,b){J.NC(J.d9(a),U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bEd:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sMY(U.b4(b,0))},null,null,4,0,null,0,2,"call"]},
bEe:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sblh(U.kx(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bEf:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sblg(U.kx(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bEg:{"^":"c:86;",
$2:[function(a,b){J.d9(a).ska(U.ap(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bEi:{"^":"c:86;",
$2:[function(a,b){var z=J.d9(a)
z.skc(b!=null?V.rN(b):$.$get$BI())},null,null,4,0,null,0,2,"call"]},
bEj:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sYs(U.b4(b,-120))},null,null,4,0,null,0,2,"call"]},
bEk:{"^":"c:86;",
$2:[function(a,b){J.Nn(J.d9(a),U.b4(b,120))},null,null,4,0,null,0,2,"call"]},
bEl:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sa0O(U.b4(b,50))},null,null,4,0,null,0,2,"call"]},
bEm:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sa0P(U.b4(b,50))},null,null,4,0,null,0,2,"call"]},
bEn:{"^":"c:86;",
$2:[function(a,b){J.d9(a).sa0Q(U.b4(b,90))},null,null,4,0,null,0,2,"call"]},
Br:{"^":"t;a3u:a@,jQ:b*,kE:c*"},
asu:{"^":"mF;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,c,d,e,f,r,x,y,z,Q,ch,a,b",
gu4:function(){return this.r1},
su4:function(a){if(!J.a(this.r1,a)){this.r1=a
this.ds()}},
gdq:function(){return this.r2},
sdq:function(a){this.bmz(a)},
glb:function(){return this.go},
jT:function(a,b){var z,y,x,w
this.Kg(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.iF()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.b(a)+"px"
z.width=y
z=this.id.style
y=H.b(b)+"px"
z.height=y
this.fQ(this.k1,0,0,"none")
this.fv(this.k1,this.r2.cE)
z=this.k2
y=this.r2
this.fQ(z,y.cs,J.aR(y.cp),this.r2.ct)
y=this.k3
z=this.r2
this.fQ(y,z.cs,J.aR(z.cp),this.r2.ct)
z=this.db
if(z===2){z=J.x(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a_(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aH(a))
y=this.k1
y.toString
y.setAttribute("height",J.a_(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a_(J.k(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aH(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aH(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.b(this.cy.b)+" L "+H.b(a)+","+H.b(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.b(J.k(this.cy.b,this.r1.b))+" L "+H.b(a)+","+H.b(J.k(this.cy.b,this.r1.b)))}else if(z===1){z=J.x(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a_(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a_(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aH(b))}else{x.toString
x.setAttribute("x",J.a_(J.k(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aH(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aH(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.b(this.cy.a)+",0 L "+H.b(this.cy.a)+","+H.b(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.b(J.k(this.cy.a,this.r1.a))+",0 L "+H.b(J.k(this.cy.a,this.r1.a))+","+H.b(b))}else if(z===3){z=J.x(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a_(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a_(this.r1.a))}else{y.toString
y.setAttribute("x",J.a_(J.k(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aH(0-y))}z=J.x(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a_(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a_(this.r1.b))}else{y.toString
y.setAttribute("y",J.a_(J.k(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aH(0-y))}z=this.k1
y=this.r2
this.fQ(z,y.cs,J.aR(y.cp),this.r2.ct)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
bmz:function(a){var z,y
this.ah_()
this.ah1()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().D(0)
this.r2.rj(0,"CartesianChartZoomerReset",this.gawY())}this.r2=a
if(a!=null){z=this.fx
y=J.cj(a.cx)
y=H.d(new W.A(0,y.a,y.b,W.z(this.gb1V()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.r2.pe(0,"CartesianChartZoomerReset",this.gawY())
if($.$get$hK()===!0){y=this.r2.cx
y.toString
y=H.d(new W.bL(y,"touchstart",!1),[H.r(C.U,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gb1W()),y.c),[H.r(y,0)])
y.t()
z.push(y)}}this.dx=null
this.dy=null},
b20:function(a){var z=J.n(a)
return!!z.$isum||!!z.$isiD||!!z.$isjG},
R9:function(a){return C.a.iB(this.Oo(a),new E.asw(this),V.F0())!=null},
aHv:function(a){var z=J.n(a)
if(!!z.$isjG)return J.aw(a.db)?null:a.db
else if(!!z.$isl0)return a.db
return 0/0},
a55:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isjG){if(b==null)y=null
else{y=J.aV(b)
x=!a.ae
w=new P.ak(y,x)
w.eS(y,x)
y=w}z.sjQ(a,y)}else if(!!z.$isiD)z.sjQ(a,b)
else if(!!z.$isum)z.sjQ(a,b)},
aJG:function(a,b){return this.a55(a,b,!1)},
aHu:function(a){var z=J.n(a)
if(!!z.$isjG)return J.aw(a.cy)?null:a.cy
else if(!!z.$isl0)return a.cy
return 0/0},
a54:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isjG){if(b==null)y=null
else{y=J.aV(b)
x=!a.ae
w=new P.ak(y,x)
w.eS(y,x)
y=w}z.skE(a,y)}else if(!!z.$isiD)z.skE(a,b)
else if(!!z.$isum)z.skE(a,b)},
aJE:function(a,b){return this.a54(a,b,!1)},
aje:function(a,b,a0){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=a===2
if(z){y=this.dy
if(y==null){y=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[D.eJ,E.Br])),[D.eJ,E.Br])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[D.eJ,E.Br])),[D.eJ,E.Br])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.Oo(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.K)(v),++u){t=v[u]
s=x.a
if(!s.V(0,t)){r=J.n(t)
r=!!r.$isum||!!r.$isiD||!!r.$isjG}else r=!1
if(r)s.l(0,t,new E.Br(!1,this.aHv(t),this.aHu(t)))}}y=this.cy
if(z){y=y.b
q=P.aH(y,J.k(y,b))
y=this.cy.b
p=P.aB(y,J.k(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aH(y,J.k(y,b))
y=this.cy.a
m=P.aB(y,J.k(y,b))
o="h"
q=null
p=null}l=[]
k=D.k7(this.r2.a8,!1)
for(y=k.length,s=o==="v",r=!a0,j=null,i=null,h=null,g=null,u=0;u<k.length;k.length===y||(0,H.K)(k),++u){f=k[u]
if(!(f instanceof D.kP))continue
if(f.go!==!0||f.fy!==!0){g=f
continue}h=s?f.al:f.ae
e=J.n(h)
if(!(!!e.$isum||!!e.$isiD||!!e.$isjG)){g=f
continue}if(J.ao(C.a.bn(l,h),0)){g=f
continue}l.push(h)
e=f.cy
if(z){d=F.ba(e,H.d(new P.F(0,0),[null]))
e=J.aR(F.aO(J.ad(f.gdq()),d).b)
if(typeof q!=="number")return q.E()
e=H.d(new P.F(0,q-e),[null])
j=J.p(f.fr.t5([J.q(e.a,C.b.U(f.cy.offsetLeft)),J.q(e.b,C.b.U(f.cy.offsetTop))]),1)
d=F.ba(f.cy,H.d(new P.F(0,0),[null]))
e=J.aR(F.aO(J.ad(f.gdq()),d).b)
if(typeof p!=="number")return p.E()
e=H.d(new P.F(0,p-e),[null])
i=J.p(f.fr.t5([J.q(e.a,C.b.U(f.cy.offsetLeft)),J.q(e.b,C.b.U(f.cy.offsetTop))]),1)}else{d=F.ba(e,H.d(new P.F(0,0),[null]))
e=J.aR(F.aO(J.ad(f.gdq()),d).a)
if(typeof m!=="number")return m.E()
e=H.d(new P.F(m-e,0),[null])
j=J.p(f.fr.t5([J.q(e.a,C.b.U(f.cy.offsetLeft)),J.q(e.b,C.b.U(f.cy.offsetTop))]),0)
d=F.ba(f.cy,H.d(new P.F(0,0),[null]))
e=J.aR(F.aO(J.ad(f.gdq()),d).a)
if(typeof n!=="number")return n.E()
e=H.d(new P.F(n-e,0),[null])
i=J.p(f.fr.t5([J.q(e.a,C.b.U(f.cy.offsetLeft)),J.q(e.b,C.b.U(f.cy.offsetTop))]),0)}if(J.Q(i,j)){c=i
i=j
j=c}this.aJG(h,j)
this.aJE(h,i)
if(this.fr){e=x.a.h(0,h)
e=J.a(e==null?e:e.ga3u(),!0)}else e=!0
if(e){x.a.h(0,h).sa3u(!0)
if(h!=null&&r){e=this.r2
if(z){e.cc=j
e.c6=i
e.aFD()}else{e.c5=j
e.c8=i
e.aEz()}}}this.fr=!0
if(!this.r2.cf)break
g=f}},
aGp:function(a,b){return this.aje(a,b,!1)},
aCK:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.Oo(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.V(0,t)){this.a55(t,J.Yu(w.h(0,t)),!0)
this.a54(t,J.Yt(w.h(0,t)),!0)
if(w.h(0,t).ga3u())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.c5=0/0
x.c8=0/0
x.aEz()}},
ah_:function(){return this.aCK(!1)},
aCO:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.Oo(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.V(0,t)){this.a55(t,J.Yu(w.h(0,t)),!0)
this.a54(t,J.Yt(w.h(0,t)),!0)
if(w.h(0,t).ga3u())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.cc=0/0
x.c6=0/0
x.aFD()}},
ah1:function(){return this.aCO(!1)},
aGq:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.G(a)
if(z.gjP(a)||J.aw(b)){if(this.fr)if(c)this.aCO(!0)
else this.aCK(!0)
return}if(!this.R9(c))return
y=this.Oo(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aHQ(x)
if(w==null)return
v=J.n(b)
if(c){u=J.k(w.LT(["0",z.aH(a)]).b,this.ako(w))
t=J.k(w.LT(["0",v.aH(b)]).b,this.ako(w))
this.cy=H.d(new P.F(50,u),[null])
this.aje(2,J.q(t,u),!0)}else{s=J.k(w.LT([z.aH(a),"0"]).a,this.akn(w))
r=J.k(w.LT([v.aH(b),"0"]).a,this.akn(w))
this.cy=H.d(new P.F(s,50),[null])
this.aje(1,J.q(r,s),!0)}},
Oo:function(a){var z,y,x,w,v,u,t
z=[]
y=D.k7(this.r2.a8,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.K)(y),++v){u=y[v]
if(!(u instanceof D.kP))continue
if(a){t=u.al
if(t!=null&&J.Q(C.a.bn(z,t),0))z.push(u.al)}else{t=u.ae
if(t!=null&&J.Q(C.a.bn(z,t),0))z.push(u.ae)}w=u}return z},
aHQ:function(a){var z,y,x,w,v
z=D.k7(this.r2.a8,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.K)(z),++w){v=z[w]
if(!(v instanceof D.kP))continue
if(J.a(v.al,a)||J.a(v.ae,a))return v
x=v}return},
akn:function(a){var z=F.ba(a.cy,H.d(new P.F(0,0),[null]))
return J.aR(F.aO(J.ad(a.gdq()),z).a)},
ako:function(a){var z=F.ba(a.cy,H.d(new P.F(0,0),[null]))
return J.aR(F.aO(J.ad(a.gdq()),z).b)},
fQ:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.V(0,a))z.h(0,a).kT(null)
R.qW(a,b,c,d)
return}if(!!J.n(a).$isbl){z=this.k4.a
if(!z.V(0,a))z.l(0,a,new N.ce(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kT(b)
y.smw(c)
y.sma(d)}},
fv:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.V(0,a))z.h(0,a).kJ(null)
R.vX(a,b)
return}if(!!J.n(a).$isbl){z=this.k4.a
if(!z.V(0,a))z.l(0,a,new N.ce(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kJ(b)}},
aVk:function(a){var z,y,x,w
for(z=a.length,y=this.rx,x=0;x<a.length;a.length===z||(0,H.K)(a),++x){w=a[x]
if(y.B(0,w.identifier))return w}return},
aVl:function(a){var z,y,x,w
z=this.rx
z.dR(0)
for(y=a.length,x=0;w=a.length,x<w;a.length===y||(0,H.K)(a),++x)z.n(0,a[x].identifier)
if(0>=w)return H.e(a,0)
return a[0]},
bxm:[function(a){var z,y
if($.$get$hK()===!0){z=Date.now()
y=$.nB
if(typeof y!=="number")return H.l(y)
y=z-y<1000
z=y}else z=!1
if(z)return
this.aBz(J.cl(a))},"$1","gb1V",2,0,4,4],
bxn:[function(a){var z=this.aVl(J.N_(a))
$.nB=Date.now()
this.aBz(H.d(new P.F(C.b.U(z.pageX),C.b.U(z.pageY)),[null]))},"$1","gb1W",2,0,5,4],
aBz:function(a){var z,y
z=this.r2
if(!z.cn&&!z.cg)return
z.cx.appendChild(this.go)
z=this.r2
this.jn(z.Q,z.ch)
this.cy=F.aO(this.go,a)
this.cx=!0
z=this.fy
y=H.d(new W.aC(document,"mousemove",!1),[H.r(C.z,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaIc()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.aC(document,"mouseup",!1),[H.r(C.A,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaId()),y.c),[H.r(y,0)])
y.t()
z.push(y)
if($.$get$hK()===!0){y=H.d(new W.aC(document,"touchmove",!1),[H.r(C.aw,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaIf()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.aC(document,"touchend",!1),[H.r(C.ad,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaIe()),y.c),[H.r(y,0)])
y.t()
z.push(y)}y=H.d(new W.aC(document,"keydown",!1),[H.r(C.a5,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gEC()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.db=0
this.su4(null)},
bt0:[function(a){this.aBA(J.cl(a))},"$1","gaIc",2,0,4,4],
bt3:[function(a){var z=this.aVk(J.N_(a))
if(z!=null)this.aBA(J.cl(z))},"$1","gaIf",2,0,5,4],
aBA:function(a){var z,y
z=F.aO(this.go,a)
if(this.db===0)if(this.r2.bF){if(!(this.R9(!0)&&this.R9(!1))){this.LF()
return}if(J.ao(J.aW(J.q(z.a,this.cy.a)),2)&&J.ao(J.aW(J.q(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.x(J.aW(J.q(z.b,this.cy.b)),J.aW(J.q(z.a,this.cy.a)))){if(this.R9(!0))this.db=2
else{this.LF()
return}y=2}else{if(this.R9(!1))this.db=1
else{this.LF()
return}y=1}if(y===1)if(!this.r2.cn){this.LF()
return}if(y===2)if(!this.r2.cg){this.LF()
return}}y=this.r2
if(P.bp(0,0,y.Q,y.ch,null).pE(0,z)){y=this.db
if(y===2)this.su4(H.d(new P.F(0,J.q(z.b,this.cy.b)),[null]))
else if(y===1)this.su4(H.d(new P.F(J.q(z.a,this.cy.a),0),[null]))
else if(y===3)this.su4(H.d(new P.F(J.q(z.a,this.cy.a),J.q(z.b,this.cy.b)),[null]))
else this.su4(null)}},
bt1:[function(a){this.aBB()},"$1","gaId",2,0,4,4],
bt2:[function(a){this.aBB()},"$1","gaIe",2,0,5,4],
aBB:function(){var z,y
for(z=this.fy;z.length>0;)z.pop().D(0)
J.a0(this.go)
this.cx=!1
this.ds()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.aGp(2,z.b)
z=this.db
if(z===1||z===3)this.aGp(1,this.r1.a)}else{this.ah_()
V.W(new E.asy(this))}},
acE:[function(a){if(F.d_(a)===27)this.LF()},"$1","gEC",2,0,7,4],
LF:function(){for(var z=this.fy;z.length>0;)z.pop().D(0)
J.a0(this.go)
this.cx=!1
this.ds()},
bAc:[function(a){this.ah_()
V.W(new E.asx(this))},"$1","gawY",2,0,8,4],
aQi:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.w(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
aj:{
asv:function(){var z,y
z=H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.t,N.ce])),[P.t,N.ce])
y=P.a9(null,null,null,P.O)
z=new E.asu(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,y,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a1(0,null,null,null,null,null,0),[P.u,[P.C,P.aI]])),[P.u,[P.C,P.aI]]))
z.a=z
z.aQi()
return z}}},
asw:{"^":"c:0;a",
$1:function(a){return this.a.b20(a)}},
asy:{"^":"c:3;a",
$0:[function(){this.a.ah1()},null,null,0,0,null,"call"]},
asx:{"^":"c:3;a",
$0:[function(){this.a.ah1()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.b8,args:[V.v,P.u,P.b8]},{func:1,v:true,args:[[P.a3,P.u]]},{func:1,ret:F.bO},{func:1,v:true,args:[W.cG]},{func:1,v:true,args:[W.iT]},{func:1,v:true,args:[P.t]},{func:1,v:true,args:[W.hy]},{func:1,v:true,args:[N.cz]},{func:1,ret:P.u,args:[D.mb]}]
init.types.push.apply(init.types,deferredTypes)
$.WP=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["a52","$get$a52",function(){return P.m(["scaleType",new E.bEo(),"offsetLeft",new E.bEp(),"offsetRight",new E.bEq(),"minimum",new E.bEr(),"maximum",new E.bEt(),"formatString",new E.bEu(),"showMinMaxOnly",new E.bEv(),"percentTextSize",new E.bEw(),"labelsColor",new E.bEx(),"labelsFontFamily",new E.bEy(),"labelsFontStyle",new E.bEz(),"labelsFontWeight",new E.bEA(),"labelsTextDecoration",new E.bEB(),"labelsLetterSpacing",new E.bEC(),"labelsRotation",new E.bEE(),"labelsAlign",new E.bEF(),"angleFrom",new E.bEG(),"angleTo",new E.bEH(),"percentOriginX",new E.bEI(),"percentOriginY",new E.bEJ(),"percentRadius",new E.bEK(),"majorTicksCount",new E.bEL(),"justify",new E.bEM()])},$,"a53","$get$a53",function(){var z=P.U()
z.p(0,N.em())
z.p(0,$.$get$a52())
return z},$,"a54","$get$a54",function(){return P.m(["scaleType",new E.bEN(),"ticksPlacement",new E.bEP(),"offsetLeft",new E.bEQ(),"offsetRight",new E.bER(),"majorTickStroke",new E.bES(),"majorTickStrokeWidth",new E.bET(),"minorTickStroke",new E.bEU(),"minorTickStrokeWidth",new E.bEV(),"angleFrom",new E.bEW(),"angleTo",new E.bEX(),"percentOriginX",new E.bEY(),"percentOriginY",new E.bF_(),"percentRadius",new E.bF0(),"majorTicksCount",new E.bF1(),"majorTicksPercentLength",new E.bF2(),"minorTicksCount",new E.bF3(),"minorTicksPercentLength",new E.bF4(),"cutOffAngle",new E.bF5()])},$,"a55","$get$a55",function(){var z=P.U()
z.p(0,N.em())
z.p(0,$.$get$a54())
return z},$,"a56","$get$a56",function(){return P.m(["scaleType",new E.bEb(),"offsetLeft",new E.bEc(),"offsetRight",new E.bEd(),"percentStartThickness",new E.bEe(),"percentEndThickness",new E.bEf(),"placement",new E.bEg(),"gradient",new E.bEi(),"angleFrom",new E.bEj(),"angleTo",new E.bEk(),"percentOriginX",new E.bEl(),"percentOriginY",new E.bEm(),"percentRadius",new E.bEn()])},$,"a57","$get$a57",function(){var z=P.U()
z.p(0,N.em())
z.p(0,$.$get$a56())
return z},$])}
$dart_deferred_initializers$["HLnsC7FmctTZEckhUH4JmFBPvfw="]=$dart_deferred_initializers$.current

//# sourceMappingURL=main.dart.js_2.part.js.map
