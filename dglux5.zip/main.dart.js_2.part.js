self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,N,{"^":"",
aIh:function(){var z=document
z=z.createElement("div")
z=new N.G6(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.pw()
z.adI()
return z},
akP:{"^":"Kh;",
sqQ:["axp",function(a){if(!J.a(this.k4,a)){this.k4=a
this.d1()}}],
sHw:function(a){if(!J.a(this.r1,a)){this.r1=a
this.d1()}},
sHx:function(a){if(!J.a(this.rx,a)){this.rx=a
this.d1()}},
sHy:function(a){if(!J.a(this.ry,a)){this.ry=a
this.d1()}},
sHA:function(a){if(!J.a(this.x1,a)){this.x1=a
this.d1()}},
sHz:function(a){if(!J.a(this.x2,a)){this.x2=a
this.d1()}},
saV6:function(a){if(!J.a(this.y1,a)){if(J.y(a,180))a=180
this.y1=J.S(a,-180)?-180:a
this.d1()}},
saV5:function(a){if(J.a(this.y2,a))return
this.y2=a
this.d1()},
giL:function(a){return this.F},
siL:function(a,b){if(b==null)b=0
if(!J.a(this.F,b)){this.F=b
this.d1()}},
gjl:function(a){return this.v},
sjl:function(a,b){if(b==null)b=100
if(!J.a(this.v,b)){this.v=b
this.d1()}},
sb0Y:function(a){if(this.L!==a){this.L=a
this.d1()}},
gv5:function(a){return this.R},
sv5:function(a,b){if(b==null||J.S(b,0))b=0
if(J.y(b,4))b=4
if(!J.a(this.R,b)){this.R=b
this.d1()}},
savN:function(a){if(this.W!==a){this.W=a
this.d1()}},
swe:function(a){this.X=a
this.d1()},
gqi:function(){return this.D},
sqi:function(a){if(!J.a(this.D,a)){this.D=a
this.d1()}},
saUW:function(a){if(!J.a(this.Z,a)){this.Z=a
this.d1()}},
gtZ:function(a){return this.U},
stZ:["acw",function(a,b){if(!J.a(this.U,b))this.U=b}],
sHT:["acx",function(a){if(!J.a(this.ar,a))this.ar=a}],
sa5A:function(a){this.acz(a)
this.d1()},
iV:function(a,b){this.FH(a,b)
this.Oe()
if(J.a(this.D,"circular"))this.b17(a,b)
else this.b18(a,b)},
Oe:function(){var z,y,x,w,v
z=this.W
y=this.k2
if(z){y.se_(0,2)
z=this.k2.f
if(0>=z.length)return H.e(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isd8)z.sc6(x,this.a2H(this.F,this.R))
J.a3(J.b6(x.gaT()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.e(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isd8)z.sc6(x,this.a2H(this.v,this.R))
J.a3(J.b6(x.gaT()),"text-decoration",this.x1)}else{y.se_(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.e(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isd8){y=this.F
w=J.k(y,J.D(J.M(J.o(this.v,y),J.o(this.fy,1)),v))
z.sc6(x,this.a2H(w,this.R))}J.a3(J.b6(x.gaT()),"text-decoration",this.x1);++v}}this.eO(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.b(this.x2)+"px")},
b17:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.M(J.o(this.fr,this.dy),z-1)
x=P.ax(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.M(a,2)
x=P.ax(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.o(w,x*(50-u)/100)
u=J.M(b,2)
x=P.ax(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.o(u,x*(50-w)/100)
r=C.c.M(this.L,"%")&&!0
x=this.L
if(r){H.ca("")
x=H.dG(x,"%","")}q=P.dF(x,null)
for(x=J.aw(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.e(w,p)
o=w[p]
w=J.k(J.o(this.dy,90),x.bl(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.Js(o)
w=m.b
u=J.E(w)
if(u.bJ(w,0)){if(r){l=P.ax(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.M(l,w)}else k=0
l=m.a
j=J.aw(l)
i=J.k(j.bl(l,l),u.bl(w,w))
if(typeof i!=="number")H.ac(H.bB(i))
i=Math.sqrt(i)
h=J.D(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.Z){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.D(j.dh(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.D(u.dh(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a3(J.b6(o.gaT()),"transform","")
i=J.n(o)
if(!!i.$iscK)i.iM(o,d,c)
else E.eB(o.gaT(),d,c)
i=J.b6(o.gaT())
h=J.J(i)
h.l(i,"transform",J.k(h.h(i,"transform")," scale ("+H.b(k)+")"))
if(!J.a(this.y1,0))if(!!J.n(o.gaT()).$ismI){i=J.b6(o.gaT())
h=J.J(i)
h.l(i,"transform",J.k(h.h(i,"transform")," rotate("+H.b(this.y1)+" "+H.b(j.dh(l,2))+" "+H.b(J.M(u.f6(w),2))+")"))}else{J.je(J.I(o.gaT())," rotate("+H.b(this.y1)+"deg)")
J.lu(J.I(o.gaT()),H.b(J.D(j.dh(l,2),k))+" "+H.b(J.D(u.dh(w,2),k)))}}},
b18:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.M(J.o(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.e(x,0)
w=this.Js(x[0])
v=C.c.M(this.L,"%")&&!0
x=this.L
if(v){H.ca("")
x=H.dG(x,"%","")}u=P.dF(x,null)
x=w.b
t=J.E(x)
if(t.bJ(x,0))s=J.M(v?J.M(J.D(a,u),200):u,x)
else s=0
r=J.M(J.D(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ab(r)))
p=Math.abs(Math.sin(H.ab(r)))
this.acw(this,J.D(J.M(J.k(J.D(w.a,q),t.bl(x,p)),2),s))
this.Wv()
x=this.k2.f
if(y<0||y>=x.length)return H.e(x,y)
w=this.Js(x[y])
x=w.b
t=J.E(x)
if(t.bJ(x,0))s=J.M(v?J.M(J.D(a,u),200):u,x)
else s=0
this.acx(J.D(J.M(J.k(J.D(w.a,q),t.bl(x,p)),2),s))
this.Wv()
if(!J.a(this.y1,0)){for(x=J.aw(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.e(t,n)
w=this.Js(t[n])
t=w.b
m=J.E(t)
if(m.bJ(t,0))J.M(v?J.M(x.bl(a,u),200):u,t)
o=P.aA(J.k(J.D(w.a,p),m.bl(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.E(a)
k=J.M(J.o(x.A(a,this.U),this.ar),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.e(y,n)
j=y[n]
y=this.U
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.k(y,t)
w=this.Js(j)
y=w.b
m=J.E(y)
if(m.bJ(y,0))s=J.M(v?J.M(x.bl(a,u),200):u,y)
else s=0
h=w.a
g=J.E(h)
i=J.o(i,J.D(g.dh(h,2),s))
J.a3(J.b6(j.gaT()),"transform","")
if(J.a(this.y1,0)){y=J.D(J.k(g.bl(h,p),m.bl(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$iscK)y.iM(j,i,f)
else E.eB(j.gaT(),i,f)
y=J.b6(j.gaT())
t=J.J(y)
t.l(y,"transform",J.k(t.h(y,"transform")," scale ("+H.b(s)+")"))}else{i=J.o(J.k(this.U,t),g.dh(h,2))
t=J.k(g.bl(h,p),m.bl(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$iscK)t.iM(j,i,e)
else E.eB(j.gaT(),i,e)
d=g.dh(h,2)
c=-y/2
y=J.b6(j.gaT())
t=J.J(y)
m=s-1
t.l(y,"transform",J.k(t.h(y,"transform")," translate("+H.b(J.D(J.bG(d),m))+" "+H.b(-c*m)+")"))
m=J.b6(j.gaT())
y=J.J(m)
y.l(m,"transform",J.k(y.h(m,"transform")," scale ("+H.b(s)+")"))
m=J.b6(j.gaT())
y=J.J(m)
y.l(m,"transform",J.k(y.h(m,"transform")," rotate("+H.b(this.y1)+" "+H.b(d)+" "+H.b(c)+")"))}}},
Js:function(a){var z,y,x,w
if(!!J.n(a.gaT()).$isep){z=H.j(a.gaT(),"$isep").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.bl()
w=x*0.7}else{y=J.d1(a.gaT())
y.toString
w=J.cV(a.gaT())
w.toString}return H.d(new P.F(y,w),[null])},
a2P:[function(){return N.D5()},"$0","guH",0,0,3],
a2H:function(a,b){var z=this.X
if(z==null||J.a(z,""))return U.oI(a,"0")
else return U.oI(a,this.X)},
a7:[function(){this.acz(0)
this.d1()
var z=this.k2
z.d=!0
z.r=!0
z.se_(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gdc",0,0,0],
aB5:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.x(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new N.nn(this.guH(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
Kh:{"^":"lD;",
gZu:function(){return this.cy},
sUJ:["axt",function(a){if(a==null)a=50
if(J.S(a,0))a=0
if(J.y(a,100))a=100
if(!J.a(this.db,a)){this.db=a
this.d1()}}],
sUK:["axu",function(a){if(a==null)a=50
if(J.S(a,0))a=0
if(J.y(a,100))a=100
if(!J.a(this.dx,a)){this.dx=a
this.d1()}}],
sRu:["axq",function(a){if(J.S(a,-360))a=-360
if(J.y(a,360))a=360
if(!J.a(this.dy,a)){this.dy=a
this.e0()
this.d1()}}],
sahI:["axr",function(a,b){if(J.S(b,-360))b=-360
if(J.y(b,360))b=360
if(!J.a(this.fr,b)){this.fr=b
this.e0()
this.d1()}}],
saWw:function(a){if(a==null||J.S(a,0))a=0
if(J.y(a,20))a=20
if(!J.a(this.fx,a)){this.fx=a
this.d1()}},
sa5A:["acz",function(a){if(a==null||J.S(a,2))a=2
if(J.y(a,30))a=30
if(!J.a(this.fy,a)){this.fy=a
this.d1()}}],
saWx:function(a){if(this.go!==a){this.go=a
this.d1()}},
saW3:function(a){if(this.id!==a){this.id=a
this.d1()}},
sUL:["axv",function(a){if(a==null||J.S(a,0))a=0
if(J.y(a,200))a=200
if(!J.a(this.k1,a)){this.k1=a
this.d1()}}],
gka:function(){return this.cy},
f8:["axs",function(a,b,c,d){R.p6(a,b,c,d)}],
eO:["acy",function(a,b){R.tR(a,b)}],
A9:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.h(a)
if(y!=="")J.a3(z.gf4(a),"d",y)
else J.a3(z.gf4(a),"d","M 0,0")}},
akQ:{"^":"Kh;",
sa5z:["axw",function(a){if(!J.a(this.k4,a)){this.k4=a
this.d1()}}],
saW2:function(a){if(!J.a(this.r2,a)){this.r2=a
this.d1()}},
sqS:["axx",function(a){if(!J.a(this.rx,a)){this.rx=a
this.d1()}}],
sHO:function(a){if(!J.a(this.x1,a)){this.x1=a
this.d1()}},
gqi:function(){return this.x2},
sqi:function(a){if(!J.a(this.x2,a)){this.x2=a
this.d1()}},
gtZ:function(a){return this.y1},
stZ:function(a,b){if(!J.a(this.y1,b)){this.y1=b
this.d1()}},
sHT:function(a){if(!J.a(this.y2,a)){this.y2=a
this.d1()}},
sb39:function(a){if(!J.a(this.K,a)){this.K=a
this.d1()}},
saO0:function(a){var z
if(!J.a(this.F,a)){this.F=a
if(a!=null){z=J.o(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.v=z
this.d1()}},
iV:function(a,b){var z,y
this.FH(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.f8(this.k2,this.k4,J.aL(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.f8(this.k3,this.rx,J.aL(this.x1),this.ry)
if(J.a(this.x2,"circular"))this.aPV(a,b)
else this.aPW(a,b)},
aPV:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.M(J.o(this.fr,this.dy),J.o(J.k(J.D(this.fx,J.o(this.fy,1)),this.fy),1))
x=C.c.M(this.go,"%")&&!0
w=this.go
if(x){H.ca("")
w=H.dG(w,"%","")}v=P.dF(w,null)
if(x){w=P.ax(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.ax(a,b)
w=J.M(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.o(w,t*(50-s)/100)
s=J.M(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.o(s,t*(50-w)/100)
w=P.ax(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.a(this.K,"center"))o=0.5
else o=J.a(this.K,"outside")?1:0
w=o-1
s=J.aw(y)
n=0
while(!0){m=J.k(J.D(this.fx,J.o(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.k(J.o(this.dy,90),s.bl(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++n}this.A9(this.k3)
z.a=""
y=J.M(J.o(this.fr,this.dy),J.o(this.fy,1))
h=C.c.M(this.id,"%")&&!0
s=this.id
if(h){H.ca("")
s=H.dG(s,"%","")}g=P.dF(s,null)
if(h){s=P.ax(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.aw(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.k(J.o(this.dy,90),s.bl(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++f}this.A9(this.k2)},
aPW:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.M(this.go,"%")&&!0
y=this.go
if(z){H.ca("")
y=H.dG(y,"%","")}x=P.dF(y,null)
w=z?J.M(J.D(J.M(a,2),x),100):x
v=C.c.M(this.id,"%")&&!0
y=this.id
if(v){H.ca("")
y=H.dG(y,"%","")}u=P.dF(y,null)
t=v?J.M(J.D(J.M(a,2),u),100):u
y=this.cx
y.a=""
s=J.E(a)
r=J.M(J.o(s.A(a,this.y1),this.y2),J.o(J.k(J.D(this.fx,J.o(this.fy,1)),this.fy),1))
if(J.a(this.K,"center"))q=0.5
else q=J.a(this.K,"outside")?1:0
p=J.E(t)
o=p.A(t,w)
n=1-q
m=0
while(!0){l=J.k(J.D(this.fx,J.o(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.A(t,q*o)
y.a+="M "+H.b(k)+","+H.b(n*o)+" "
y.a+="L "+H.b(k)+","+H.b(j)+" ";++m}this.A9(this.k3)
y.a=""
r=J.M(J.o(s.A(a,this.y1),this.y2),J.o(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.b(k)+",0 "
y.a+="L "+H.b(k)+","+H.b(t)+" ";++i}this.A9(this.k2)},
a7:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.A9(z)
this.A9(this.k3)}},"$0","gdc",0,0,0]},
akR:{"^":"Kh;",
sUJ:function(a){this.axt(a)
this.r2=!0},
sUK:function(a){this.axu(a)
this.r2=!0},
sRu:function(a){this.axq(a)
this.r2=!0},
sahI:function(a,b){this.axr(this,b)
this.r2=!0},
sUL:function(a){this.axv(a)
this.r2=!0},
sb0X:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.d1()}},
sb0W:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.d1()}},
saaW:function(a){if(this.x2!==a){this.x2=a
this.e0()
this.d1()}},
gjn:function(){return this.y1},
sjn:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.a(this.y1,a)){this.y1=a
this.r2=!0
this.d1()}},
gqi:function(){return this.y2},
sqi:function(a){if(!J.a(this.y2,a)){this.y2=a
this.r2=!0
this.d1()}},
gtZ:function(a){return this.K},
stZ:function(a,b){if(!J.a(this.K,b)){this.K=b
this.r2=!0
this.d1()}},
sHT:function(a){if(!J.a(this.F,a)){this.F=a
this.r2=!0
this.d1()}},
jt:function(a){var z,y,x,w,v,u,t,s,r
this.zI(this)
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.K)(z),++u){t=z[u]
s=J.h(t)
y.push(s.ghk(t))
x.push(s.gCV(t))
w.push(s.gu5(t))}if(J.cJ(J.o(this.dy,this.fr))===!0){z=J.ba(J.o(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.i.G(0.5*z)}else r=0
this.k2=this.aMX(y,w,r)
this.k3=this.aKu(x,w,r)
this.r2=!0},
iV:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.FH(a,b)
z=J.aw(a)
y=J.aw(b)
E.FZ(this.k4,z.bl(a,1),y.bl(b,1))
if(J.a(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.ax(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.a(this.y2,"circular")){z=P.aA(0,P.ax(a,b))
this.rx=z
this.aPY(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.b(this.rx)+" "+H.b(this.rx))}else{z=J.D(J.o(z.A(a,this.K),this.F),1)
y.bl(b,1)
v=C.c.M(this.ry,"%")&&!0
y=this.ry
if(v){H.ca("")
y=H.dG(y,"%","")}u=P.dF(y,null)
t=v?J.M(J.D(z,u),100):u
s=C.c.M(this.x1,"%")&&!0
y=this.x1
if(s){H.ca("")
y=H.dG(y,"%","")}r=P.dF(y,null)
q=s?J.M(J.D(z,r),100):r
this.r1.se_(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.o(q,t)
p=q
o=p
m=0
break
case"cross":y=J.E(q)
x=J.E(t)
o=J.k(y.dh(q,2),x.dh(t,2))
n=J.o(y.dh(q,2),x.dh(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.d(new P.F(this.K,o),[null])
k=H.d(new P.F(this.K,n),[null])
j=H.d(new P.F(J.k(this.K,z),p),[null])
i=H.d(new P.F(J.k(this.K,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.e(y,0)
h=y[0]
this.eO(h.gaT(),this.L)
R.p6(h.gaT(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.b(y)+","+H.b(x)+" "
z.a+="L "+H.b(j.a)+","+H.b(j.b)+" "
z.a+="L "+H.b(i.a)+","+H.b(i.b)+" "
z.a+="L "+H.b(k.a)+","+H.b(k.b)+" "
z.a+="L "+H.b(y)+","+H.b(x)+" "
this.A9(h.gaT())
x=this.cy
x.toString
new W.di(x).P(0,"viewBox")}},
aMX:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.kp(J.D(J.o(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.e(a,y)
t=J.V(J.bT(a[y],16),255)
if(y>=a.length)return H.e(a,y)
s=J.V(J.bT(a[y],8),255)
if(y>=a.length)return H.e(a,y)
r=J.V(a[y],255)
if(x>=a.length)return H.e(a,x)
q=J.V(J.bT(a[x],16),255)
if(x>=a.length)return H.e(a,x)
p=J.V(J.bT(a[x],8),255)
if(x>=a.length)return H.e(a,x)
o=J.V(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.G(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.G(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.G(w*r+m*o)&255)>>>0)}}return z},
aKu:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.kp(J.D(J.o(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.e(a,x)
v=a[x]
if(y>=w)return H.e(a,y)
t=J.M(J.o(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.e(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.k(w,s*t))}}return z},
aPY:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.ax(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.M(this.ry,"%")&&!0
z=this.ry
if(v){H.ca("")
z=H.dG(z,"%","")}u=P.dF(z,new N.akS())
if(v){z=P.ax(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.M(this.x1,"%")&&!0
z=this.x1
if(s){H.ca("")
z=H.dG(z,"%","")}r=P.dF(z,new N.akT())
if(s){z=P.ax(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.ax(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.ax(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.se_(0,w)
for(z=J.E(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.o(this.dy,90)
d=J.o(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.k(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.A(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.e(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.e(e,d)
g=J.aN(J.D(e[d],255))
g=J.b1(J.a(g,0)?1:g,24)
e=h.gaT()
a3=this.k2
if(d>=a3.length)return H.e(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.eO(e,a3+g)
a3=h.gaT()
e=this.k2
if(d>=e.length)return H.e(e,d)
R.p6(a3,e[d]+g,1,"solid")
y.a+="M "+H.b(l)+","+H.b(k)+" "
y.a+="L "+H.b(a)+","+H.b(a0)+" "
y.a+="L "+H.b(a1)+","+H.b(a2)+" "
y.a+="L "+H.b(j)+","+H.b(i)+" "
y.a+="L "+H.b(l)+","+H.b(k)+" "
this.A9(h.gaT())}}},
bhk:[function(){var z,y
z=new N.a6x(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gb0N",0,0,3],
a7:["axy",function(){var z=this.r1
z.d=!0
z.r=!0
z.se_(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gdc",0,0,0],
aB6:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.saaW([new N.xo(65280,0.5,0),new N.xo(16776960,0.8,0.5),new N.xo(16711680,1,1)])
z=new N.nn(this.gb0N(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
akS:{"^":"c:0;",
$1:function(a){return 0}},
akT:{"^":"c:0;",
$1:function(a){return 0}},
xo:{"^":"t;hk:a*,CV:b>,u5:c>"}}],["","",,L,{"^":"",
bK9:[function(a){var z=!!J.n(a.glL().gaT()).$isfW?H.j(a.glL().gaT(),"$isfW"):null
if(z!=null)if(z.got()!=null&&!J.a(z.got(),""))return L.V6(a.glL(),z.got())
else return z.Hb(a)
return""},"$1","bBx",2,0,8,55],
byE:function(){if($.Ru)return
$.Ru=!0
$.$get$hG().l(0,"percentTextSize",L.bBA())
$.$get$hG().l(0,"minorTicksPercentLength",L.adX())
$.$get$hG().l(0,"majorTicksPercentLength",L.adX())
$.$get$hG().l(0,"percentStartThickness",L.adZ())
$.$get$hG().l(0,"percentEndThickness",L.adZ())
$.$get$hH().l(0,"percentTextSize",L.bBB())
$.$get$hH().l(0,"minorTicksPercentLength",L.adY())
$.$get$hH().l(0,"majorTicksPercentLength",L.adY())
$.$get$hH().l(0,"percentStartThickness",L.ae_())
$.$get$hH().l(0,"percentEndThickness",L.ae_())},
b4u:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Dl())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Eq())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Eo())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Mn())
return z
case"linearAxis":return $.$get$wh()
case"logAxis":return $.$get$wk()
case"categoryAxis":return $.$get$tD()
case"datetimeAxis":return $.$get$w4()
case"axisRenderer":return $.$get$ty()
case"radialAxisRenderer":return $.$get$Mg()
case"angularAxisRenderer":return $.$get$Kt()
case"linearAxisRenderer":return $.$get$ty()
case"logAxisRenderer":return $.$get$ty()
case"categoryAxisRenderer":return $.$get$ty()
case"datetimeAxisRenderer":return $.$get$ty()
case"lineSeries":return $.$get$wf()
case"areaSeries":return $.$get$D1()
case"columnSeries":return $.$get$Do()
case"barSeries":return $.$get$D9()
case"bubbleSeries":return $.$get$Dg()
case"pieSeries":return $.$get$zg()
case"spectrumSeries":return $.$get$MC()
case"radarSeries":return $.$get$zk()
case"lineSet":return $.$get$qG()
case"areaSet":return $.$get$D3()
case"columnSet":return $.$get$Dq()
case"barSet":return $.$get$Db()
case"gridlines":return $.$get$Lp()}return[]},
b4s:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof L.o3)return a
else{z=$.$get$Wu()
y=H.d([],[N.eE])
x=H.d([],[E.jr])
w=H.d([],[L.iP])
v=H.d([],[E.jr])
u=H.d([],[L.iP])
t=H.d([],[E.jr])
s=H.d([],[L.yO])
r=H.d([],[E.jr])
q=H.d([],[L.zl])
p=H.d([],[E.jr])
o=$.$get$am()
n=$.Q+1
$.Q=n
n=new L.o3(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
n.c5(b,"chart")
J.U(J.x(n.b),"absolute")
o=L.an_()
n.w=o
J.bw(n.b,o.cx)
o=n.w
o.bq=n
o.OG()
o=L.ak6()
n.V=o
o.sd2(n.w)
return n}case"scaleTicks":if(a instanceof L.Ep)return a
else{z=$.$get$ZI()
y=$.$get$am()
x=$.Q+1
$.Q=x
x=new L.Ep(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c5(b,"scale-ticks")
J.U(J.x(x.b),"absolute")
z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.and(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cl(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.cy=P.hK()
x.w=z
J.bw(x.b,z.gZu())
return x}case"scaleLabels":if(a instanceof L.En)return a
else{z=$.$get$ZG()
y=$.$get$am()
x=$.Q+1
$.Q=x
x=new L.En(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c5(b,"scale-labels")
J.U(J.x(x.b),"absolute")
z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.anb(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cl(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.cy=P.hK()
z.aB5()
x.w=z
J.bw(x.b,z.gZu())
x.w.se7(x)
return x}case"scaleTrack":if(a instanceof L.Er)return a
else{z=$.$get$ZK()
y=$.$get$am()
x=$.Q+1
$.Q=x
x=new L.Er(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c5(b,"scale-track")
J.U(J.x(x.b),"absolute")
J.ma(J.I(x.b),"hidden")
y=L.anf()
x.w=y
J.bw(x.b,y.gZu())
return x}}return},
bKF:[function(){var z=new L.aon(null,null,null)
z.adw()
return z},"$0","bBy",0,0,3],
an_:function(){var z,y,x,w,v,u,t
z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
y=P.bd(0,0,0,0,null)
x=P.bd(0,0,0,0,null)
w=new N.cG(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.d([],[P.fn])
t=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,P.t])),[P.u,P.t])
z=new L.o2(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",N.bBb(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.aB3("chartBase")
z.aB1()
z.aBO()
z.sSC("single")
z.aBf()
return z},
bRe:[function(a,b,c){return L.b3c(a,c)},"$3","bBA",6,0,1,16,28,1],
b3c:function(a,b){var z,y,x
z=a.C("view")
if(z==null)return
y=z.gdt()
if(y==null)return
x=J.h(y)
return J.M(J.D(J.a(y.gqi(),"circular")?P.ax(x.gbw(y),x.gbX(y)):x.gbw(y),b),200)},
bRf:[function(a,b,c){return L.b3d(a,c)},"$3","bBB",6,0,1,16,28,1],
b3d:function(a,b){var z,y,x,w
z=a.C("view")
if(z==null)return
y=z.gdt()
if(y==null)return
x=J.D(b,200)
w=J.h(y)
return J.M(x,J.a(y.gqi(),"circular")?P.ax(w.gbw(y),w.gbX(y)):w.gbw(y))},
bRg:[function(a,b,c){return L.b3e(a,c)},"$3","adX",6,0,1,16,28,1],
b3e:function(a,b){var z,y,x
z=a.C("view")
if(z==null)return
y=z.gdt()
if(y==null)return
x=J.h(y)
return J.M(J.D(J.a(y.gqi(),"circular")?P.ax(x.gbw(y),x.gbX(y)):x.gbw(y),b),200)},
bRh:[function(a,b,c){return L.b3f(a,c)},"$3","adY",6,0,1,16,28,1],
b3f:function(a,b){var z,y,x,w
z=a.C("view")
if(z==null)return
y=z.gdt()
if(y==null)return
x=J.D(b,200)
w=J.h(y)
return J.M(x,J.a(y.gqi(),"circular")?P.ax(w.gbw(y),w.gbX(y)):w.gbw(y))},
bRi:[function(a,b,c){return L.b3g(a,c)},"$3","adZ",6,0,1,16,28,1],
b3g:function(a,b){var z,y,x
z=a.C("view")
if(z==null)return
y=z.gdt()
if(y==null)return
x=J.h(y)
if(J.a(y.gqi(),"circular")){x=P.ax(x.gbw(y),x.gbX(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.M(J.D(x.gbw(y),b),100)
return x},
bRj:[function(a,b,c){return L.b3h(a,c)},"$3","ae_",6,0,1,16,28,1],
b3h:function(a,b){var z,y,x,w
z=a.C("view")
if(z==null)return
y=z.gdt()
if(y==null)return
x=J.h(y)
w=J.aw(b)
return J.a(y.gqi(),"circular")?J.M(w.bl(b,200),P.ax(x.gbw(y),x.gbX(y))):J.M(w.bl(b,100),x.gbw(y))},
aon:{"^":"N_;a,b,c",
sc6:function(a,b){var z,y,x,w,v
if(J.a(this.b,b))return
this.ayd(this,b)
if(b instanceof N.l6){z=b.e
if(z.gaT() instanceof N.eE&&H.j(z.gaT(),"$iseE").K!=null){J.lq(J.I(this.a),"")
return}y=K.bP(b.r,"fault")
if(y==="fault"&&b.r instanceof F.v){x=b.r
if(J.a(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof F.el&&J.y(w.ry,0)){z=H.j(w.d_(0),"$isjF")
y=K.eR(z.ghk(z),null,"rgba(0,0,0,0)")}}}v=H.b(y==="fault"?K.eR(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.lq(J.I(this.a),v)}}},
anb:{"^":"akP;aa,a9,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,F,v,L,R,W,X,T,D,Z,U,ar,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sqQ:function(a){var z=this.k4
if(z instanceof F.v)H.j(z,"$isv").d0(this.gdC())
this.axp(a)
if(a instanceof F.v)a.dm(this.gdC())},
stZ:function(a,b){this.acw(this,b)
this.Wv()},
sHT:function(a){this.acx(a)
this.Wv()},
ge7:function(){return this.a9},
se7:function(a){H.j(a,"$isaM")
this.a9=a
if(a!=null)F.bY(this.gb4z())},
eO:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.acy(a,b)
return}if(!!J.n(a).$isb4){z=this.aa.a
if(!z.S(0,a))z.l(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jz(b)}},
oM:[function(a){this.d1()},"$1","gdC",2,0,2,11],
Wv:[function(){var z=this.a9
if(z!=null)if(z.a instanceof F.v)F.a7(new L.anc(this))},"$0","gb4z",0,0,0]},
anc:{"^":"c:3;a",
$0:[function(){var z=this.a
z.a9.a.bE("offsetLeft",z.U)
z.a9.a.bE("offsetRight",z.ar)},null,null,0,0,null,"call"]},
En:{"^":"aGF;aI,dt:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,c7,bY,bZ,bH,bU,bT,c3,c8,cc,c9,bK,cd,cD,cs,ce,cE,ct,cz,cA,cB,cu,cF,cl,cv,cG,cn,ca,cK,co,bN,cp,cC,cq,cr,cj,cH,cT,cI,cL,cW,cJ,cw,cM,cN,cS,cb,cO,cP,cm,cQ,cU,cR,F,v,L,R,W,X,T,D,Z,U,ar,aa,a9,ac,ag,ah,at,ad,aL,aP,aW,ai,aM,aC,aG,an,ao,aF,aU,aw,b_,b8,b4,bf,bb,b5,aX,b9,bs,aY,bv,aZ,bp,bg,bn,bj,bk,b3,bD,bh,bi,bB,bS,bF,br,bL,bA,bQ,bG,bP,bI,bt,bc,bW,bq,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdw:function(){return this.aI},
sfb:function(a,b){if(J.a(this.D,"none")&&!J.a(b,"none")){this.mc(this,b)
this.ec()}else this.mc(this,b)},
fC:[function(a,b){this.mx(this,b)
this.sis(!0)},"$1","gf9",2,0,2,11],
rZ:[function(a){this.x0()},"$0","gmL",0,0,0],
a7:[function(){this.sis(!1)
this.fJ()
this.w.sHH(!0)
this.w.a7()
this.w.sqQ(null)
this.w.sHH(!1)},"$0","gdc",0,0,0],
ie:[function(){this.sis(!1)
this.fJ()},"$0","gks",0,0,0],
fX:function(){this.Cj()
this.sis(!0)},
x0:function(){if(this.a instanceof F.v)this.w.iu(J.d1(this.b),J.cV(this.b))},
ec:function(){var z,y
this.zJ()
this.soE(-1)
z=this.w
y=J.h(z)
y.sbw(z,J.o(y.gbw(z),1))},
$isbL:1,
$isbK:1,
$iscI:1},
aGF:{"^":"aM+mE;oE:x$?,uS:y$?",$iscI:1},
bhT:{"^":"c:36;",
$2:[function(a,b){a.gdt().sqi(K.at(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bhU:{"^":"c:36;",
$2:[function(a,b){J.Jw(a.gdt(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhV:{"^":"c:36;",
$2:[function(a,b){a.gdt().sHT(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhX:{"^":"c:36;",
$2:[function(a,b){J.yl(a.gdt(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhY:{"^":"c:36;",
$2:[function(a,b){J.yk(a.gdt(),K.aV(b,100))},null,null,4,0,null,0,2,"call"]},
bhZ:{"^":"c:36;",
$2:[function(a,b){a.gdt().swe(K.G(b,""))},null,null,4,0,null,0,2,"call"]},
bi_:{"^":"c:36;",
$2:[function(a,b){a.gdt().savN(K.T(b,!1))},null,null,4,0,null,0,2,"call"]},
bi0:{"^":"c:36;",
$2:[function(a,b){a.gdt().sb0Y(K.kM(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bi1:{"^":"c:36;",
$2:[function(a,b){a.gdt().sqQ(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
bi2:{"^":"c:36;",
$2:[function(a,b){a.gdt().sHw(K.G(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bi3:{"^":"c:36;",
$2:[function(a,b){a.gdt().sHx(K.at(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bi4:{"^":"c:36;",
$2:[function(a,b){a.gdt().sHy(K.at(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bi5:{"^":"c:36;",
$2:[function(a,b){a.gdt().sHA(K.at(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bi7:{"^":"c:36;",
$2:[function(a,b){a.gdt().sHz(K.ak(b,0))},null,null,4,0,null,0,2,"call"]},
bi8:{"^":"c:36;",
$2:[function(a,b){a.gdt().saV6(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bi9:{"^":"c:36;",
$2:[function(a,b){a.gdt().saV5(K.at(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bia:{"^":"c:36;",
$2:[function(a,b){a.gdt().sRu(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bib:{"^":"c:36;",
$2:[function(a,b){J.Jk(a.gdt(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bic:{"^":"c:36;",
$2:[function(a,b){a.gdt().sUJ(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bid:{"^":"c:36;",
$2:[function(a,b){a.gdt().sUK(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bie:{"^":"c:36;",
$2:[function(a,b){a.gdt().sUL(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
bif:{"^":"c:36;",
$2:[function(a,b){a.gdt().sa5A(K.ak(b,11))},null,null,4,0,null,0,2,"call"]},
big:{"^":"c:36;",
$2:[function(a,b){a.gdt().saUW(K.at(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
and:{"^":"akQ;L,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,F,v,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sqS:function(a){var z=this.rx
if(z instanceof F.v)H.j(z,"$isv").d0(this.gdC())
this.axx(a)
if(a instanceof F.v)a.dm(this.gdC())},
sa5z:function(a){var z=this.k4
if(z instanceof F.v)H.j(z,"$isv").d0(this.gdC())
this.axw(a)
if(a instanceof F.v)a.dm(this.gdC())},
f8:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.L.a
if(z.S(0,a))z.h(0,a).jM(null)
this.axs(a,b,c,d)
return}if(!!J.n(a).$isb4){z=this.L.a
if(!z.S(0,a))z.l(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jM(b)
y.slf(c)
y.skV(d)}},
oM:[function(a){this.d1()},"$1","gdC",2,0,2,11]},
Ep:{"^":"aGG;aI,dt:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,c7,bY,bZ,bH,bU,bT,c3,c8,cc,c9,bK,cd,cD,cs,ce,cE,ct,cz,cA,cB,cu,cF,cl,cv,cG,cn,ca,cK,co,bN,cp,cC,cq,cr,cj,cH,cT,cI,cL,cW,cJ,cw,cM,cN,cS,cb,cO,cP,cm,cQ,cU,cR,F,v,L,R,W,X,T,D,Z,U,ar,aa,a9,ac,ag,ah,at,ad,aL,aP,aW,ai,aM,aC,aG,an,ao,aF,aU,aw,b_,b8,b4,bf,bb,b5,aX,b9,bs,aY,bv,aZ,bp,bg,bn,bj,bk,b3,bD,bh,bi,bB,bS,bF,br,bL,bA,bQ,bG,bP,bI,bt,bc,bW,bq,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdw:function(){return this.aI},
sfb:function(a,b){if(J.a(this.D,"none")&&!J.a(b,"none")){this.mc(this,b)
this.ec()}else this.mc(this,b)},
fC:[function(a,b){this.mx(this,b)
this.sis(!0)
if(b==null)this.w.iu(J.d1(this.b),J.cV(this.b))},"$1","gf9",2,0,2,11],
rZ:[function(a){this.w.iu(J.d1(this.b),J.cV(this.b))},"$0","gmL",0,0,0],
a7:[function(){this.sis(!1)
this.fJ()
this.w.sHH(!0)
this.w.a7()
this.w.sqS(null)
this.w.sa5z(null)
this.w.sHH(!1)},"$0","gdc",0,0,0],
ie:[function(){this.sis(!1)
this.fJ()},"$0","gks",0,0,0],
fX:function(){this.Cj()
this.sis(!0)},
ec:function(){var z,y
this.zJ()
this.soE(-1)
z=this.w
y=J.h(z)
y.sbw(z,J.o(y.gbw(z),1))},
x0:function(){this.w.iu(J.d1(this.b),J.cV(this.b))},
$isbL:1,
$isbK:1},
aGG:{"^":"aM+mE;oE:x$?,uS:y$?",$iscI:1},
bii:{"^":"c:48;",
$2:[function(a,b){a.gdt().sqi(K.at(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bij:{"^":"c:48;",
$2:[function(a,b){a.gdt().sb39(K.at(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bik:{"^":"c:48;",
$2:[function(a,b){J.Jw(a.gdt(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bil:{"^":"c:48;",
$2:[function(a,b){a.gdt().sHT(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bim:{"^":"c:48;",
$2:[function(a,b){a.gdt().sa5z(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
bin:{"^":"c:48;",
$2:[function(a,b){a.gdt().saW2(K.ak(b,1))},null,null,4,0,null,0,2,"call"]},
bio:{"^":"c:48;",
$2:[function(a,b){a.gdt().sqS(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
bip:{"^":"c:48;",
$2:[function(a,b){a.gdt().sHO(K.ak(b,1))},null,null,4,0,null,0,2,"call"]},
biq:{"^":"c:48;",
$2:[function(a,b){a.gdt().sRu(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bir:{"^":"c:48;",
$2:[function(a,b){J.Jk(a.gdt(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bit:{"^":"c:48;",
$2:[function(a,b){a.gdt().sUJ(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
biu:{"^":"c:48;",
$2:[function(a,b){a.gdt().sUK(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
biv:{"^":"c:48;",
$2:[function(a,b){a.gdt().sUL(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
biw:{"^":"c:48;",
$2:[function(a,b){a.gdt().sa5A(K.ak(b,11))},null,null,4,0,null,0,2,"call"]},
bix:{"^":"c:48;",
$2:[function(a,b){a.gdt().saW3(K.kM(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
biy:{"^":"c:48;",
$2:[function(a,b){a.gdt().saWw(K.ak(b,2))},null,null,4,0,null,0,2,"call"]},
biz:{"^":"c:48;",
$2:[function(a,b){a.gdt().saWx(K.kM(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
biA:{"^":"c:48;",
$2:[function(a,b){a.gdt().saO0(K.aV(b,null))},null,null,4,0,null,0,2,"call"]},
ane:{"^":"akR;v,L,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,F,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gk9:function(){return this.L},
sk9:function(a){var z=this.L
if(z!=null)z.d0(this.ga8T())
this.L=a
if(a!=null)a.dm(this.ga8T())
this.b4e(null)},
b4e:[function(a){var z,y,x,w,v,u,t,s
z=this.L
if(z==null){z=new F.el(!1,H.d([],[F.aB]),0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,null,!1,null,!1,0,null,null,null,null,null)
z.bm()
z.aQ(!1,null)
z.ch=null
z.fQ(F.hS(new F.du(0,255,0,1),0,0))
z.fQ(F.hS(new F.du(0,0,0,1),0,50))}y=J.hP(z)
x=J.b9(y)
x.ew(y,F.rT())
w=[]
if(J.y(x.gm(y),1))for(x=x.gbd(y);x.u();){v=x.gH()
u=J.h(v)
t=u.ghk(v)
s=H.dx(v.i("alpha"))
s.toString
w.push(new N.xo(t,s,J.M(u.gu5(v),100)))}else if(J.a(x.gm(y),1)){v=x.h(y,0)
x=J.h(v)
u=x.ghk(v)
t=H.dx(v.i("alpha"))
t.toString
w.push(new N.xo(u,t,0))
x=x.ghk(v)
t=H.dx(v.i("alpha"))
t.toString
w.push(new N.xo(x,t,1))}this.saaW(w)},"$1","ga8T",2,0,5,11],
eO:function(a,b){var z,y,x
if(typeof b==="number"&&Math.floor(b)===b){this.acy(a,b)
return}if(!!J.n(a).$isb4){z=this.v.a
if(!z.S(0,a))z.l(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
x=F.cH(!1,null)
x.B("fillType",!0).a_("gradient")
x.B("gradient",!0).$2(b,!1)
x.B("gradientType",!0).a_("linear")
y.jz(x)}},
a7:[function(){var z=this.L
if(z!=null){z.d0(this.ga8T())
this.L=null}this.axy()},"$0","gdc",0,0,0],
aBg:function(){var z=$.$get$Dm()
if(J.a(z.ry,0)){z.fQ(F.hS(new F.du(0,255,0,1),1,0))
z.fQ(F.hS(new F.du(255,255,0,1),1,50))
z.fQ(F.hS(new F.du(255,0,0,1),1,100))}},
af:{
anf:function(){var z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.ane(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cl(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.cy=P.hK()
z.aB6()
z.aBg()
return z}}},
Er:{"^":"aGH;aI,dt:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,c7,bY,bZ,bH,bU,bT,c3,c8,cc,c9,bK,cd,cD,cs,ce,cE,ct,cz,cA,cB,cu,cF,cl,cv,cG,cn,ca,cK,co,bN,cp,cC,cq,cr,cj,cH,cT,cI,cL,cW,cJ,cw,cM,cN,cS,cb,cO,cP,cm,cQ,cU,cR,F,v,L,R,W,X,T,D,Z,U,ar,aa,a9,ac,ag,ah,at,ad,aL,aP,aW,ai,aM,aC,aG,an,ao,aF,aU,aw,b_,b8,b4,bf,bb,b5,aX,b9,bs,aY,bv,aZ,bp,bg,bn,bj,bk,b3,bD,bh,bi,bB,bS,bF,br,bL,bA,bQ,bG,bP,bI,bt,bc,bW,bq,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdw:function(){return this.aI},
sfb:function(a,b){if(J.a(this.D,"none")&&!J.a(b,"none")){this.mc(this,b)
this.ec()}else this.mc(this,b)},
fC:[function(a,b){this.mx(this,b)
this.sis(!0)},"$1","gf9",2,0,2,11],
rZ:[function(a){this.x0()},"$0","gmL",0,0,0],
a7:[function(){this.sis(!1)
this.fJ()
this.w.sHH(!0)
this.w.a7()
this.w.sk9(null)
this.w.sHH(!1)},"$0","gdc",0,0,0],
ie:[function(){this.sis(!1)
this.fJ()},"$0","gks",0,0,0],
fX:function(){this.Cj()
this.sis(!0)},
ec:function(){var z,y
this.zJ()
this.soE(-1)
z=this.w
y=J.h(z)
y.sbw(z,J.o(y.gbw(z),1))},
x0:function(){if(this.a instanceof F.v)this.w.iu(J.d1(this.b),J.cV(this.b))},
$isbL:1,
$isbK:1},
aGH:{"^":"aM+mE;oE:x$?,uS:y$?",$iscI:1},
bhG:{"^":"c:73;",
$2:[function(a,b){a.gdt().sqi(K.at(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bhH:{"^":"c:73;",
$2:[function(a,b){J.Jw(a.gdt(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhI:{"^":"c:73;",
$2:[function(a,b){a.gdt().sHT(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhJ:{"^":"c:73;",
$2:[function(a,b){a.gdt().sb0X(K.kM(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bhK:{"^":"c:73;",
$2:[function(a,b){a.gdt().sb0W(K.kM(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bhM:{"^":"c:73;",
$2:[function(a,b){a.gdt().sjn(K.at(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bhN:{"^":"c:73;",
$2:[function(a,b){var z=a.gdt()
z.sk9(b!=null?F.pX(b):$.$get$Dm())},null,null,4,0,null,0,2,"call"]},
bhO:{"^":"c:73;",
$2:[function(a,b){a.gdt().sRu(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bhP:{"^":"c:73;",
$2:[function(a,b){J.Jk(a.gdt(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bhQ:{"^":"c:73;",
$2:[function(a,b){a.gdt().sUJ(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bhR:{"^":"c:73;",
$2:[function(a,b){a.gdt().sUK(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bhS:{"^":"c:73;",
$2:[function(a,b){a.gdt().sUL(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
yH:{"^":"t;a9W:a@,iL:b*,jl:c*"},
ak5:{"^":"lD;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,c,d,e,f,r,x,y,z,Q,ch,a,b",
gqE:function(){return this.r1},
sqE:function(a){if(!J.a(this.r1,a)){this.r1=a
this.d1()}},
gd2:function(){return this.r2},
sd2:function(a){this.b1I(a)},
gka:function(){return this.go},
iV:function(a,b){var z,y,x,w
this.FH(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.hK()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.b(a)+"px"
z.width=y
z=this.id.style
y=H.b(b)+"px"
z.height=y
this.f8(this.k1,0,0,"none")
this.eO(this.k1,this.r2.cd)
z=this.k2
y=this.r2
this.f8(z,y.cc,J.aL(y.c9),this.r2.bK)
y=this.k3
z=this.r2
this.f8(y,z.cc,J.aL(z.c9),this.r2.bK)
z=this.db
if(z===2){z=J.y(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a0(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aK(a))
y=this.k1
y.toString
y.setAttribute("height",J.a0(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a0(J.k(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aK(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aK(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.b(this.cy.b)+" L "+H.b(a)+","+H.b(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.b(J.k(this.cy.b,this.r1.b))+" L "+H.b(a)+","+H.b(J.k(this.cy.b,this.r1.b)))}else if(z===1){z=J.y(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a0(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a0(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aK(b))}else{x.toString
x.setAttribute("x",J.a0(J.k(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aK(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aK(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.b(this.cy.a)+",0 L "+H.b(this.cy.a)+","+H.b(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.b(J.k(this.cy.a,this.r1.a))+",0 L "+H.b(J.k(this.cy.a,this.r1.a))+","+H.b(b))}else if(z===3){z=J.y(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a0(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a0(this.r1.a))}else{y.toString
y.setAttribute("x",J.a0(J.k(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aK(0-y))}z=J.y(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a0(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a0(this.r1.b))}else{y.toString
y.setAttribute("y",J.a0(J.k(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aK(0-y))}z=this.k1
y=this.r2
this.f8(z,y.cc,J.aL(y.c9),this.r2.bK)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
b1I:function(a){var z
this.a7Z()
this.a8_()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().J(0)
this.r2.pg(0,"CartesianChartZoomerReset",this.gal3())}this.r2=a
if(a!=null){z=J.ck(a.cx)
z=H.d(new W.A(0,z.a,z.b,W.z(this.gaM3()),z.c),[H.r(z,0)])
z.t()
this.fx.push(z)
this.r2.nt(0,"CartesianChartZoomerReset",this.gal3())}this.dx=null
this.dy=null},
LF:function(a){var z,y,x,w,v
z=this.Jg(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.K)(z),++x){v=J.n(z[x])
if(!(!!v.$isri||!!v.$isi0||!!v.$isiW))return!1}return!0},
atD:function(a){var z=J.n(a)
if(!!z.$isiW)return J.av(a.db)?null:a.db
else if(!!z.$isrk)return a.db
return 0/0},
Y8:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isiW){if(b==null)y=null
else{y=J.aN(b)
x=!a.ah
w=new P.ag(y,x)
w.eJ(y,x)
y=w}z.siL(a,y)}else if(!!z.$isi0)z.siL(a,b)
else if(!!z.$isri)z.siL(a,b)},
avn:function(a,b){return this.Y8(a,b,!1)},
atB:function(a){var z=J.n(a)
if(!!z.$isiW)return J.av(a.cy)?null:a.cy
else if(!!z.$isrk)return a.cy
return 0/0},
Y7:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isiW){if(b==null)y=null
else{y=J.aN(b)
x=!a.ah
w=new P.ag(y,x)
w.eJ(y,x)
y=w}z.sjl(a,y)}else if(!!z.$isi0)z.sjl(a,b)
else if(!!z.$isri)z.sjl(a,b)},
avm:function(a,b){return this.Y7(a,b,!1)},
a9R:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[N.e8,L.yH])),[N.e8,L.yH])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[N.e8,L.yH])),[N.e8,L.yH])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.Jg(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.K)(v),++u){t=v[u]
s=x.a
if(!s.S(0,t)){r=J.n(t)
r=!!r.$isri||!!r.$isi0||!!r.$isiW}else r=!1
if(r)s.l(0,t,new L.yH(!1,this.atD(t),this.atB(t)))}}y=this.cy
if(z){y=y.b
q=P.aA(y,J.k(y,b))
y=this.cy.b
p=P.ax(y,J.k(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aA(y,J.k(y,b))
y=this.cy.a
m=P.ax(y,J.k(y,b))
o="h"
q=null
p=null}l=[]
k=N.jM(this.r2.ad,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof N.k1))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.at:f.ah
r=J.n(h)
if(!(!!r.$isri||!!r.$isi0||!!r.$isiW)){g=f
break c$0}if(J.au(C.a.cV(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=Q.b8(y,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.aj(f.gd2()),e).b)
if(typeof q!=="number")return q.A()
y=H.d(new P.F(0,q-y),[null])
y=f.fr.pM([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(1>=y.length)return H.e(y,1)
j=y[1]
e=Q.b8(f.cy,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.aj(f.gd2()),e).b)
if(typeof p!=="number")return p.A()
y=H.d(new P.F(0,p-y),[null])
y=f.fr.pM([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(1>=y.length)return H.e(y,1)
i=y[1]}else{e=Q.b8(y,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.aj(f.gd2()),e).a)
if(typeof m!=="number")return m.A()
y=H.d(new P.F(m-y,0),[null])
y=f.fr.pM([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(0>=y.length)return H.e(y,0)
j=y[0]
e=Q.b8(f.cy,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.aj(f.gd2()),e).a)
if(typeof n!=="number")return n.A()
y=H.d(new P.F(n-y,0),[null])
y=f.fr.pM([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(0>=y.length)return H.e(y,0)
i=y[0]}if(J.S(i,j)){d=i
i=j
j=d}this.avn(h,j)
this.avm(h,i)
this.fr=!0
break}k.length===y||(0,H.K)(k);++u}if(!this.fr)return
x.a.h(0,h).sa9W(!0)
if(h!=null&&!c){y=this.r2
if(z){y.c3=j
y.c8=i
y.as9()}else{y.bH=j
y.bU=i
y.arq()}}},
asJ:function(a,b){return this.a9R(a,b,!1)},
apP:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.Jg(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.S(0,t)){this.Y8(t,J.SZ(w.h(0,t)),!0)
this.Y7(t,J.SY(w.h(0,t)),!0)
if(w.h(0,t).ga9W())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.bH=0/0
x.bU=0/0
x.arq()}},
a7Z:function(){return this.apP(!1)},
apT:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.Jg(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.S(0,t)){this.Y8(t,J.SZ(w.h(0,t)),!0)
this.Y7(t,J.SY(w.h(0,t)),!0)
if(w.h(0,t).ga9W())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.c3=0/0
x.c8=0/0
x.as9()}},
a8_:function(){return this.apT(!1)},
asK:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.E(a)
if(z.gki(a)||J.av(b)){if(this.fr)if(c)this.apT(!0)
else this.apP(!0)
return}if(!this.LF(c))return
y=this.Jg(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.atW(x)
if(w==null)return
v=J.n(b)
if(c){u=J.k(w.GV(["0",z.aK(a)]).b,this.aaU(w))
t=J.k(w.GV(["0",v.aK(b)]).b,this.aaU(w))
this.cy=H.d(new P.F(50,u),[null])
this.a9R(2,J.o(t,u),!0)}else{s=J.k(w.GV([z.aK(a),"0"]).a,this.aaT(w))
r=J.k(w.GV([v.aK(b),"0"]).a,this.aaT(w))
this.cy=H.d(new P.F(s,50),[null])
this.a9R(1,J.o(r,s),!0)}},
Jg:function(a){var z,y,x,w,v,u,t
z=[]
y=N.jM(this.r2.ad,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.K)(y),++v){u=y[v]
if(!(u instanceof N.k1))continue
if(a){t=u.at
if(t!=null&&J.S(C.a.cV(z,t),0))z.push(u.at)}else{t=u.ah
if(t!=null&&J.S(C.a.cV(z,t),0))z.push(u.ah)}w=u}return z},
atW:function(a){var z,y,x,w,v
z=N.jM(this.r2.ad,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.K)(z),++w){v=z[w]
if(!(v instanceof N.k1))continue
if(J.a(v.at,a)||J.a(v.ah,a))return v
x=v}return},
aaT:function(a){var z=Q.b8(a.cy,H.d(new P.F(0,0),[null]))
return J.aL(Q.aK(J.aj(a.gd2()),z).a)},
aaU:function(a){var z=Q.b8(a.cy,H.d(new P.F(0,0),[null]))
return J.aL(Q.aK(J.aj(a.gd2()),z).b)},
f8:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.S(0,a))z.h(0,a).jM(null)
R.p6(a,b,c,d)
return}if(!!J.n(a).$isb4){z=this.k4.a
if(!z.S(0,a))z.l(0,a,new E.bW(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jM(b)
y.slf(c)
y.skV(d)}},
eO:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.S(0,a))z.h(0,a).jz(null)
R.tR(a,b)
return}if(!!J.n(a).$isb4){z=this.k4.a
if(!z.S(0,a))z.l(0,a,new E.bW(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jz(b)}},
ba9:[function(a){var z,y
z=this.r2
if(!z.bY&&!z.bT)return
z.cx.appendChild(this.go)
z=this.r2
this.iu(z.Q,z.ch)
this.cy=Q.aK(this.go,J.ct(a))
this.cx=!0
z=this.fy
y=H.d(new W.ay(document,"mousemove",!1),[H.r(C.C,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaue()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.ay(document,"mouseup",!1),[H.r(C.D,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gauf()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.ay(document,"keydown",!1),[H.r(C.a2,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gAS()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.db=0
this.sqE(null)},"$1","gaM3",2,0,4,4],
b6E:[function(a){var z,y
z=Q.aK(this.go,J.ct(a))
if(this.db===0)if(this.r2.bZ){if(!(this.LF(!0)&&this.LF(!1))){this.GL()
return}if(J.au(J.ba(J.o(z.a,this.cy.a)),2)&&J.au(J.ba(J.o(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.y(J.ba(J.o(z.b,this.cy.b)),J.ba(J.o(z.a,this.cy.a)))){if(this.LF(!0))this.db=2
else{this.GL()
return}y=2}else{if(this.LF(!1))this.db=1
else{this.GL()
return}y=1}if(y===1)if(!this.r2.bY){this.GL()
return}if(y===2)if(!this.r2.bT){this.GL()
return}}y=this.r2
if(P.bd(0,0,y.Q,y.ch,null).nW(0,z)){y=this.db
if(y===2)this.sqE(H.d(new P.F(0,J.o(z.b,this.cy.b)),[null]))
else if(y===1)this.sqE(H.d(new P.F(J.o(z.a,this.cy.a),0),[null]))
else if(y===3)this.sqE(H.d(new P.F(J.o(z.a,this.cy.a),J.o(z.b,this.cy.b)),[null]))
else this.sqE(null)}},"$1","gaue",2,0,4,4],
b6F:[function(a){var z,y
for(z=this.fy;z.length>0;)z.pop().J(0)
J.X(this.go)
this.cx=!1
this.d1()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.asJ(2,z.b)
z=this.db
if(z===1||z===3)this.asJ(1,this.r1.a)}else{this.a7Z()
F.a7(new L.ak7(this))}},"$1","gauf",2,0,4,4],
a43:[function(a){if(Q.cN(a)===27)this.GL()},"$1","gAS",2,0,6,4],
GL:function(){for(var z=this.fy;z.length>0;)z.pop().J(0)
J.X(this.go)
this.cx=!1
this.d1()},
bcB:[function(a){this.a7Z()
F.a7(new L.ak8(this))},"$1","gal3",2,0,7,4],
aB2:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.x(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
af:{
ak6:function(){var z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.ak5(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.aB2()
return z}}},
ak7:{"^":"c:3;a",
$0:[function(){this.a.a8_()},null,null,0,0,null,"call"]},
ak8:{"^":"c:3;a",
$0:[function(){this.a.a8_()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.bb,args:[F.v,P.u,P.bb]},{func:1,v:true,args:[[P.a_,P.u]]},{func:1,ret:Q.bL},{func:1,v:true,args:[W.cz]},{func:1,v:true,args:[P.t]},{func:1,v:true,args:[W.hi]},{func:1,v:true,args:[E.ci]},{func:1,ret:P.u,args:[N.l6]}]
init.types.push.apply(init.types,deferredTypes)
$.Ru=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["ZF","$get$ZF",function(){return P.m(["scaleType",new L.bhT(),"offsetLeft",new L.bhU(),"offsetRight",new L.bhV(),"minimum",new L.bhX(),"maximum",new L.bhY(),"formatString",new L.bhZ(),"showMinMaxOnly",new L.bi_(),"percentTextSize",new L.bi0(),"labelsColor",new L.bi1(),"labelsFontFamily",new L.bi2(),"labelsFontStyle",new L.bi3(),"labelsFontWeight",new L.bi4(),"labelsTextDecoration",new L.bi5(),"labelsLetterSpacing",new L.bi7(),"labelsRotation",new L.bi8(),"labelsAlign",new L.bi9(),"angleFrom",new L.bia(),"angleTo",new L.bib(),"percentOriginX",new L.bic(),"percentOriginY",new L.bid(),"percentRadius",new L.bie(),"majorTicksCount",new L.bif(),"justify",new L.big()])},$,"ZG","$get$ZG",function(){var z=P.a1()
z.q(0,E.eN())
z.q(0,$.$get$ZF())
return z},$,"ZH","$get$ZH",function(){return P.m(["scaleType",new L.bii(),"ticksPlacement",new L.bij(),"offsetLeft",new L.bik(),"offsetRight",new L.bil(),"majorTickStroke",new L.bim(),"majorTickStrokeWidth",new L.bin(),"minorTickStroke",new L.bio(),"minorTickStrokeWidth",new L.bip(),"angleFrom",new L.biq(),"angleTo",new L.bir(),"percentOriginX",new L.bit(),"percentOriginY",new L.biu(),"percentRadius",new L.biv(),"majorTicksCount",new L.biw(),"majorTicksPercentLength",new L.bix(),"minorTicksCount",new L.biy(),"minorTicksPercentLength",new L.biz(),"cutOffAngle",new L.biA()])},$,"ZI","$get$ZI",function(){var z=P.a1()
z.q(0,E.eN())
z.q(0,$.$get$ZH())
return z},$,"ZJ","$get$ZJ",function(){return P.m(["scaleType",new L.bhG(),"offsetLeft",new L.bhH(),"offsetRight",new L.bhI(),"percentStartThickness",new L.bhJ(),"percentEndThickness",new L.bhK(),"placement",new L.bhM(),"gradient",new L.bhN(),"angleFrom",new L.bhO(),"angleTo",new L.bhP(),"percentOriginX",new L.bhQ(),"percentOriginY",new L.bhR(),"percentRadius",new L.bhS()])},$,"ZK","$get$ZK",function(){var z=P.a1()
z.q(0,E.eN())
z.q(0,$.$get$ZJ())
return z},$])}
$dart_deferred_initializers$["Bm1vQVm2n2eCOipFibVTyyXqwr4="]=$dart_deferred_initializers$.current

//# sourceMappingURL=main.dart.js_2.part.js.map
