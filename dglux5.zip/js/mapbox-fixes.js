mapboxgl.Map.prototype.dgAddLayerFixed = function(layer, before) {
  // hack to fix unimplemented feature in package:js
  // transforms key names: a_b_c => a-b-c
  if (layer.paint) {
    var oldPaint = layer.paint;
    layer.paint = {};

    Object.keys(oldPaint).forEach(function(key) {
      var newKey = key.split('_').join('-');
      layer.paint[newKey] = oldPaint[key];
    });
  }

  if (layer.layout) {
    var oldLayout = layer.layout;
    layer.layout = {};

    Object.keys(oldLayout).forEach(function(key) {
      var newKey = key.split('_').join('-');
      layer.layout[newKey] = oldLayout[key];
    });
  }

  mapboxgl.Map.prototype.addLayer.call(this, layer, before);
};

mapboxgl.Map.prototype.dgExposeToInterop = function() {
  mapboxgl.fixes.exposedMap = this;
};

mapboxgl.Map.prototype.dgHideFromInterop = function() {
  mapboxgl.fixes.exposedMap = null;
};

// most all of these are to work around Dart having no really performant way
// to convert a Dart Map to a JS object
mapboxgl.fixes = {
  // convert DGLux table data into a JS object
  createFeatureProperties: function(columns, data) {
    var map = {};

    var i = 0;
    var length = columns.length;

    for (; i < length; i++) {
      map[columns[i]] = data[i];
    }

    return map;
  },
  // use JSON.parse instead of Dart's JSON.decode so we can make Mapbox use the
  // data as GeoJSON
  createJsonSource: function(str) {
    return JSON.parse(str);
  }
};
