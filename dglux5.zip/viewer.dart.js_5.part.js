self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,K,{"^":"",
CM:function(a,b,c,d,e,f){var z,y,x,w,v,u,t,s,r
z=K.C(a,null)
if(z==null)return c
if(!K.u1(z)){y=J.m(z)
y=y.j(z,1/0)||y.j(z,-1/0)}else y=!0
if(y){if(d)return J.U(z)
return c}y=J.au(e)
x=J.pp(y.aB(e,z),b)
w=C.c.c3(x,".")
if(w>=0){v=C.c.nH(x,$.$get$a2O(),w)
if(v>0)x=C.c.bw(x,0,v)
else{u=C.c.nH(x,$.$get$a2P(),w)
if(u>0){x=C.c.bw(x,0,u)
t=y.aB(e,z)
s=u-w
H.a0(10)
H.a0(s)
r=Math.pow(10,s)
x=C.c.bw(J.pp(J.E(J.bk(J.x(t,r)),r),20),0,x.length)}}if(typeof b!=="number")return H.j(b)
if(x.length-w>b)x=J.pp(y.aB(e,z),b)}w=C.c.c3(x,".")
if(f&&w>0){while(!0){if(!(C.c.he(x,"0")&&!C.c.he(x,".")))break
x=C.c.bw(x,0,x.length-1)}if(C.c.he(x,"."))x=C.c.bw(x,0,x.length-1)}return x}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[]
init.types.push.apply(init.types,deferredTypes);(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["a2O","$get$a2O",function(){return P.cx("0{5,}",!0,!1)},$,"a2P","$get$a2P",function(){return P.cx("9{5,}",!0,!1)},$])}
$dart_deferred_initializers$["6Vc9Ai4jBTqrclK9fhm8fnLi5XA="]=$dart_deferred_initializers$.current

//# sourceMappingURL=viewer.dart.js_13.part.js.map
