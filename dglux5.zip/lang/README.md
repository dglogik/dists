# DGLux5 Localization

DGLux5 Translation Dictionaries

## Contributing

* Check if your locale exists.
  * If it doesn't exist then copy the "template.json" to "locales".
* Rename to your lang (e.g. en_US.json), the file must end in *.json
* That's it! You can now start translating.
