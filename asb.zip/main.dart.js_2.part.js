self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,D,{"^":"",
aQL:function(){var z=document
z=z.createElement("div")
z=new D.Ic(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,[P.D,P.aH]])),[P.v,[P.D,P.aH]]))
z.a=z
z.qH()
z.ak5()
return z},
apy:{"^":"MH;",
sti:["aGR",function(a){if(!J.a(this.k4,a)){this.k4=a
this.dl()}}],
sKE:function(a){if(!J.a(this.r1,a)){this.r1=a
this.dl()}},
sKF:function(a){if(!J.a(this.rx,a)){this.rx=a
this.dl()}},
sKG:function(a){if(!J.a(this.ry,a)){this.ry=a
this.dl()}},
sKI:function(a){if(!J.a(this.x1,a)){this.x1=a
this.dl()}},
sKH:function(a){if(!J.a(this.x2,a)){this.x2=a
this.dl()}},
sb5Z:function(a){if(!J.a(this.y1,a)){if(J.y(a,180))a=180
this.y1=J.Q(a,-180)?-180:a
this.dl()}},
sb5Y:function(a){if(J.a(this.y2,a))return
this.y2=a
this.dl()},
gjo:function(a){return this.B},
sjo:function(a,b){if(b==null)b=0
if(!J.a(this.B,b)){this.B=b
this.dl()}},
gk0:function(a){return this.T},
sk0:function(a,b){if(b==null)b=100
if(!J.a(this.T,b)){this.T=b
this.dl()}},
sbdE:function(a){if(this.I!==a){this.I=a
this.dl()}},
gwV:function(a){return this.W},
swV:function(a,b){if(b==null||J.Q(b,0))b=0
if(J.y(b,4))b=4
if(!J.a(this.W,b)){this.W=b
this.dl()}},
saF0:function(a){if(this.X!==a){this.X=a
this.dl()}},
syl:function(a){this.aa=a
this.dl()},
grz:function(){return this.U},
srz:function(a){if(!J.a(this.U,a)){this.U=a
this.dl()}},
sb5K:function(a){if(!J.a(this.C,a)){this.C=a
this.dl()}},
gvD:function(a){return this.a_},
svD:["aiC",function(a,b){if(!J.a(this.a_,b))this.a_=b}],
sL5:["aiD",function(a){if(!J.a(this.a3,a))this.a3=a}],
sab9:function(a){this.aiF(a)
this.dl()},
jA:function(a,b){this.IJ(a,b)
this.Sk()
if(J.a(this.U,"circular"))this.bdT(a,b)
else this.bdU(a,b)},
Sk:function(){var z,y,x,w,v
z=this.X
y=this.k2
if(z){y.seN(0,2)
z=this.k2.f
if(0>=z.length)return H.e(z,0)
x=z[0]
z=J.m(x)
if(!!z.$isdp)z.sbY(x,this.a87(this.B,this.W))
J.a4(J.bc(x.gbc()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.e(z,1)
x=z[1]
z=J.m(x)
if(!!z.$isdp)z.sbY(x,this.a87(this.T,this.W))
J.a4(J.bc(x.gbc()),"text-decoration",this.x1)}else{y.seN(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.e(z,v)
x=z[v]
z=J.m(x)
if(!!z.$isdp){y=this.B
w=J.k(y,J.B(J.L(J.o(this.T,y),J.o(this.fy,1)),v))
z.sbY(x,this.a87(w,this.W))}J.a4(J.bc(x.gbc()),"text-decoration",this.x1);++v}}this.fe(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.b(this.x2)+"px")},
bdT:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.L(J.o(this.fr,this.dy),z-1)
x=P.aD(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.L(a,2)
x=P.aD(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.o(w,x*(50-u)/100)
u=J.L(b,2)
x=P.aD(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.o(u,x*(50-w)/100)
r=C.c.E(this.I,"%")&&!0
x=this.I
if(r){H.cq("")
x=H.e2(x,"%","")}q=P.dI(x,null)
for(x=J.av(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.e(w,p)
o=w[p]
w=J.k(J.o(this.dy,90),x.bl(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.MP(o)
w=m.b
u=J.G(w)
if(u.bz(w,0)){if(r){l=P.aD(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.L(l,w)}else k=0
l=m.a
j=J.av(l)
i=J.k(j.bl(l,l),u.bl(w,w))
if(typeof i!=="number")H.a9(H.bn(i))
i=Math.sqrt(i)
h=J.B(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.C){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.B(j.dE(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.B(u.dE(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a4(J.bc(o.gbc()),"transform","")
i=J.m(o)
if(!!i.$iscY)i.jp(o,d,c)
else N.fr(o.gbc(),d,c)
i=J.bc(o.gbc())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," scale ("+H.b(k)+")"))
if(!J.a(this.y1,0))if(!!J.m(o.gbc()).$isnC){i=J.bc(o.gbc())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," rotate("+H.b(this.y1)+" "+H.b(j.dE(l,2))+" "+H.b(J.L(u.fw(w),2))+")"))}else{J.hY(J.J(o.gbc())," rotate("+H.b(this.y1)+"deg)")
J.p3(J.J(o.gbc()),H.b(J.B(j.dE(l,2),k))+" "+H.b(J.B(u.dE(w,2),k)))}}},
bdU:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.L(J.o(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.e(x,0)
w=this.MP(x[0])
v=C.c.E(this.I,"%")&&!0
x=this.I
if(v){H.cq("")
x=H.e2(x,"%","")}u=P.dI(x,null)
x=w.b
t=J.G(x)
if(t.bz(x,0))s=J.L(v?J.L(J.B(a,u),200):u,x)
else s=0
r=J.L(J.B(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.af(r)))
p=Math.abs(Math.sin(H.af(r)))
this.aiC(this,J.B(J.L(J.k(J.B(w.a,q),t.bl(x,p)),2),s))
this.a0w()
x=this.k2.f
if(y<0||y>=x.length)return H.e(x,y)
w=this.MP(x[y])
x=w.b
t=J.G(x)
if(t.bz(x,0))s=J.L(v?J.L(J.B(a,u),200):u,x)
else s=0
this.aiD(J.B(J.L(J.k(J.B(w.a,q),t.bl(x,p)),2),s))
this.a0w()
if(!J.a(this.y1,0)){for(x=J.av(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.e(t,n)
w=this.MP(t[n])
t=w.b
m=J.G(t)
if(m.bz(t,0))J.L(v?J.L(x.bl(a,u),200):u,t)
o=P.aG(J.k(J.B(w.a,p),m.bl(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.G(a)
k=J.L(J.o(x.F(a,this.a_),this.a3),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.e(y,n)
j=y[n]
y=this.a_
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.k(y,t)
w=this.MP(j)
y=w.b
m=J.G(y)
if(m.bz(y,0))s=J.L(v?J.L(x.bl(a,u),200):u,y)
else s=0
h=w.a
g=J.G(h)
i=J.o(i,J.B(g.dE(h,2),s))
J.a4(J.bc(j.gbc()),"transform","")
if(J.a(this.y1,0)){y=J.B(J.k(g.bl(h,p),m.bl(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.m(j)
if(!!y.$iscY)y.jp(j,i,f)
else N.fr(j.gbc(),i,f)
y=J.bc(j.gbc())
t=J.H(y)
t.l(y,"transform",J.k(t.h(y,"transform")," scale ("+H.b(s)+")"))}else{i=J.o(J.k(this.a_,t),g.dE(h,2))
t=J.k(g.bl(h,p),m.bl(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.m(j)
if(!!t.$iscY)t.jp(j,i,e)
else N.fr(j.gbc(),i,e)
d=g.dE(h,2)
c=-y/2
y=J.bc(j.gbc())
t=J.H(y)
m=s-1
t.l(y,"transform",J.k(t.h(y,"transform")," translate("+H.b(J.B(J.bM(d),m))+" "+H.b(-c*m)+")"))
m=J.bc(j.gbc())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," scale ("+H.b(s)+")"))
m=J.bc(j.gbc())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," rotate("+H.b(this.y1)+" "+H.b(d)+" "+H.b(c)+")"))}}},
MP:function(a){var z,y,x,w
if(!!J.m(a.gbc()).$isf_){z=H.j(a.gbc(),"$isf_").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.bl()
w=x*0.7}else{y=J.db(a.gbc())
y.toString
w=J.d4(a.gbc())
w.toString}return H.d(new P.F(y,w),[null])},
a8g:[function(){return D.F5()},"$0","gwt",0,0,3],
a87:function(a,b){var z=this.aa
if(z==null||J.a(z,""))return O.pY(a,"0",null,null)
else return O.pY(a,this.aa,null,null)},
V:[function(){this.aiF(0)
this.dl()
var z=this.k2
z.d=!0
z.r=!0
z.seN(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gdm",0,0,0],
aKT:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.x(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new D.oo(this.gwt(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
MH:{"^":"mj;",
ga3Q:function(){return this.cy},
sZD:["aGV",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.y(a,100))a=100
if(!J.a(this.db,a)){this.db=a
this.dl()}}],
sZE:["aGW",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.y(a,100))a=100
if(!J.a(this.dx,a)){this.dx=a
this.dl()}}],
sWc:["aGS",function(a){if(J.Q(a,-360))a=-360
if(J.y(a,360))a=360
if(!J.a(this.dy,a)){this.dy=a
this.es()
this.dl()}}],
saoI:["aGT",function(a,b){if(J.Q(b,-360))b=-360
if(J.y(b,360))b=360
if(!J.a(this.fr,b)){this.fr=b
this.es()
this.dl()}}],
sb7z:function(a){if(a==null||J.Q(a,0))a=0
if(J.y(a,20))a=20
if(!J.a(this.fx,a)){this.fx=a
this.dl()}},
sab9:["aiF",function(a){if(a==null||J.Q(a,2))a=2
if(J.y(a,30))a=30
if(!J.a(this.fy,a)){this.fy=a
this.dl()}}],
sb7A:function(a){if(this.go!==a){this.go=a
this.dl()}},
sb74:function(a){if(this.id!==a){this.id=a
this.dl()}},
sZF:["aGX",function(a){if(a==null||J.Q(a,0))a=0
if(J.y(a,200))a=200
if(!J.a(this.k1,a)){this.k1=a
this.dl()}}],
gkS:function(){return this.cy},
fG:["aGU",function(a,b,c,d){R.qp(a,b,c,d)}],
fe:["aiE",function(a,b){R.vb(a,b)}],
CE:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.h(a)
if(y!=="")J.a4(z.gfk(a),"d",y)
else J.a4(z.gfk(a),"d","M 0,0")}},
apz:{"^":"MH;",
sab8:["aGY",function(a){if(!J.a(this.k4,a)){this.k4=a
this.dl()}}],
sb73:function(a){if(!J.a(this.r2,a)){this.r2=a
this.dl()}},
stk:["aGZ",function(a){if(!J.a(this.rx,a)){this.rx=a
this.dl()}}],
sKY:function(a){if(!J.a(this.x1,a)){this.x1=a
this.dl()}},
grz:function(){return this.x2},
srz:function(a){if(!J.a(this.x2,a)){this.x2=a
this.dl()}},
gvD:function(a){return this.y1},
svD:function(a,b){if(!J.a(this.y1,b)){this.y1=b
this.dl()}},
sL5:function(a){if(!J.a(this.y2,a)){this.y2=a
this.dl()}},
sbgs:function(a){if(!J.a(this.w,a)){this.w=a
this.dl()}},
saZa:function(a){var z
if(!J.a(this.B,a)){this.B=a
if(a!=null){z=J.o(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.T=z
this.dl()}},
jA:function(a,b){var z,y
this.IJ(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.fG(this.k2,this.k4,J.aR(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.fG(this.k3,this.rx,J.aR(this.x1),this.ry)
if(J.a(this.x2,"circular"))this.b0j(a,b)
else this.b0k(a,b)},
b0j:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.L(J.o(this.fr,this.dy),J.o(J.k(J.B(this.fx,J.o(this.fy,1)),this.fy),1))
x=C.c.E(this.go,"%")&&!0
w=this.go
if(x){H.cq("")
w=H.e2(w,"%","")}v=P.dI(w,null)
if(x){w=P.aD(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aD(a,b)
w=J.L(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.o(w,t*(50-s)/100)
s=J.L(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.o(s,t*(50-w)/100)
w=P.aD(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.a(this.w,"center"))o=0.5
else o=J.a(this.w,"outside")?1:0
w=o-1
s=J.av(y)
n=0
while(!0){m=J.k(J.B(this.fx,J.o(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.k(J.o(this.dy,90),s.bl(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.T
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++n}this.CE(this.k3)
z.a=""
y=J.L(J.o(this.fr,this.dy),J.o(this.fy,1))
h=C.c.E(this.id,"%")&&!0
s=this.id
if(h){H.cq("")
s=H.e2(s,"%","")}g=P.dI(s,null)
if(h){s=P.aD(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.av(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.k(J.o(this.dy,90),s.bl(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.T
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++f}this.CE(this.k2)},
b0k:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.E(this.go,"%")&&!0
y=this.go
if(z){H.cq("")
y=H.e2(y,"%","")}x=P.dI(y,null)
w=z?J.L(J.B(J.L(a,2),x),100):x
v=C.c.E(this.id,"%")&&!0
y=this.id
if(v){H.cq("")
y=H.e2(y,"%","")}u=P.dI(y,null)
t=v?J.L(J.B(J.L(a,2),u),100):u
y=this.cx
y.a=""
s=J.G(a)
r=J.L(J.o(s.F(a,this.y1),this.y2),J.o(J.k(J.B(this.fx,J.o(this.fy,1)),this.fy),1))
if(J.a(this.w,"center"))q=0.5
else q=J.a(this.w,"outside")?1:0
p=J.G(t)
o=p.F(t,w)
n=1-q
m=0
while(!0){l=J.k(J.B(this.fx,J.o(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.F(t,q*o)
y.a+="M "+H.b(k)+","+H.b(n*o)+" "
y.a+="L "+H.b(k)+","+H.b(j)+" ";++m}this.CE(this.k3)
y.a=""
r=J.L(J.o(s.F(a,this.y1),this.y2),J.o(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.b(k)+",0 "
y.a+="L "+H.b(k)+","+H.b(t)+" ";++i}this.CE(this.k2)},
V:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.CE(z)
this.CE(this.k3)}},"$0","gdm",0,0,0]},
apA:{"^":"MH;",
sZD:function(a){this.aGV(a)
this.r2=!0},
sZE:function(a){this.aGW(a)
this.r2=!0},
sWc:function(a){this.aGS(a)
this.r2=!0},
saoI:function(a,b){this.aGT(this,b)
this.r2=!0},
sZF:function(a){this.aGX(a)
this.r2=!0},
sbdD:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.dl()}},
sbdC:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.dl()}},
sagP:function(a){if(this.x2!==a){this.x2=a
this.es()
this.dl()}},
gk6:function(){return this.y1},
sk6:function(a){var z=J.m(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.a(this.y1,a)){this.y1=a
this.r2=!0
this.dl()}},
grz:function(){return this.y2},
srz:function(a){if(!J.a(this.y2,a)){this.y2=a
this.r2=!0
this.dl()}},
gvD:function(a){return this.w},
svD:function(a,b){if(!J.a(this.w,b)){this.w=b
this.r2=!0
this.dl()}},
sL5:function(a){if(!J.a(this.B,a)){this.B=a
this.r2=!0
this.dl()}},
kg:function(a){var z,y,x,w,v,u,t,s,r
this.Cb(this)
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.K)(z),++u){t=z[u]
s=J.h(t)
y.push(s.gi0(t))
x.push(s.gFv(t))
w.push(s.gvK(t))}if(J.cy(J.o(this.dy,this.fr))===!0){z=J.aY(J.o(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.f.P(0.5*z)}else r=0
this.k2=this.aXZ(y,w,r)
this.k3=this.aVb(x,w,r)
this.r2=!0},
jA:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.IJ(a,b)
z=J.av(a)
y=J.av(b)
N.I5(this.k4,z.bl(a,1),y.bl(b,1))
if(J.a(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aD(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.a(this.y2,"circular")){z=P.aG(0,P.aD(a,b))
this.rx=z
this.b0m(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.b(this.rx)+" "+H.b(this.rx))}else{z=J.B(J.o(z.F(a,this.w),this.B),1)
y.bl(b,1)
v=C.c.E(this.ry,"%")&&!0
y=this.ry
if(v){H.cq("")
y=H.e2(y,"%","")}u=P.dI(y,null)
t=v?J.L(J.B(z,u),100):u
s=C.c.E(this.x1,"%")&&!0
y=this.x1
if(s){H.cq("")
y=H.e2(y,"%","")}r=P.dI(y,null)
q=s?J.L(J.B(z,r),100):r
this.r1.seN(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.o(q,t)
p=q
o=p
m=0
break
case"cross":y=J.G(q)
x=J.G(t)
o=J.k(y.dE(q,2),x.dE(t,2))
n=J.o(y.dE(q,2),x.dE(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.d(new P.F(this.w,o),[null])
k=H.d(new P.F(this.w,n),[null])
j=H.d(new P.F(J.k(this.w,z),p),[null])
i=H.d(new P.F(J.k(this.w,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.e(y,0)
h=y[0]
this.fe(h.gbc(),this.I)
R.qp(h.gbc(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.b(y)+","+H.b(x)+" "
z.a+="L "+H.b(j.a)+","+H.b(j.b)+" "
z.a+="L "+H.b(i.a)+","+H.b(i.b)+" "
z.a+="L "+H.b(k.a)+","+H.b(k.b)+" "
z.a+="L "+H.b(y)+","+H.b(x)+" "
this.CE(h.gbc())
x=this.cy
x.toString
new W.e_(x).O(0,"viewBox")}},
aXZ:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.l1(J.B(J.o(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.e(a,y)
t=J.X(J.c4(a[y],16),255)
if(y>=a.length)return H.e(a,y)
s=J.X(J.c4(a[y],8),255)
if(y>=a.length)return H.e(a,y)
r=J.X(a[y],255)
if(x>=a.length)return H.e(a,x)
q=J.X(J.c4(a[x],16),255)
if(x>=a.length)return H.e(a,x)
p=J.X(J.c4(a[x],8),255)
if(x>=a.length)return H.e(a,x)
o=J.X(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.P(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.P(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.P(w*r+m*o)&255)>>>0)}}return z},
aVb:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.l1(J.B(J.o(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.e(a,x)
v=a[x]
if(y>=w)return H.e(a,y)
t=J.L(J.o(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.e(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.k(w,s*t))}}return z},
b0m:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aD(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.E(this.ry,"%")&&!0
z=this.ry
if(v){H.cq("")
z=H.e2(z,"%","")}u=P.dI(z,new D.apB())
if(v){z=P.aD(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.E(this.x1,"%")&&!0
z=this.x1
if(s){H.cq("")
z=H.e2(z,"%","")}r=P.dI(z,new D.apC())
if(s){z=P.aD(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aD(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aD(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.seN(0,w)
for(z=J.G(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.o(this.dy,90)
d=J.o(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.k(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.F(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.e(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.e(e,d)
g=J.aT(J.B(e[d],255))
g=J.bb(J.a(g,0)?1:g,24)
e=h.gbc()
a3=this.k2
if(d>=a3.length)return H.e(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.fe(e,a3+g)
a3=h.gbc()
e=this.k2
if(d>=e.length)return H.e(e,d)
R.qp(a3,e[d]+g,1,"solid")
y.a+="M "+H.b(l)+","+H.b(k)+" "
y.a+="L "+H.b(a)+","+H.b(a0)+" "
y.a+="L "+H.b(a1)+","+H.b(a2)+" "
y.a+="L "+H.b(j)+","+H.b(i)+" "
y.a+="L "+H.b(l)+","+H.b(k)+" "
this.CE(h.gbc())}}},
bw5:[function(){var z,y
z=new D.aac(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gbdt",0,0,3],
V:["aH_",function(){var z=this.r1
z.d=!0
z.r=!0
z.seN(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gdm",0,0,0],
aKU:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sagP([new D.yK(65280,0.5,0),new D.yK(16776960,0.8,0.5),new D.yK(16711680,1,1)])
z=new D.oo(this.gbdt(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
apB:{"^":"c:0;",
$1:function(a){return 0}},
apC:{"^":"c:0;",
$1:function(a){return 0}},
yK:{"^":"t;i0:a*,Fv:b>,vK:c>"}}],["","",,E,{"^":"",
bYn:[function(a){var z=!!J.m(a.gmh().gbc()).$isha?H.j(a.gmh().gbc(),"$isha"):null
if(z!=null)if(z.gpx()!=null&&!J.a(z.gpx(),""))return E.Y7(a.gmh(),z.gpx())
else return z.Kk(a)
return""},"$1","bPJ",2,0,9,57],
bMB:function(){if($.U1)return
$.U1=!0
$.$get$ig().l(0,"percentTextSize",E.bPO())
$.$get$ig().l(0,"minorTicksPercentLength",E.ai3())
$.$get$ig().l(0,"majorTicksPercentLength",E.ai3())
$.$get$ig().l(0,"percentStartThickness",E.ai5())
$.$get$ig().l(0,"percentEndThickness",E.ai5())
$.$get$ih().l(0,"percentTextSize",E.bPP())
$.$get$ih().l(0,"minorTicksPercentLength",E.ai4())
$.$get$ih().l(0,"majorTicksPercentLength",E.ai4())
$.$get$ih().l(0,"percentStartThickness",E.ai6())
$.$get$ih().l(0,"percentEndThickness",E.ai6())},
beV:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$ex())
C.a.q(z,$.$get$Fm())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$ex())
C.a.q(z,$.$get$Gt())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$ex())
C.a.q(z,$.$get$Gr())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$ex())
C.a.q(z,$.$get$ON())
return z
case"linearAxis":return $.$get$xu()
case"logAxis":return $.$get$xx()
case"categoryAxis":return $.$get$v1()
case"datetimeAxis":return $.$get$xg()
case"axisRenderer":return $.$get$uV()
case"radialAxisRenderer":return $.$get$OG()
case"angularAxisRenderer":return $.$get$MT()
case"linearAxisRenderer":return $.$get$uV()
case"logAxisRenderer":return $.$get$uV()
case"categoryAxisRenderer":return $.$get$uV()
case"datetimeAxisRenderer":return $.$get$uV()
case"lineSeries":return $.$get$xs()
case"areaSeries":return $.$get$F2()
case"columnSeries":return $.$get$Fo()
case"barSeries":return $.$get$F9()
case"bubbleSeries":return $.$get$Fg()
case"pieSeries":return $.$get$AW()
case"spectrumSeries":return $.$get$P_()
case"radarSeries":return $.$get$AZ()
case"lineSet":return $.$get$t5()
case"areaSet":return $.$get$F4()
case"columnSet":return $.$get$Fq()
case"barSet":return $.$get$Fb()
case"gridlines":return $.$get$NO()}return[]},
beT:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof E.pd)return a
else{z=$.$get$ZC()
y=H.d([],[D.eq])
x=H.d([],[N.jW])
w=H.d([],[E.iS])
v=H.d([],[N.jW])
u=H.d([],[E.iS])
t=H.d([],[N.jW])
s=H.d([],[E.Ak])
r=H.d([],[N.jW])
q=H.d([],[E.B_])
p=H.d([],[N.jW])
o=$.$get$ap()
n=$.S+1
$.S=n
n=new E.pd(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,null,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
n.cc(b,"chart")
J.U(J.x(n.b),"absolute")
o=E.arR()
n.v=o
J.bE(n.b,o.cx)
o=n.v
o.bj=n
o.SP()
o=E.aoR()
n.D=o
o.sde(n.v)
return n}case"scaleTicks":if(a instanceof E.Gs)return a
else{z=$.$get$a23()
y=$.$get$ap()
x=$.S+1
$.S=x
x=new E.Gs(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-ticks")
J.U(J.x(x.b),"absolute")
z=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.t,N.c7])),[P.t,N.c7])
z=new E.as5(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cA(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,[P.D,P.aH]])),[P.v,[P.D,P.aH]]))
z.a=z
z.cy=P.io()
x.v=z
J.bE(x.b,z.ga3Q())
return x}case"scaleLabels":if(a instanceof E.Gq)return a
else{z=$.$get$a21()
y=$.$get$ap()
x=$.S+1
$.S=x
x=new E.Gq(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-labels")
J.U(J.x(x.b),"absolute")
z=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.t,N.c7])),[P.t,N.c7])
z=new E.as3(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cA(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,[P.D,P.aH]])),[P.v,[P.D,P.aH]]))
z.a=z
z.cy=P.io()
z.aKT()
x.v=z
J.bE(x.b,z.ga3Q())
x.v.se8(x)
return x}case"scaleTrack":if(a instanceof E.Gu)return a
else{z=$.$get$a25()
y=$.$get$ap()
x=$.S+1
$.S=x
x=new E.Gu(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ar(),null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-track")
J.U(J.x(x.b),"absolute")
J.m9(J.J(x.b),"hidden")
y=E.as7()
x.v=y
J.bE(x.b,y.ga3Q())
return x}}return},
bYT:[function(){var z=new E.atf(null,null,null)
z.ajU()
return z},"$0","bPK",0,0,3],
arR:function(){var z,y,x,w,v,u,t
z=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.t,N.c7])),[P.t,N.c7])
y=P.bj(0,0,0,0,null)
x=P.bj(0,0,0,0,null)
w=new D.cV(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.d([],[P.ff])
t=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,P.t])),[P.v,P.t])
z=new E.o2(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",D.bPj(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,[P.D,P.aH]])),[P.v,[P.D,P.aH]]))
z.a=z
z.aKS("chartBase")
z.aKQ()
z.aLB()
z.sXp("single")
z.aL3()
return z},
c4u:[function(a,b,c){return E.bdu(a,c)},"$3","bPO",6,0,1,17,30,1],
bdu:function(a,b){var z,y,x
z=a.H("view")
if(z==null)return
y=z.gdP()
if(y==null)return
x=J.h(y)
return J.L(J.B(J.a(y.grz(),"circular")?P.aD(x.gbF(y),x.gcf(y)):x.gbF(y),b),200)},
c4v:[function(a,b,c){return E.bdv(a,c)},"$3","bPP",6,0,1,17,30,1],
bdv:function(a,b){var z,y,x,w
z=a.H("view")
if(z==null)return
y=z.gdP()
if(y==null)return
x=J.B(b,200)
w=J.h(y)
return J.L(x,J.a(y.grz(),"circular")?P.aD(w.gbF(y),w.gcf(y)):w.gbF(y))},
c4w:[function(a,b,c){return E.bdw(a,c)},"$3","ai3",6,0,1,17,30,1],
bdw:function(a,b){var z,y,x
z=a.H("view")
if(z==null)return
y=z.gdP()
if(y==null)return
x=J.h(y)
return J.L(J.B(J.a(y.grz(),"circular")?P.aD(x.gbF(y),x.gcf(y)):x.gbF(y),b),200)},
c4x:[function(a,b,c){return E.bdx(a,c)},"$3","ai4",6,0,1,17,30,1],
bdx:function(a,b){var z,y,x,w
z=a.H("view")
if(z==null)return
y=z.gdP()
if(y==null)return
x=J.B(b,200)
w=J.h(y)
return J.L(x,J.a(y.grz(),"circular")?P.aD(w.gbF(y),w.gcf(y)):w.gbF(y))},
c4y:[function(a,b,c){return E.bdy(a,c)},"$3","ai5",6,0,1,17,30,1],
bdy:function(a,b){var z,y,x
z=a.H("view")
if(z==null)return
y=z.gdP()
if(y==null)return
x=J.h(y)
if(J.a(y.grz(),"circular")){x=P.aD(x.gbF(y),x.gcf(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.L(J.B(x.gbF(y),b),100)
return x},
c4z:[function(a,b,c){return E.bdz(a,c)},"$3","ai6",6,0,1,17,30,1],
bdz:function(a,b){var z,y,x,w
z=a.H("view")
if(z==null)return
y=z.gdP()
if(y==null)return
x=J.h(y)
w=J.av(b)
return J.a(y.grz(),"circular")?J.L(w.bl(b,200),P.aD(x.gbF(y),x.gcf(y))):J.L(w.bl(b,100),x.gbF(y))},
atf:{"^":"Pk;a,b,c",
sbY:function(a,b){var z,y,x,w,v
if(J.a(this.b,b))return
this.aHK(this,b)
if(b instanceof D.lK){z=b.e
if(z.gbc() instanceof D.eq&&H.j(z.gbc(),"$iseq").w!=null){J.zO(J.J(this.a),"")
return}y=U.c1(b.r,"fault")
if(y==="fault"&&b.r instanceof V.u){x=b.r
if(J.a(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof V.eX&&J.y(w.x1,0)){z=H.j(w.dd(0),"$isk6")
y=U.ed(z.gi0(z),null,"rgba(0,0,0,0)")}}}v=H.b(y==="fault"?U.ed(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.zO(J.J(this.a),v)}},
ahl:function(a){J.b2(this.a,a,$.$get$aB())}},
as3:{"^":"apy;af,aj,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,B,T,I,W,X,aa,a4,U,C,a_,a3,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sti:function(a){var z=this.k4
if(z instanceof V.u)H.j(z,"$isu").dg(this.gdZ())
this.aGR(a)
if(a instanceof V.u)a.dF(this.gdZ())},
svD:function(a,b){this.aiC(this,b)
this.a0w()},
sL5:function(a){this.aiD(a)
this.a0w()},
ge8:function(){return this.aj},
se8:function(a){H.j(a,"$isaV")
this.aj=a
if(a!=null)V.bm(this.gbic())},
fe:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.aiE(a,b)
return}if(!!J.m(a).$isbf){z=this.af.a
if(!z.M(0,a))z.l(0,a,new N.c7(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kn(b)}},
pQ:[function(a){this.dl()},"$1","gdZ",2,0,2,11],
a0w:[function(){var z=this.aj
if(z!=null)if(z.a instanceof V.u)V.a3(new E.as4(this))},"$0","gbic",0,0,0]},
as4:{"^":"c:3;a",
$0:[function(){var z=this.a
z.aj.a.bq("offsetLeft",z.a_)
z.aj.a.bq("offsetRight",z.a3)},null,null,0,0,null,"call"]},
Gq:{"^":"aP7;aE,dP:v@,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,c9,ca,c6,cp,ce,co,cq,cI,bR,cl,cJ,cr,bV,cm,ct,cK,cF,cz,cw,cu,cA,cP,cQ,cN,cL,cS,cG,cj,cY,cH,bQ,cB,cR,cC,cv,cU,cD,cT,cW,d_,dc,cX,cO,d0,d1,d6,cn,d2,d3,cE,d4,d7,d8,cZ,da,cV,ck,d9,d5,W,X,aa,a4,U,C,a_,a3,af,aj,an,ag,ao,ap,a9,aC,aJ,aZ,al,aU,aD,aG,ar,ay,aQ,aT,au,aV,aS,aN,bn,be,ba,aW,bm,b8,b9,bu,b7,bP,bD,bh,bs,bi,b0,bv,bE,bt,bJ,c8,c3,bA,c4,bM,bX,bK,bT,bO,bU,bB,bw,bj,c_,cd,c5,bL,c0,y2,w,B,T,I,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdR:function(){return this.aE},
seZ:function(a,b){if(J.a(this.a3,"none")&&!J.a(b,"none")){this.mu(this,b)
this.eo()}else this.mu(this,b)},
fY:[function(a,b){this.ne(this,b)
this.shA(!0)},"$1","gf3",2,0,2,11],
k5:[function(a){this.xc()},"$0","gig",0,0,0],
V:[function(){this.shA(!1)
this.fI()
this.v.sKQ(!0)
this.v.V()
this.v.sti(null)
this.v.sKQ(!1)},"$0","gdm",0,0,0],
i4:[function(){this.shA(!1)
this.fI()},"$0","gkl",0,0,0],
h3:function(){this.w6()
this.shA(!0)},
xc:function(){if(this.a instanceof V.u)this.v.j7(J.db(this.b),J.d4(this.b))},
eo:function(){var z,y
this.Cd()
this.sot(-1)
z=this.v
y=J.h(z)
y.sbF(z,J.o(y.gbF(z),1))},
$isbU:1,
$isbQ:1,
$iscp:1},
aP7:{"^":"aV+lP;ot:x$?,ul:y$?",$iscp:1},
bw6:{"^":"c:40;",
$2:[function(a,b){a.gdP().srz(U.as(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bw7:{"^":"c:40;",
$2:[function(a,b){J.LL(a.gdP(),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bw8:{"^":"c:40;",
$2:[function(a,b){a.gdP().sL5(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bw9:{"^":"c:40;",
$2:[function(a,b){J.zT(a.gdP(),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bwa:{"^":"c:40;",
$2:[function(a,b){J.zS(a.gdP(),U.b0(b,100))},null,null,4,0,null,0,2,"call"]},
bwb:{"^":"c:40;",
$2:[function(a,b){a.gdP().syl(U.E(b,""))},null,null,4,0,null,0,2,"call"]},
bwc:{"^":"c:40;",
$2:[function(a,b){a.gdP().saF0(U.R(b,!1))},null,null,4,0,null,0,2,"call"]},
bwd:{"^":"c:40;",
$2:[function(a,b){a.gdP().sbdE(U.kj(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bwf:{"^":"c:40;",
$2:[function(a,b){a.gdP().sti(R.cR(b,16777215))},null,null,4,0,null,0,2,"call"]},
bwg:{"^":"c:40;",
$2:[function(a,b){a.gdP().sKE(U.E(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bwh:{"^":"c:40;",
$2:[function(a,b){a.gdP().sKF(U.as(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bwi:{"^":"c:40;",
$2:[function(a,b){a.gdP().sKG(U.as(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bwj:{"^":"c:40;",
$2:[function(a,b){a.gdP().sKI(U.as(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bwk:{"^":"c:40;",
$2:[function(a,b){a.gdP().sKH(U.am(b,0))},null,null,4,0,null,0,2,"call"]},
bwl:{"^":"c:40;",
$2:[function(a,b){a.gdP().sb5Z(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bwm:{"^":"c:40;",
$2:[function(a,b){a.gdP().sb5Y(U.as(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bwn:{"^":"c:40;",
$2:[function(a,b){a.gdP().sWc(U.b0(b,-120))},null,null,4,0,null,0,2,"call"]},
bwo:{"^":"c:40;",
$2:[function(a,b){J.LB(a.gdP(),U.b0(b,120))},null,null,4,0,null,0,2,"call"]},
bwq:{"^":"c:40;",
$2:[function(a,b){a.gdP().sZD(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bwr:{"^":"c:40;",
$2:[function(a,b){a.gdP().sZE(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bws:{"^":"c:40;",
$2:[function(a,b){a.gdP().sZF(U.b0(b,90))},null,null,4,0,null,0,2,"call"]},
bwt:{"^":"c:40;",
$2:[function(a,b){a.gdP().sab9(U.am(b,11))},null,null,4,0,null,0,2,"call"]},
bwu:{"^":"c:40;",
$2:[function(a,b){a.gdP().sb5K(U.as(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
as5:{"^":"apz;I,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,B,T,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
stk:function(a){var z=this.rx
if(z instanceof V.u)H.j(z,"$isu").dg(this.gdZ())
this.aGZ(a)
if(a instanceof V.u)a.dF(this.gdZ())},
sab8:function(a){var z=this.k4
if(z instanceof V.u)H.j(z,"$isu").dg(this.gdZ())
this.aGY(a)
if(a instanceof V.u)a.dF(this.gdZ())},
fG:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.I.a
if(z.M(0,a))z.h(0,a).kz(null)
this.aGU(a,b,c,d)
return}if(!!J.m(a).$isbf){z=this.I.a
if(!z.M(0,a))z.l(0,a,new N.c7(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kz(b)
y.sm9(c)
y.slP(d)}},
pQ:[function(a){this.dl()},"$1","gdZ",2,0,2,11]},
Gs:{"^":"aP8;aE,dP:v@,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,c9,ca,c6,cp,ce,co,cq,cI,bR,cl,cJ,cr,bV,cm,ct,cK,cF,cz,cw,cu,cA,cP,cQ,cN,cL,cS,cG,cj,cY,cH,bQ,cB,cR,cC,cv,cU,cD,cT,cW,d_,dc,cX,cO,d0,d1,d6,cn,d2,d3,cE,d4,d7,d8,cZ,da,cV,ck,d9,d5,W,X,aa,a4,U,C,a_,a3,af,aj,an,ag,ao,ap,a9,aC,aJ,aZ,al,aU,aD,aG,ar,ay,aQ,aT,au,aV,aS,aN,bn,be,ba,aW,bm,b8,b9,bu,b7,bP,bD,bh,bs,bi,b0,bv,bE,bt,bJ,c8,c3,bA,c4,bM,bX,bK,bT,bO,bU,bB,bw,bj,c_,cd,c5,bL,c0,y2,w,B,T,I,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdR:function(){return this.aE},
seZ:function(a,b){if(J.a(this.a3,"none")&&!J.a(b,"none")){this.mu(this,b)
this.eo()}else this.mu(this,b)},
fY:[function(a,b){this.ne(this,b)
this.shA(!0)
if(b==null)this.v.j7(J.db(this.b),J.d4(this.b))},"$1","gf3",2,0,2,11],
k5:[function(a){this.v.j7(J.db(this.b),J.d4(this.b))},"$0","gig",0,0,0],
V:[function(){this.shA(!1)
this.fI()
this.v.sKQ(!0)
this.v.V()
this.v.stk(null)
this.v.sab8(null)
this.v.sKQ(!1)},"$0","gdm",0,0,0],
i4:[function(){this.shA(!1)
this.fI()},"$0","gkl",0,0,0],
h3:function(){this.w6()
this.shA(!0)},
eo:function(){var z,y
this.Cd()
this.sot(-1)
z=this.v
y=J.h(z)
y.sbF(z,J.o(y.gbF(z),1))},
xc:function(){this.v.j7(J.db(this.b),J.d4(this.b))},
$isbU:1,
$isbQ:1},
aP8:{"^":"aV+lP;ot:x$?,ul:y$?",$iscp:1},
bwv:{"^":"c:55;",
$2:[function(a,b){a.gdP().srz(U.as(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bww:{"^":"c:55;",
$2:[function(a,b){a.gdP().sbgs(U.as(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bwx:{"^":"c:55;",
$2:[function(a,b){J.LL(a.gdP(),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bwy:{"^":"c:55;",
$2:[function(a,b){a.gdP().sL5(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bwz:{"^":"c:55;",
$2:[function(a,b){a.gdP().sab8(R.cR(b,16777215))},null,null,4,0,null,0,2,"call"]},
bwD:{"^":"c:55;",
$2:[function(a,b){a.gdP().sb73(U.am(b,1))},null,null,4,0,null,0,2,"call"]},
bwE:{"^":"c:55;",
$2:[function(a,b){a.gdP().stk(R.cR(b,16777215))},null,null,4,0,null,0,2,"call"]},
bwF:{"^":"c:55;",
$2:[function(a,b){a.gdP().sKY(U.am(b,1))},null,null,4,0,null,0,2,"call"]},
bwG:{"^":"c:55;",
$2:[function(a,b){a.gdP().sWc(U.b0(b,-120))},null,null,4,0,null,0,2,"call"]},
bwH:{"^":"c:55;",
$2:[function(a,b){J.LB(a.gdP(),U.b0(b,120))},null,null,4,0,null,0,2,"call"]},
bwI:{"^":"c:55;",
$2:[function(a,b){a.gdP().sZD(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bwJ:{"^":"c:55;",
$2:[function(a,b){a.gdP().sZE(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bwK:{"^":"c:55;",
$2:[function(a,b){a.gdP().sZF(U.b0(b,90))},null,null,4,0,null,0,2,"call"]},
bwL:{"^":"c:55;",
$2:[function(a,b){a.gdP().sab9(U.am(b,11))},null,null,4,0,null,0,2,"call"]},
bwM:{"^":"c:55;",
$2:[function(a,b){a.gdP().sb74(U.kj(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bwO:{"^":"c:55;",
$2:[function(a,b){a.gdP().sb7z(U.am(b,2))},null,null,4,0,null,0,2,"call"]},
bwP:{"^":"c:55;",
$2:[function(a,b){a.gdP().sb7A(U.kj(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bwQ:{"^":"c:55;",
$2:[function(a,b){a.gdP().saZa(U.b0(b,null))},null,null,4,0,null,0,2,"call"]},
as6:{"^":"apA;T,I,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,B,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gkC:function(){return this.I},
skC:function(a){var z=this.I
if(z!=null)z.dg(this.gaeF())
this.I=a
if(a!=null)a.dF(this.gaeF())
if(!this.r)this.bhL(null)},
bhL:[function(a){var z,y,x,w,v,u,t,s
z=this.I
if(z==null){z=new V.eX(!1,null,H.d([],[V.aC]),0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!1,null,null,-1,null,!1,null,!1,null,!1,0,null,null,null,null,null)
z.bo()
z.aP(!1,null)
z.ch=null
z.fT(V.iy(new V.dN(0,255,0,1),0,0))
z.fT(V.iy(new V.dN(0,0,0,1),0,50))}y=J.h6(z)
x=J.b4(y)
x.eW(y,V.ug())
w=[]
if(J.y(x.gm(y),1))for(x=x.gb6(y);x.u();){v=x.gK()
u=J.h(v)
t=u.gi0(v)
s=H.dh(v.i("alpha"))
s.toString
w.push(new D.yK(t,s,J.L(u.gvK(v),100)))}else if(J.a(x.gm(y),1)){v=x.h(y,0)
x=J.h(v)
u=x.gi0(v)
t=H.dh(v.i("alpha"))
t.toString
w.push(new D.yK(u,t,0))
x=x.gi0(v)
t=H.dh(v.i("alpha"))
t.toString
w.push(new D.yK(x,t,1))}this.sagP(w)},"$1","gaeF",2,0,6,11],
fe:function(a,b){var z,y,x
if(typeof b==="number"&&Math.floor(b)===b){this.aiE(a,b)
return}if(!!J.m(a).$isbf){z=this.T.a
if(!z.M(0,a))z.l(0,a,new N.c7(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
x=V.cS(!1,null)
x.N("fillType",!0).ac("gradient")
x.N("gradient",!0).$2(b,!1)
x.N("gradientType",!0).ac("linear")
y.kn(x)
x.V()}},
V:[function(){var z=this.I
if(z!=null&&!J.a(z,$.$get$Av())){this.I.dg(this.gaeF())
this.I=null}this.aH_()},"$0","gdm",0,0,0],
aL4:function(){var z=$.$get$Av()
if(J.a(z.x1,0)){z.fT(V.iy(new V.dN(0,255,0,1),1,0))
z.fT(V.iy(new V.dN(255,255,0,1),1,50))
z.fT(V.iy(new V.dN(255,0,0,1),1,100))}},
ak:{
as7:function(){var z=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.t,N.c7])),[P.t,N.c7])
z=new E.as6(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cA(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,[P.D,P.aH]])),[P.v,[P.D,P.aH]]))
z.a=z
z.cy=P.io()
z.aKU()
z.aL4()
return z}}},
Gu:{"^":"aP9;aE,dP:v@,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,c9,ca,c6,cp,ce,co,cq,cI,bR,cl,cJ,cr,bV,cm,ct,cK,cF,cz,cw,cu,cA,cP,cQ,cN,cL,cS,cG,cj,cY,cH,bQ,cB,cR,cC,cv,cU,cD,cT,cW,d_,dc,cX,cO,d0,d1,d6,cn,d2,d3,cE,d4,d7,d8,cZ,da,cV,ck,d9,d5,W,X,aa,a4,U,C,a_,a3,af,aj,an,ag,ao,ap,a9,aC,aJ,aZ,al,aU,aD,aG,ar,ay,aQ,aT,au,aV,aS,aN,bn,be,ba,aW,bm,b8,b9,bu,b7,bP,bD,bh,bs,bi,b0,bv,bE,bt,bJ,c8,c3,bA,c4,bM,bX,bK,bT,bO,bU,bB,bw,bj,c_,cd,c5,bL,c0,y2,w,B,T,I,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdR:function(){return this.aE},
seZ:function(a,b){if(J.a(this.a3,"none")&&!J.a(b,"none")){this.mu(this,b)
this.eo()}else this.mu(this,b)},
fY:[function(a,b){this.ne(this,b)
this.shA(!0)},"$1","gf3",2,0,2,11],
k5:[function(a){this.xc()},"$0","gig",0,0,0],
V:[function(){this.shA(!1)
this.fI()
this.v.sKQ(!0)
this.v.V()
this.v.skC(null)
this.v.sKQ(!1)},"$0","gdm",0,0,0],
i4:[function(){this.shA(!1)
this.fI()},"$0","gkl",0,0,0],
h3:function(){this.w6()
this.shA(!0)},
eo:function(){var z,y
this.Cd()
this.sot(-1)
z=this.v
y=J.h(z)
y.sbF(z,J.o(y.gbF(z),1))},
xc:function(){if(this.a instanceof V.u)this.v.j7(J.db(this.b),J.d4(this.b))},
$isbU:1,
$isbQ:1},
aP9:{"^":"aV+lP;ot:x$?,ul:y$?",$iscp:1},
bvU:{"^":"c:76;",
$2:[function(a,b){a.gdP().srz(U.as(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bvV:{"^":"c:76;",
$2:[function(a,b){J.LL(a.gdP(),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bvW:{"^":"c:76;",
$2:[function(a,b){a.gdP().sL5(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bvX:{"^":"c:76;",
$2:[function(a,b){a.gdP().sbdD(U.kj(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bvY:{"^":"c:76;",
$2:[function(a,b){a.gdP().sbdC(U.kj(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bvZ:{"^":"c:76;",
$2:[function(a,b){a.gdP().sk6(U.as(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bw_:{"^":"c:76;",
$2:[function(a,b){var z=a.gdP()
z.skC(b!=null?V.rg(b):$.$get$Av())},null,null,4,0,null,0,2,"call"]},
bw0:{"^":"c:76;",
$2:[function(a,b){a.gdP().sWc(U.b0(b,-120))},null,null,4,0,null,0,2,"call"]},
bw1:{"^":"c:76;",
$2:[function(a,b){J.LB(a.gdP(),U.b0(b,120))},null,null,4,0,null,0,2,"call"]},
bw2:{"^":"c:76;",
$2:[function(a,b){a.gdP().sZD(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bw4:{"^":"c:76;",
$2:[function(a,b){a.gdP().sZE(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bw5:{"^":"c:76;",
$2:[function(a,b){a.gdP().sZF(U.b0(b,90))},null,null,4,0,null,0,2,"call"]},
Ae:{"^":"t;afJ:a@,jo:b*,k0:c*"},
aoQ:{"^":"mj;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,c,d,e,f,r,x,y,z,Q,ch,a,b",
gt4:function(){return this.r1},
st4:function(a){if(!J.a(this.r1,a)){this.r1=a
this.dl()}},
gde:function(){return this.r2},
sde:function(a){this.beK(a)},
gkS:function(){return this.go},
jA:function(a,b){var z,y,x,w
this.IJ(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.io()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.b(a)+"px"
z.width=y
z=this.id.style
y=H.b(b)+"px"
z.height=y
this.fG(this.k1,0,0,"none")
this.fe(this.k1,this.r2.cq)
z=this.k2
y=this.r2
this.fG(z,y.cp,J.aR(y.ce),this.r2.co)
y=this.k3
z=this.r2
this.fG(y,z.cp,J.aR(z.ce),this.r2.co)
z=this.db
if(z===2){z=J.y(this.r1.b,0)
y=J.m(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a1(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aM(a))
y=this.k1
y.toString
y.setAttribute("height",J.a1(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a1(J.k(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aM(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aM(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.b(this.cy.b)+" L "+H.b(a)+","+H.b(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.b(J.k(this.cy.b,this.r1.b))+" L "+H.b(a)+","+H.b(J.k(this.cy.b,this.r1.b)))}else if(z===1){z=J.y(this.r1.a,0)
y=J.m(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a1(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a1(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aM(b))}else{x.toString
x.setAttribute("x",J.a1(J.k(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aM(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aM(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.b(this.cy.a)+",0 L "+H.b(this.cy.a)+","+H.b(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.b(J.k(this.cy.a,this.r1.a))+",0 L "+H.b(J.k(this.cy.a,this.r1.a))+","+H.b(b))}else if(z===3){z=J.y(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a1(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a1(this.r1.a))}else{y.toString
y.setAttribute("x",J.a1(J.k(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aM(0-y))}z=J.y(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a1(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a1(this.r1.b))}else{y.toString
y.setAttribute("y",J.a1(J.k(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aM(0-y))}z=this.k1
y=this.r2
this.fG(z,y.cp,J.aR(y.ce),this.r2.co)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
beK:function(a){var z,y
this.adE()
this.adF()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().G(0)
this.r2.qp(0,"CartesianChartZoomerReset",this.gasB())}this.r2=a
if(a!=null){z=this.fx
y=J.ck(a.cx)
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaWS()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.r2.of(0,"CartesianChartZoomerReset",this.gasB())
if($.$get$hB()===!0){y=this.r2.cx
y.toString
y=H.d(new W.bF(y,"touchstart",!1),[H.r(C.T,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaWT()),y.c),[H.r(y,0)])
y.t()
z.push(y)}}this.dx=null
this.dy=null},
Pd:function(a){var z,y,x,w,v
z=this.MA(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.K)(z),++x){v=J.m(z[x])
if(!(!!v.$istG||!!v.$isiE||!!v.$isjt))return!1}return!0},
aCx:function(a){var z=J.m(a)
if(!!z.$isjt)return J.aw(a.db)?null:a.db
else if(!!z.$iskH)return a.db
return 0/0},
a2p:function(a,b,c){var z,y,x,w
z=J.m(a)
if(!!z.$isjt){if(b==null)y=null
else{y=J.aT(b)
x=!a.ao
w=new P.ah(y,x)
w.eK(y,x)
y=w}z.sjo(a,y)}else if(!!z.$isiE)z.sjo(a,b)
else if(!!z.$istG)z.sjo(a,b)},
aEw:function(a,b){return this.a2p(a,b,!1)},
aCv:function(a){var z=J.m(a)
if(!!z.$isjt)return J.aw(a.cy)?null:a.cy
else if(!!z.$iskH)return a.cy
return 0/0},
a2o:function(a,b,c){var z,y,x,w
z=J.m(a)
if(!!z.$isjt){if(b==null)y=null
else{y=J.aT(b)
x=!a.ao
w=new P.ah(y,x)
w.eK(y,x)
y=w}z.sk0(a,y)}else if(!!z.$isiE)z.sk0(a,b)
else if(!!z.$istG)z.sk0(a,b)},
aEu:function(a,b){return this.a2o(a,b,!1)},
afI:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[D.ez,E.Ae])),[D.ez,E.Ae])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[D.ez,E.Ae])),[D.ez,E.Ae])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.MA(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.K)(v),++u){t=v[u]
s=x.a
if(!s.M(0,t)){r=J.m(t)
r=!!r.$istG||!!r.$isiE||!!r.$isjt}else r=!1
if(r)s.l(0,t,new E.Ae(!1,this.aCx(t),this.aCv(t)))}}y=this.cy
if(z){y=y.b
q=P.aG(y,J.k(y,b))
y=this.cy.b
p=P.aD(y,J.k(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aG(y,J.k(y,b))
y=this.cy.a
m=P.aD(y,J.k(y,b))
o="h"
q=null
p=null}l=[]
k=D.jZ(this.r2.a9,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof D.kv))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.ap:f.ao
r=J.m(h)
if(!(!!r.$istG||!!r.$isiE||!!r.$isjt)){g=f
break c$0}if(J.an(C.a.bx(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=F.b7(y,H.d(new P.F(0,0),[null]))
y=J.aR(F.aN(J.ak(f.gde()),e).b)
if(typeof q!=="number")return q.F()
y=H.d(new P.F(0,q-y),[null])
j=J.q(f.fr.r4([J.o(y.a,C.b.P(f.cy.offsetLeft)),J.o(y.b,C.b.P(f.cy.offsetTop))]),1)
e=F.b7(f.cy,H.d(new P.F(0,0),[null]))
y=J.aR(F.aN(J.ak(f.gde()),e).b)
if(typeof p!=="number")return p.F()
y=H.d(new P.F(0,p-y),[null])
i=J.q(f.fr.r4([J.o(y.a,C.b.P(f.cy.offsetLeft)),J.o(y.b,C.b.P(f.cy.offsetTop))]),1)}else{e=F.b7(y,H.d(new P.F(0,0),[null]))
y=J.aR(F.aN(J.ak(f.gde()),e).a)
if(typeof m!=="number")return m.F()
y=H.d(new P.F(m-y,0),[null])
j=J.q(f.fr.r4([J.o(y.a,C.b.P(f.cy.offsetLeft)),J.o(y.b,C.b.P(f.cy.offsetTop))]),0)
e=F.b7(f.cy,H.d(new P.F(0,0),[null]))
y=J.aR(F.aN(J.ak(f.gde()),e).a)
if(typeof n!=="number")return n.F()
y=H.d(new P.F(n-y,0),[null])
i=J.q(f.fr.r4([J.o(y.a,C.b.P(f.cy.offsetLeft)),J.o(y.b,C.b.P(f.cy.offsetTop))]),0)}if(J.Q(i,j)){d=i
i=j
j=d}this.aEw(h,j)
this.aEu(h,i)
this.fr=!0
break}k.length===y||(0,H.K)(k);++u}if(!this.fr)return
x.a.h(0,h).safJ(!0)
if(h!=null&&!c){y=this.r2
if(z){y.ca=j
y.c6=i
y.aAL()}else{y.bL=j
y.c0=i
y.azS()}}},
aBq:function(a,b){return this.afI(a,b,!1)},
ay8:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.MA(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.M(0,t)){this.a2p(t,J.VJ(w.h(0,t)),!0)
this.a2o(t,J.VI(w.h(0,t)),!0)
if(w.h(0,t).gafJ())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.bL=0/0
x.c0=0/0
x.azS()}},
adE:function(){return this.ay8(!1)},
ayd:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.MA(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.M(0,t)){this.a2p(t,J.VJ(w.h(0,t)),!0)
this.a2o(t,J.VI(w.h(0,t)),!0)
if(w.h(0,t).gafJ())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.ca=0/0
x.c6=0/0
x.aAL()}},
adF:function(){return this.ayd(!1)},
aBr:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.G(a)
if(z.gkk(a)||J.aw(b)){if(this.fr)if(c)this.ayd(!0)
else this.ay8(!0)
return}if(!this.Pd(c))return
y=this.MA(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aCR(x)
if(w==null)return
v=J.m(b)
if(c){u=J.k(w.K4(["0",z.aM(a)]).b,this.agN(w))
t=J.k(w.K4(["0",v.aM(b)]).b,this.agN(w))
this.cy=H.d(new P.F(50,u),[null])
this.afI(2,J.o(t,u),!0)}else{s=J.k(w.K4([z.aM(a),"0"]).a,this.agM(w))
r=J.k(w.K4([v.aM(b),"0"]).a,this.agM(w))
this.cy=H.d(new P.F(s,50),[null])
this.afI(1,J.o(r,s),!0)}},
MA:function(a){var z,y,x,w,v,u,t
z=[]
y=D.jZ(this.r2.a9,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.K)(y),++v){u=y[v]
if(!(u instanceof D.kv))continue
if(a){t=u.ap
if(t!=null&&J.Q(C.a.bx(z,t),0))z.push(u.ap)}else{t=u.ao
if(t!=null&&J.Q(C.a.bx(z,t),0))z.push(u.ao)}w=u}return z},
aCR:function(a){var z,y,x,w,v
z=D.jZ(this.r2.a9,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.K)(z),++w){v=z[w]
if(!(v instanceof D.kv))continue
if(J.a(v.ap,a)||J.a(v.ao,a))return v
x=v}return},
agM:function(a){var z=F.b7(a.cy,H.d(new P.F(0,0),[null]))
return J.aR(F.aN(J.ak(a.gde()),z).a)},
agN:function(a){var z=F.b7(a.cy,H.d(new P.F(0,0),[null]))
return J.aR(F.aN(J.ak(a.gde()),z).b)},
fG:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.M(0,a))z.h(0,a).kz(null)
R.qp(a,b,c,d)
return}if(!!J.m(a).$isbf){z=this.k4.a
if(!z.M(0,a))z.l(0,a,new N.c7(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kz(b)
y.sm9(c)
y.slP(d)}},
fe:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.M(0,a))z.h(0,a).kn(null)
R.vb(a,b)
return}if(!!J.m(a).$isbf){z=this.k4.a
if(!z.M(0,a))z.l(0,a,new N.c7(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kn(b)}},
aPI:function(a){var z,y,x,w
for(z=a.length,y=this.rx,x=0;x<a.length;a.length===z||(0,H.K)(a),++x){w=a[x]
if(y.E(0,w.identifier))return w}return},
aPJ:function(a){var z,y,x,w
z=this.rx
z.dM(0)
for(y=a.length,x=0;w=a.length,x<w;a.length===y||(0,H.K)(a),++x)z.n(0,a[x].identifier)
if(0>=w)return H.e(a,0)
return a[0]},
boq:[function(a){var z,y
if($.$get$hB()===!0){z=Date.now()
y=$.ne
if(typeof y!=="number")return H.l(y)
y=z-y<1000
z=y}else z=!1
if(z)return
this.awX(J.cl(a))},"$1","gaWS",2,0,4,4],
bor:[function(a){var z=this.aPJ(J.Lf(a))
$.ne=Date.now()
this.awX(H.d(new P.F(C.b.P(z.pageX),C.b.P(z.pageY)),[null]))},"$1","gaWT",2,0,5,4],
awX:function(a){var z,y
z=this.r2
if(!z.cd&&!z.c9)return
z.cx.appendChild(this.go)
z=this.r2
this.j7(z.Q,z.ch)
this.cy=F.aN(this.go,a)
this.cx=!0
z=this.fy
y=H.d(new W.ay(document,"mousemove",!1),[H.r(C.x,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaDc()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.ay(document,"mouseup",!1),[H.r(C.A,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaDd()),y.c),[H.r(y,0)])
y.t()
z.push(y)
if($.$get$hB()===!0){y=H.d(new W.ay(document,"touchmove",!1),[H.r(C.av,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaDf()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.ay(document,"touchend",!1),[H.r(C.ab,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaDe()),y.c),[H.r(y,0)])
y.t()
z.push(y)}y=H.d(new W.ay(document,"keydown",!1),[H.r(C.a4,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gDg()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.db=0
this.st4(null)},
bko:[function(a){this.awY(J.cl(a))},"$1","gaDc",2,0,4,4],
bkr:[function(a){var z=this.aPI(J.Lf(a))
if(z!=null)this.awY(J.cl(z))},"$1","gaDf",2,0,5,4],
awY:function(a){var z,y
z=F.aN(this.go,a)
if(this.db===0)if(this.r2.c5){if(!(this.Pd(!0)&&this.Pd(!1))){this.JV()
return}if(J.an(J.aY(J.o(z.a,this.cy.a)),2)&&J.an(J.aY(J.o(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.y(J.aY(J.o(z.b,this.cy.b)),J.aY(J.o(z.a,this.cy.a)))){if(this.Pd(!0))this.db=2
else{this.JV()
return}y=2}else{if(this.Pd(!1))this.db=1
else{this.JV()
return}y=1}if(y===1)if(!this.r2.cd){this.JV()
return}if(y===2)if(!this.r2.c9){this.JV()
return}}y=this.r2
if(P.bj(0,0,y.Q,y.ch,null).oK(0,z)){y=this.db
if(y===2)this.st4(H.d(new P.F(0,J.o(z.b,this.cy.b)),[null]))
else if(y===1)this.st4(H.d(new P.F(J.o(z.a,this.cy.a),0),[null]))
else if(y===3)this.st4(H.d(new P.F(J.o(z.a,this.cy.a),J.o(z.b,this.cy.b)),[null]))
else this.st4(null)}},
bkp:[function(a){this.awZ()},"$1","gaDd",2,0,4,4],
bkq:[function(a){this.awZ()},"$1","gaDe",2,0,5,4],
awZ:function(){var z,y
for(z=this.fy;z.length>0;)z.pop().G(0)
J.a_(this.go)
this.cx=!1
this.dl()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.aBq(2,z.b)
z=this.db
if(z===1||z===3)this.aBq(1,this.r1.a)}else{this.adE()
V.a3(new E.aoT(this))}},
a9u:[function(a){if(F.cU(a)===27)this.JV()},"$1","gDg",2,0,7,4],
JV:function(){for(var z=this.fy;z.length>0;)z.pop().G(0)
J.a_(this.go)
this.cx=!1
this.dl()},
br4:[function(a){this.adE()
V.a3(new E.aoS(this))},"$1","gasB",2,0,8,4],
aKR:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.x(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ak:{
aoR:function(){var z,y
z=H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.t,N.c7])),[P.t,N.c7])
y=P.a8(null,null,null,P.O)
z=new E.aoQ(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,y,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.ab(H.d(new H.a0(0,null,null,null,null,null,0),[P.v,[P.D,P.aH]])),[P.v,[P.D,P.aH]]))
z.a=z
z.aKR()
return z}}},
aoT:{"^":"c:3;a",
$0:[function(){this.a.adF()},null,null,0,0,null,"call"]},
aoS:{"^":"c:3;a",
$0:[function(){this.a.adF()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.be,args:[V.u,P.v,P.be]},{func:1,v:true,args:[[P.Y,P.v]]},{func:1,ret:F.bU},{func:1,v:true,args:[W.cE]},{func:1,v:true,args:[W.iH]},{func:1,v:true,args:[P.t]},{func:1,v:true,args:[W.hl]},{func:1,v:true,args:[N.cx]},{func:1,ret:P.v,args:[D.lK]}]
init.types.push.apply(init.types,deferredTypes)
$.U1=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["a20","$get$a20",function(){return P.n(["scaleType",new E.bw6(),"offsetLeft",new E.bw7(),"offsetRight",new E.bw8(),"minimum",new E.bw9(),"maximum",new E.bwa(),"formatString",new E.bwb(),"showMinMaxOnly",new E.bwc(),"percentTextSize",new E.bwd(),"labelsColor",new E.bwf(),"labelsFontFamily",new E.bwg(),"labelsFontStyle",new E.bwh(),"labelsFontWeight",new E.bwi(),"labelsTextDecoration",new E.bwj(),"labelsLetterSpacing",new E.bwk(),"labelsRotation",new E.bwl(),"labelsAlign",new E.bwm(),"angleFrom",new E.bwn(),"angleTo",new E.bwo(),"percentOriginX",new E.bwq(),"percentOriginY",new E.bwr(),"percentRadius",new E.bws(),"majorTicksCount",new E.bwt(),"justify",new E.bwu()])},$,"a21","$get$a21",function(){var z=P.V()
z.q(0,N.eP())
z.q(0,$.$get$a20())
return z},$,"a22","$get$a22",function(){return P.n(["scaleType",new E.bwv(),"ticksPlacement",new E.bww(),"offsetLeft",new E.bwx(),"offsetRight",new E.bwy(),"majorTickStroke",new E.bwz(),"majorTickStrokeWidth",new E.bwD(),"minorTickStroke",new E.bwE(),"minorTickStrokeWidth",new E.bwF(),"angleFrom",new E.bwG(),"angleTo",new E.bwH(),"percentOriginX",new E.bwI(),"percentOriginY",new E.bwJ(),"percentRadius",new E.bwK(),"majorTicksCount",new E.bwL(),"majorTicksPercentLength",new E.bwM(),"minorTicksCount",new E.bwO(),"minorTicksPercentLength",new E.bwP(),"cutOffAngle",new E.bwQ()])},$,"a23","$get$a23",function(){var z=P.V()
z.q(0,N.eP())
z.q(0,$.$get$a22())
return z},$,"a24","$get$a24",function(){return P.n(["scaleType",new E.bvU(),"offsetLeft",new E.bvV(),"offsetRight",new E.bvW(),"percentStartThickness",new E.bvX(),"percentEndThickness",new E.bvY(),"placement",new E.bvZ(),"gradient",new E.bw_(),"angleFrom",new E.bw0(),"angleTo",new E.bw1(),"percentOriginX",new E.bw2(),"percentOriginY",new E.bw4(),"percentRadius",new E.bw5()])},$,"a25","$get$a25",function(){var z=P.V()
z.q(0,N.eP())
z.q(0,$.$get$a24())
return z},$])}
$dart_deferred_initializers$["dkjx1Uzb+XXa3bSQQ6zDpPygNd4="]=$dart_deferred_initializers$.current

//# sourceMappingURL=main.dart.js_2.part.js.map
